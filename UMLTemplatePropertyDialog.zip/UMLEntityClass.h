#if !defined(AFX_UMLENTITYCLASS_H__8BBDE424_2729_426C_89EC_B3E3E1021F92__INCLUDED_)
#define AFX_UMLENTITYCLASS_H__8BBDE424_2729_426C_89EC_B3E3E1021F92__INCLUDED_

#include "UMLEntity.h"
#include "Attribute.h"
#include "Operation.h"

#include "UMLClassPropertyDialog.h"
#include "Tokenizer.h"
#include "PropertyContainer.h"
#include "OperationContainer.h"
#include "AttributeContainer.h"

 
//===========================================================================
// Summary:
//     The CUMLEntityClass class derived from CUMLEntity
//      U M L Entity Class
//===========================================================================

class CUMLEntityClass : public CUMLEntity
{

public:
// Construction/initialization/destruction
	
	//-----------------------------------------------------------------------
	// Summary:
	// U M L Entity Class, Constructs a CUMLEntityClass object.
	//		Returns A  value.
	CUMLEntityClass();
	
	//-----------------------------------------------------------------------
	// Summary:
	// C U M L Entity Class, Destructor of class CUMLEntityClass
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value.
	virtual ~CUMLEntityClass();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clone this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CDiagramEntity,or NULL if the call failed
	virtual CDiagramEntity* Clone();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create From String, You construct a CUMLEntityClass object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is a static function.
	//		Returns a pointer to the object CDiagramEntity,or NULL if the call failed  
	// Parameters:
	//		str---Specifies A CString type value.
	static	CDiagramEntity* CreateFromString( const CString& str );

// Overrides
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draws current object to the specify device.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---A pointer to the CDC or NULL if the call failed.  
	//		rect---Specifies A CRect type value.
	virtual void Draw( CDC* dc, CRect rect );

	
	//-----------------------------------------------------------------------
	// Summary:
	// Import H, None Description.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns TRUE on success; FALSE otherwise.  
	// Parameters:
	//		filename---Specifies A CString type value.
	virtual BOOL	ImportH( const CString& filename );

	
	//-----------------------------------------------------------------------
	// Summary:
	// Get String, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CString type value.
	virtual CString GetString() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// From String, None Description.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns TRUE on success; FALSE otherwise.  
	// Parameters:
	//		str---Specifies A CString type value.
	virtual BOOL	FromString( const CString& str );
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create a duplicate copy of this object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		obj---A pointer to the CDiagramEntity or NULL if the call failed.
	virtual void	Copy( CDiagramEntity* obj );
	
	//-----------------------------------------------------------------------
	// Summary:
	// None Description.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CString type value.  
	// Parameters:
	//		format---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual CString	Export( UINT format = 0 ) const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Message, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns TRUE on success; FALSE otherwise.  
	// Parameters:
	//		msg---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		sender---A pointer to the CDiagramEntity or NULL if the call failed.  
	//		from---A pointer to the CWnd or NULL if the call failed.
	virtual BOOL	DoMessage( UINT msg, CDiagramEntity* sender, CWnd* from = NULL );
	
	//-----------------------------------------------------------------------
	// Summary:
	// Show Popup, Call this function to show the specify object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		point---Specifies A CPoint type value.  
	//		parent---A pointer to the CWnd or NULL if the call failed.
	virtual void	ShowPopup( CPoint point, CWnd* parent );
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Title, Sets a specify value to current class CUMLEntityClass
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		title---Specifies A CString type value.
	virtual void	SetTitle( CString title );

// Implementation
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Attributes, Returns the specified value.
	//		Returns a int type value.
	int	GetAttributes() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Operations, Returns the specified value.
	//		Returns a int type value.
	int GetOperations() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Attribute, Returns the specified value.
	//		Returns a pointer to the object CAttribute,or NULL if the call failed  
	// Parameters:
	//		index---Specifies A integer value.
	CAttribute* GetAttribute( int index ) const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Operation, Returns the specified value.
	//		Returns a pointer to the object COperation,or NULL if the call failed  
	// Parameters:
	//		index---Specifies A integer value.
	COperation* GetOperation( int index ) const;

	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear Attributes, Remove the specify data from the list.

	void ClearAttributes();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear Operations, Remove the specify data from the list.

	void ClearOperations();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear Properties, Remove the specify data from the list.

	void ClearProperties();

	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Attribute, Adds an object to the specify list.
	// Parameters:
	//		obj---A pointer to the CAttribute or NULL if the call failed.
	void AddAttribute( CAttribute* obj );
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Operation, Adds an object to the specify list.
	// Parameters:
	//		obj---A pointer to the COperation or NULL if the call failed.
	void AddOperation( COperation* obj );

	
	//-----------------------------------------------------------------------
	// Summary:
	// Calculate Restraints, None Description.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void CalcRestraints();

	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Base Class Array, Sets a specify value to current class CUMLEntityClass
	// Parameters:
	//		baseClassArray---Class Array, Specifies A CString type value.  
	//		baseClassAccessArray---Class Access Array, Specifies A CString type value.
	void		SetBaseClassArray( const CStringArray& baseClassArray, const CStringArray& baseClassAccessArray  );
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Base Class Array, Returns the specified value.
	// Parameters:
	//		array---Specifies A CString type value.  
	//		arrayAccess---Access, Specifies A CString type value.
	void		GetBaseClassArray( CStringArray& array, CStringArray& arrayAccess ) const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// In Base Class Array, None Description.
	//		Returns TRUE on success; FALSE otherwise.  
	// Parameters:
	//		title---Specifies A CString type value.
	BOOL		InBaseClassArray( const CString& title ) const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Properties, Returns the specified property value.
	//		Returns a pointer to the object CPropertyContainer,or NULL if the call failed
	CPropertyContainer* GetProperties();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Filename, Sets a specify value to current class CUMLEntityClass
	// Parameters:
	//		value---Specifies A CString type value.
	void		SetFilename( const CString& value );
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Filename, Returns the specified value.
	//		Returns a CString type value.
	CString		GetFilename() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Base Class Filename Array, Sets a specify value to current class CUMLEntityClass
	// Parameters:
	//		value---Specifies A CString type value.
	void		SetBaseClassFilenameArray( const CStringArray& value );
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Base Class Filename Array, Returns the specified value.
	// Parameters:
	//		array---Specifies A CString type value.
	void		GetBaseClassFilenameArray( CStringArray& array ) const;

protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Export H T M L, None Description.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CString type value.
	virtual CString ExportHTML() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Export C P P, None Description.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CString type value.
	virtual CString ExportCPP() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Export H, None Description.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CString type value.
	virtual CString ExportH() const;

	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Operation List, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CString type value.  
	// Parameters:
	//		format---Specifies A integer value.
	virtual CString GetOperationList( int format ) const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Attribute List, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CString type value.  
	// Parameters:
	//		format---Specifies A integer value.
	virtual CString GetAttributeList( int format ) const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Attribute Initialization List, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CString type value.
	virtual CString	GetAttributeInitializationList() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Include List, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CString type value.
	virtual CString GetIncludeList() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Dependency List, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CString type value.
	virtual CString GetDependencyList() const;

	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Operations Container, Returns the specified value.
	//		Returns a pointer to the object COperationContainer,or NULL if the call failed
	COperationContainer*	GetOperationsContainer();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Attributes Container, Returns the specified value.
	//		Returns a pointer to the object CAttributeContainer,or NULL if the call failed
	CAttributeContainer*	GetAttributesContainer();

	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Header Template Filename, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CString type value.
	virtual CString GetHeaderTemplateFilename() const;

private:

 
	// This member specify CUMLClassPropertyDialog object.  
	CUMLClassPropertyDialog	m_dlg;

	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Visible Attributes, Returns the specified value.
	//		Returns a int type value.
	int		GetVisibleAttributes() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Visible Operations, Returns the specified value.
	//		Returns a int type value.
	int		GetVisibleOperations() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Abstract, Determines if the given value is correct or exist.
	//		Returns TRUE on success; FALSE otherwise.
	BOOL	IsAbstract() const;

 
	// Class Array, The member supports arrays of CString objects.  
	CStringArray m_baseClassArray;
 
	// Class Access Array, The member supports arrays of CString objects.  
	CStringArray m_baseClassAccessArray;

 
	// You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString m_filename;
 
	// Class Filename Array, The member supports arrays of CString objects.  
	CStringArray m_baseClassFilenameArray;

 
	// This member specify CPropertyContainer object.  
	CPropertyContainer	m_properties;
 
	// This member specify COperationContainer object.  
	COperationContainer	m_operations;
 
	// This member specify CAttributeContainer object.  
	CAttributeContainer	m_attributes;


};

#endif // !defined(AFX_UMLENTITYCLASS_H__8BBDE424_2729_426C_89EC_B3E3E1021F92__INCLUDED_)
