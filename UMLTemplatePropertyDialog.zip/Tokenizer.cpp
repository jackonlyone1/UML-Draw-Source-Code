
#include "stdafx.h"
#include "Tokenizer.h"


////////////////////////////////////////////////////////////////////
// Public functions
//
CTokenizer::CTokenizer( CString strInput, const CString & strDelimiter )
{

	Init(strInput, strDelimiter);

}

void CTokenizer::Init( const CString & strInput, const CString & strDelimiter )
{

	CString copy( strInput );
	m_stra.RemoveAll();
	int nFound = copy.Find( strDelimiter );

	while(nFound != -1)
	{
		CString strLeft;
		strLeft = copy.Left( nFound );
		copy = copy.Right( copy.GetLength() - ( nFound + 1 ) );

		m_stra.Add( strLeft );
		nFound = copy.Find( strDelimiter );
	}

	m_stra.Add( copy );

}

int CTokenizer::GetSize(  ) const
{

	return m_stra.GetSize();

}

void CTokenizer::GetAt( int nIndex, CString & str ) const
{

		if( nIndex < m_stra.GetSize() )
			str = m_stra.GetAt( nIndex );
		else
			str = _T( "" );

}

void CTokenizer::GetAt( int nIndex, int & var ) const
{

		if( nIndex < m_stra.GetSize() )
			var = _ttoi( m_stra.GetAt( nIndex ) );
		else
			var = 0;

}

void CTokenizer::GetAt( int nIndex, WORD & var ) const
{

		if( nIndex < m_stra.GetSize() )
			var = static_cast< WORD >( _ttoi( m_stra.GetAt( nIndex ) ) );
		else
			var = 0;

}

void CTokenizer::GetAt( int nIndex, double & var ) const
{

		TCHAR   *stop;
		if( nIndex < m_stra.GetSize() )
			var = _tcstod( m_stra.GetAt( nIndex ), &stop );
		else
			var = 0.0;

}

void CTokenizer::GetAt( int nIndex, DWORD & var ) const
{

		if( nIndex < m_stra.GetSize() )
			var = static_cast< DWORD >( _ttoi( m_stra.GetAt( nIndex ) ) );
		else
			var = 0;

}
