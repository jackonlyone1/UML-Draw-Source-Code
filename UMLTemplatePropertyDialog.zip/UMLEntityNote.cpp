
#include "stdafx.h"
#include "UMLEntityNote.h"
#include "Tokenizer.h"
#include "UMLEntityContainer.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

CUMLEntityNote::CUMLEntityNote()
{

	SetDefaultSize( CSize( 96, 64 ) );

	CString title;
	title.LoadString( IDS_UML_NOTE );
	SetTitle( title );

	SetType( _T( "uml_note" ) );
	SetConstraints( GetDefaultSize(), CSize( -1, -1 ) );

	SetBkColor( RGB( 223,255,223 ) );

	SetPropertyDialog( &m_dlg, CUMLNotePropertyDialog::IDD );

}

CUMLEntityNote::~CUMLEntityNote()
{

	if( m_dlg.m_hWnd )
		m_dlg.DestroyWindow();

}

CDiagramEntity* CUMLEntityNote::Clone()
{

	CUMLEntityNote* obj = new CUMLEntityNote;
	obj->Copy( this );
	return obj;

}

CDiagramEntity* CUMLEntityNote::CreateFromString( const CString& str )
{

	CUMLEntityNote* obj = new CUMLEntityNote;
	if(!obj->FromString( str ) )
	{
		delete obj;
		obj = NULL;
	}

	return obj;

}

void CUMLEntityNote::Draw( CDC* dc, CRect rect )
{

	int cutoff = round( static_cast< double >( GetMarkerSize().cx ) );

	dc->SelectStockObject( BLACK_PEN );
	CBrush bk;
	bk.CreateSolidBrush( GetBkColor() );
	dc->SelectObject( &bk );

	POINT pts[ 5 ];

	pts[ 0 ].x = rect.left;
	pts[ 0 ].y = rect.top;

	pts[ 1 ].x = rect.right - cutoff;
	pts[ 1 ].y = rect.top;

	pts[ 2 ].x = rect.right;
	pts[ 2 ].y = rect.top + cutoff;

	pts[ 3 ].x = rect.right;
	pts[ 3 ].y = rect.bottom;

	pts[ 4 ].x = rect.left;
	pts[ 4 ].y = rect.bottom;

	dc->Polygon( pts, 5 );

	dc->MoveTo( rect.right - cutoff, rect.top );
	dc->LineTo( rect.right - cutoff, rect.top + cutoff );
	dc->LineTo( rect.right, rect.top + cutoff );

	if( GetTitle().GetLength() )
	{
		CRect textRect = GetTextRect( rect );

		CFont font;
		dc->SetBkMode( OPAQUE );
		dc->SetBkColor( GetBkColor() );
		font.CreateFont( -GetFontSize(), 0,0,0,FW_NORMAL,0,0,0,0,0,0,0,0, GetFont() );
		CFont* oldfont = dc->SelectObject( &font );
		dc->DrawText( GetTitle(), textRect, DT_WORDBREAK );
		dc->SelectObject( oldfont );
	}

	dc->SelectStockObject( WHITE_BRUSH );

}

void CUMLEntityNote::SetTitle( CString title )
{

	CDiagramEntity::SetTitle( title );
	CalcRestraints();

}

CRect CUMLEntityNote::GetTextRect(  const CRect& inrect ) const
{

	CRect rect( inrect );

	int cutoff = round( static_cast< double >( GetMarkerSize().cx ) );
	rect.InflateRect( -( cutoff / 2 ), -( cutoff / 2 ) );
	rect.top += cutoff / 2 + 1;

	return rect;

}

void CUMLEntityNote::SetRect( CRect rect )
{

	CDiagramEntity::SetRect( rect );
	CalcRestraints();

}

void CUMLEntityNote::SetRect( double left, double top, double right, double bottom )
{

	CDiagramEntity::SetRect( left, top, right, bottom );
	CalcRestraints();

}

void CUMLEntityNote::CalcRestraints()
{

	CString title = GetTitle();
	if( title.GetLength() )
	{

		CDC* dc = CWnd::GetDesktopWindow()->GetDC();

		CRect rect = GetRect();
		CRect textRect = GetTextRect( rect );
		CRect newRect( textRect );
		CFont font;
		font.CreateFont( -GetFontSize(), 0,0,0,FW_NORMAL,0,0,0,0,0,0,0,0, GetFont() );
		CFont* oldfont = dc->SelectObject( &font );
		dc->DrawText( GetTitle(), newRect, DT_WORDBREAK | DT_CALCRECT );
		dc->SelectObject( oldfont );
		CWnd::GetDesktopWindow()->ReleaseDC( dc );

		int diff = newRect.Height() - textRect.Height();
		rect.bottom += diff;
		int totalheight = max( GetMinimumSize().cy, rect.Height() );
		int totalwidth = GetMinimumSize().cx;
		CUMLEntityContainer* container = GetUMLContainer();
		if( container )
		{
			CSize sz = container->CalcMinimumRestraints( GetName() );
			if( sz.cx > totalheight )
				totalheight = sz.cx;
			if( sz.cy > totalwidth )
				totalwidth = sz.cy;
		}

		int steps = round( static_cast< double >( totalheight ) / 8 );
		totalheight = steps * 8;
		steps = round( static_cast< double >( totalwidth ) / 8 );
		totalwidth = steps * 8;

		if( GetMinimumSize().cy != totalheight || GetMinimumSize().cx != totalwidth )
		{
			SetMinimumSize( CSize( totalwidth, totalheight ) );
			CRect rc = GetRect();
			if( rc.Height() < totalheight || rc.Width() < totalwidth )
			{
				totalheight = max( totalheight, rc.Height() );
				totalwidth = max( totalwidth, rc.Width() );
				SetRect( GetLeft(), GetTop(), GetLeft() + totalwidth, GetTop() + totalheight );
				if( container )
					container->AdjustLinkedObjects( this );
			}
		}
		else
			SetMinimumSize( GetDefaultSize() );

	}

}

CString CUMLEntityNote::Export( UINT format ) const
{

	CString result;

	switch( format )
	{
		case EXPORT_HTML:
			result = ExportHTML();
			break;
	}

	return result;

}

CString CUMLEntityNote::ExportHTML() const
{

	CString result;
	CRect rect = GetRect();

	int font_size = 12;

	CString color = ColorrefToString( GetBkColor() );

	CString title = GetTitle();
	title.Replace( _T( "<" ), _T( "&lt;" ) );
	title.Replace( _T( ">" ), _T( "&gt;" ) );
	title.Replace( _T( "\r\n" ), _T( "<br>" ) );

	result.Format( _T( "<div style='position:absolute;left:%i;top:%i;width:%i;height:%i;border:1px solid black;background-color:#%s;'><div style='position:absolute;left:%i;top:-1;width:9:height:9;background-image:url(\"images/note.gif\");background-repeat:no-repeat;'>&nbsp;&nbsp;&nbsp;&nbsp;</div><div style='position:absolute;left:1;top:10;width:%i;height:%i;font-size:%i;font-family:%s;text-align:left;overflow:hidden;'>%s</div></div>" ),
		rect.left,rect.top,rect.Width(),rect.Height(),color,rect.Width()-10,rect.Width()-2,rect.Height()-11,font_size, GetFont(), title );

	return result;

}
