// UMLSample.h : main header file for the UMLSAMPLE application
//

#if !defined(AFX_UMLSAMPLE_H__B84EF595_D93A_4562_B58F_826C8AA3C771__INCLUDED_)
#define AFX_UMLSAMPLE_H__B84EF595_D93A_4562_B58F_826C8AA3C771__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CUMLSampleApp:
// See UMLSample.cpp for the implementation of this class
//

 
//===========================================================================
// Summary:
//     The CUMLSampleApp class derived from CWinApp
//      U M L Sample Application
//===========================================================================

class CUMLSampleApp : public CWinApp
{
public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// U M L Sample Application, Constructs a CUMLSampleApp object.
	//		Returns A  value.
	CUMLSampleApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CUMLSampleApp)
	public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Initial Instance, Override to perform Windows instance initialization, such as creating your window objects.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns TRUE on success; FALSE otherwise.
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL
 
	// Document Template, This member maintains a pointer to the object CMultiDocTemplate.  
	CMultiDocTemplate* m_pDocTemplate;
// Implementation
	//{{AFX_MSG(CUMLSampleApp)
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Application About, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnAppAbout();
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ M E S S A G E_ M A P, None Description.
	//		Returns A  value.
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_UMLSAMPLE_H__B84EF595_D93A_4562_B58F_826C8AA3C771__INCLUDED_)
