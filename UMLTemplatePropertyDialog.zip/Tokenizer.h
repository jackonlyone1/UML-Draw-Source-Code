#ifndef _CTOKENIZER_H_9BBD5DD2_819A_40CE_92574222C14D
#define _CTOKENIZER_H_9BBD5DD2_819A_40CE_92574222C14D

 
//===========================================================================
// Summary:
//      To use a CTokenizer object, just call the constructor.
//      Tokenizer
//===========================================================================

class CTokenizer
{
public:
// Construction/destruction
	
	//-----------------------------------------------------------------------
	// Summary:
	// Tokenizer, Constructs a CTokenizer object.
	//		Returns A  value.  
	// Parameters:
	//		strInput---Input, Specifies A CString type value.  
	//		strDelimiter---Delimiter, Specifies A CString type value.  
	//		")---Specifies a ") object.
	CTokenizer( CString strInput, const CString & strDelimiter = _T(",") );

// Operations
	
	//-----------------------------------------------------------------------
	// Summary:
	// Call Init after creating a new object.
	// Parameters:
	//		strInput---Input, Specifies A CString type value.  
	//		strDelimiter---Delimiter, Specifies A CString type value.  
	//		")---Specifies a ") object.
	void Init( const CString & strInput, const CString & strDelimiter = _T(",") );
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Size, Returns the specified value.
	//		Returns a int type value.  
	// Parameters:
	//		---Specifies a  object.
	int GetSize(  ) const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get At, Returns the specified value.
	// Parameters:
	//		nIndex---Index, Specifies A integer value.  
	//		str---Specifies A CString type value.
	void GetAt( int nIndex, CString & str ) const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get At, Returns the specified value.
	// Parameters:
	//		nIndex---Index, Specifies A integer value.  
	//		var---Specifies A integer value.
	void GetAt( int nIndex, int & var ) const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get At, Returns the specified value.
	// Parameters:
	//		nIndex---Index, Specifies A integer value.  
	//		var---Specifies a WORD & var object.
	void GetAt( int nIndex, WORD & var ) const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get At, Returns the specified value.
	// Parameters:
	//		nIndex---Index, Specifies A integer value.  
	//		var---Specifies a double & var object.
	void GetAt( int nIndex, double & var ) const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get At, Returns the specified value.
	// Parameters:
	//		nIndex---Index, Specifies A integer value.  
	//		var---Specifies A 32-bit unsigned integer or the address of a segment and its associated offset.
	void GetAt( int nIndex, DWORD & var ) const;


// Attributes

private:
 
	// The member supports arrays of CString objects.  
	CStringArray m_stra;


};
#endif //_CTOKENIZER_H_9BBD5DD2_819A_40CE_92574222C14D
