#if !defined(AFX_UMLLINESEGMENT_H__8BBDE424_2729_426C_89EC_B3E3E1021F92__INCLUDED_)
#define AFX_UMLLINESEGMENT_H__8BBDE424_2729_426C_89EC_B3E3E1021F92__INCLUDED_

#include "UMLEntity.h"

// Line styles
#define STYLE_NONE				0
#define STYLE_ARROWHEAD			1
#define STYLE_FILLED_ARROWHEAD	2
#define STYLE_CIRCLECROSS		4
#define STYLE_FILLED_DIAMOND	8
#define STYLE_DASHED			16
#define STYLE_INVISIBLE			32

#include "UMLLinkPropertyDialog.h"

 
//===========================================================================
// Summary:
//     The CUMLLineSegment class derived from CUMLEntity
//      U M L Line Segment
//===========================================================================

class CUMLLineSegment : public CUMLEntity
{

public:

// Creation/initialization/destruction
	
	//-----------------------------------------------------------------------
	// Summary:
	// U M L Line Segment, Constructs a CUMLLineSegment object.
	//		Returns A  value.
	CUMLLineSegment();
	
	//-----------------------------------------------------------------------
	// Summary:
	// C U M L Line Segment, Destructor of class CUMLLineSegment
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value.
	virtual ~CUMLLineSegment();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clone this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CDiagramEntity,or NULL if the call failed
	virtual	CDiagramEntity* Clone();

	
	//-----------------------------------------------------------------------
	// Summary:
	// Create From String, You construct a CUMLLineSegment object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is a static function.
	//		Returns a pointer to the object CDiagramEntity,or NULL if the call failed  
	// Parameters:
	//		str---Specifies A CString type value.
	static	CDiagramEntity* CreateFromString( const CString& str );

// Overrides
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draws current object to the specify device.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---A pointer to the CDC or NULL if the call failed.  
	//		rect---Specifies A CRect type value.
	virtual void		Draw( CDC* dc, CRect rect );
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Hit Code, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.  
	// Parameters:
	//		point---Specifies A CPoint type value.
	virtual int			GetHitCode( CPoint point ) const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Cursor, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A HCURSOR value.  
	// Parameters:
	//		hit---Specifies A integer value.
	virtual HCURSOR		GetCursor( int hit ) const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Rectangle, Sets a specify value to current class CUMLLineSegment
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		rect---Specifies A CRect type value.
	virtual void		SetRect( CRect rect );
	
	//-----------------------------------------------------------------------
	// Summary:
	// Body In Rectangle, None Description.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns TRUE on success; FALSE otherwise.  
	// Parameters:
	//		rect---Specifies A CRect type value.
	virtual BOOL		BodyInRect( CRect rect ) const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Link Position, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CPoint type value.  
	// Parameters:
	//		type---Specifies A integer value.
	virtual CPoint		GetLinkPosition( int type ) const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get String, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CString type value.
	virtual CString		GetString() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// From String, None Description.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns TRUE on success; FALSE otherwise.  
	// Parameters:
	//		str---Specifies A CString type value.
	virtual BOOL		FromString( const CString& str );
	
	//-----------------------------------------------------------------------
	// Summary:
	// None Description.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CString type value.  
	// Parameters:
	//		format---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual CString		Export( UINT format = 0 ) const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Message, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns TRUE on success; FALSE otherwise.  
	// Parameters:
	//		msg---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		sender---A pointer to the CDiagramEntity or NULL if the call failed.  
	//		from---A pointer to the CWnd or NULL if the call failed.
	virtual BOOL		DoMessage( UINT msg, CDiagramEntity* sender, CWnd* from );
	
	//-----------------------------------------------------------------------
	// Summary:
	// Show Popup, Call this function to show the specify object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		point---Specifies A CPoint type value.  
	//		parent---A pointer to the CWnd or NULL if the call failed.
	virtual void		ShowPopup( CPoint point, CWnd* parent );
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Rectangle, Sets a specify value to current class CUMLLineSegment
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		left---Specifies a double left object.  
	//		top---Specifies a double top object.  
	//		right---Specifies a double right object.  
	//		bottom---Specifies a double bottom object.
	virtual void		SetRect( double left, double top, double right, double bottom );
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create a duplicate copy of this object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		obj---A pointer to the CDiagramEntity or NULL if the call failed.
	virtual void		Copy( CDiagramEntity* obj );

	// Link style
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Style, Sets a specify value to current class CUMLLineSegment
	// Parameters:
	//		style---Specifies A integer value.
	void				SetStyle( int style );
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Style, Returns the specified value.
	//		Returns a int type value.
	int					GetStyle() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Line Style, Sets a specify value to current class CUMLLineSegment
	// Parameters:
	//		style---Specifies A integer value.
	void				SetLineStyle( int style );
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Line Style, Adds an object to the specify list.
	// Parameters:
	//		style---Specifies A integer value.
	void				AddLineStyle( int style );
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Line Style, Returns the specified value.
	//		Returns a int type value.
	int					GetLineStyle() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove Line Style, Call this function to remove a specify value from the specify object.
	// Parameters:
	//		style---Specifies A integer value.
	void				RemoveLineStyle( int style );

	// Other line information
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Horizontal, Determines if the given value is correct or exist.
	//		Returns TRUE on success; FALSE otherwise.
	BOOL				IsHorizontal() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Single Line Segment, Determines if the given value is correct or exist.
	//		Returns TRUE on success; FALSE otherwise.
	BOOL				IsSingleLineSegment() const;

	// Accessors
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Start Label, Returns the specified value.
	//		Returns a CString type value.
	CString				GetStartLabel() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Start Label, Sets a specify value to current class CUMLLineSegment
	// Parameters:
	//		label---Specifies A CString type value.
	void				SetStartLabel( const CString& label );
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get End Label, Returns the specified value.
	//		Returns a CString type value.
	CString				GetEndLabel() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set End Label, Sets a specify value to current class CUMLLineSegment
	// Parameters:
	//		label---Specifies A CString type value.
	void				SetEndLabel( const CString& label );
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Secondary Start Label, Returns the specified value.
	//		Returns a CString type value.
	CString				GetSecondaryStartLabel() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Secondary Start Label, Sets a specify value to current class CUMLLineSegment
	// Parameters:
	//		label---Specifies A CString type value.
	void				SetSecondaryStartLabel( const CString& label );
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Secondary End Label, Returns the specified value.
	//		Returns a CString type value.
	CString				GetSecondaryEndLabel() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Secondary End Label, Sets a specify value to current class CUMLLineSegment
	// Parameters:
	//		label---Specifies A CString type value.
	void				SetSecondaryEndLabel( const CString& label );


	// Links
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Link, Sets a specify value to current class CUMLLineSegment
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		type---Specifies A integer value.  
	//		name---Specifies A CString type value.
	virtual void		SetLink( int type, const CString& name );
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Link Type, Sets a specify value to current class CUMLLineSegment
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		type---Specifies A integer value.  
	//		targetType---Type, Specifies A integer value.
	virtual void		SetLinkType( int type, int targetType );
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Link, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CString type value.  
	// Parameters:
	//		type---Specifies A integer value.
	virtual CString		GetLink( int type ) const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Link Type, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.  
	// Parameters:
	//		type---Specifies A integer value.
	virtual int			GetLinkType( int type ) const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Link Code, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.  
	// Parameters:
	//		point---Specifies A CPoint type value.
	virtual int			GetLinkCode( CPoint point ) const;

	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Offset, Returns the specified value.
	//		Returns a int type value.  
	// Parameters:
	//		type---Specifies A integer value.
	int					GetOffset( int type ) const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Offset, Sets a specify value to current class CUMLLineSegment
	// Parameters:
	//		type---Specifies A integer value.  
	//		linkOffset---Offset, Specifies A integer value.
	void				SetOffset( int type, int linkOffset );

	// Operations
	
	//-----------------------------------------------------------------------
	// Summary:
	// None Description.

	void				Flip();

protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Selection Markers, Draws current object to the specify device.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---A pointer to the CDC or NULL if the call failed.  
	//		rect---Specifies A CRect type value.
	virtual void		DrawSelectionMarkers( CDC* dc, CRect rect ) const;

private:

	// Line style
 
	// This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int			m_style;

	// Labels
 
	// Label, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString		m_startLabel;
 
	// Label, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString		m_endLabel;
 
	// Start Label, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString		m_secondaryStartLabel;
 
	// End Label, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString		m_secondaryEndLabel;	

 
	// You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString		m_start;				// Object linked to the start
 
	// You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString		m_end;					// Object linked to the end

 
	// Type, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int			m_startType;			// Type of link at the start
 
	// Type, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int 		m_endType;				// Type of link at the end

 
	// Offset, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int			m_startOffset;			// Offset from top/left at the start
 
	// Offset, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int			m_endOffset;			// Offset from top/left at the end

 
	// This member specify CUMLLinkPropertyDialog object.  
	CUMLLinkPropertyDialog	m_dlg;		// Property dialog

	// HTML export functions
	
	//-----------------------------------------------------------------------
	// Summary:
	// Export H T M L, None Description.
	//		Returns a CString type value.
	CString ExportHTML() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Arrow Head H T M L, Returns the specified value.
	//		Returns a CString type value.
	CString GetArrowHeadHTML() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Circle Cross H T M L, Returns the specified value.
	//		Returns a CString type value.
	CString GetCircleCrossHTML() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Filled Arrow Head H T M L, Returns the specified value.
	//		Returns a CString type value.
	CString GetFilledArrowHeadHTML() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Filled Diamond H T M L, Returns the specified value.
	//		Returns a CString type value.
	CString GetFilledDiamondHTML() const;

	// Drawing
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Diamond, Draws current object to the specify device.
	// Parameters:
	//		dc---A pointer to the CDC or NULL if the call failed.  
	//		rect---Specifies A CRect type value.
	void	DrawDiamond( CDC* dc, const CRect& rect );
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Inheritance Arrow, Draws current object to the specify device.
	// Parameters:
	//		dc---A pointer to the CDC or NULL if the call failed.
	void	DrawInheritanceArrow( CDC* dc );
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Direction Arrow, Draws current object to the specify device.
	// Parameters:
	//		dc---A pointer to the CDC or NULL if the call failed.
	void	DrawDirectionArrow( CDC* dc );
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Style Marker Rectangle, Returns the specified value.
	//		Returns a CPoint type value.  
	// Parameters:
	//		node---Specifies A integer value.  
	//		size---Specifies A CSize type value.
	CPoint	GetStyleMarkerRect( int node, const CSize& size ) const;

};

#endif // !defined(AFX_UMLLINESEGMENT_H__8BBDE424_2729_426C_89EC_B3E3E1021F92__INCLUDED_)
