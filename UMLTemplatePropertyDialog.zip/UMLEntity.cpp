
#include "stdafx.h"
#include "UMLEntity.h"
#include "LinkFactory.h"
#include "Tokenizer.h"
#include "StringHelpers.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

CUMLEntity::CUMLEntity()
{

	// Setting fixed size
	SetDefaultSize( CSize( 0, 0 ) );
	SetConstraints( CSize( 0, 0 ), CSize( 0, 0 ) );
	SetType( _T( "uml_entity" ) );

	SetName( CLinkFactory::GetID() );

	SetRect( 0, 0, 0, 0 );

	SetFont( _T( "Arial" ) );
	SetFontSize(12);
	SetBkColor( RGB( 255, 255, 255 ) );

	SetPackage( _T( "" ) );

	SetDisplayOptions( DISPLAY_ALL );

	m_bInit = false;
}

CUMLEntity::~CUMLEntity()
{
}

CDiagramEntity* CUMLEntity::Clone()
{

	CUMLEntity* obj = new CUMLEntity;
	obj->Copy( this );
	return obj;

}

CDiagramEntity* CUMLEntity::CreateFromString( const CString& str )
{

	CUMLEntity* obj = new CUMLEntity;
	if(!obj->FromString( str ) )
	{
		delete obj;
		obj = NULL;
	}

	return obj;

}

int CUMLEntity::GetLinkCode( CPoint point ) const
{

	int cut = 1;
	int result = LINK_NONE;
	CRect rect = GetRect();
	if( ( point.x >= rect.left && point.x <= rect.right ) && ( point.y >= rect.top - cut && point.y <= rect.top + cut ) )
		result = LINK_TOP;
	if( ( point.x >= rect.left && point.x <= rect.right ) && ( point.y >= rect.bottom - cut && point.y <= rect.bottom + cut ) )
		result = LINK_BOTTOM;
	if( ( point.y >= rect.top && point.y <= rect.bottom ) && ( point.x >= rect.left - cut && point.x <= rect.left + cut ) )
		result = LINK_LEFT;
	if( ( point.y >= rect.top && point.y <= rect.bottom ) && ( point.x >= rect.right - cut && point.x <= rect.right + cut ) )
		result = LINK_RIGHT;

	return result;

}

CPoint CUMLEntity::GetLinkPosition( int type ) const
{

	CPoint point( -1, -1 );
	CRect rect = GetRect();
	switch( type )
	{
		case LINK_LEFT:
			point.x = rect.left;
			point.y = rect.top + round( static_cast< double >( rect.Height() ) / 2 );
			break;
		case LINK_RIGHT:
			point.x = rect.right;
			point.y = rect.top + round( static_cast< double >( rect.Height() ) / 2 );
			break;
		case LINK_TOP:
			point.x = rect.left + round( static_cast< double >( rect.Width() ) / 2 );
			point.y = rect.top;
			break;
		case LINK_BOTTOM:
			point.x = rect.left + round( static_cast< double >( rect.Width() ) / 2 );
			point.y = rect.bottom;
			break;
		case LINK_START:
			point.x = rect.left;
			point.y = rect.top;
			break;
		case LINK_END:
			point.x = rect.right;
			point.y = rect.bottom;
			break;
	}

	return point;

}

void CUMLEntity::Copy( CDiagramEntity* obj )
{

	CDiagramEntity::Copy( obj );

	SetName( CLinkFactory::GetID() );
	CUMLEntity* uml = static_cast< CUMLEntity* >( obj );
	if( uml )
	{

		SetPackage( uml->GetPackage() );
		SetBkColor( uml->GetBkColor() );
		SetFont( uml->GetFont() );
		SetOldId( uml->GetName() );
		SetDisplayOptions( uml->GetDisplayOptions() );

	}

}

void CUMLEntity::SetPackage( const CString& package )
{

	m_package = package;

}

CString CUMLEntity::GetPackage() const
{

	return m_package;

}

COLORREF CUMLEntity::GetBkColor() const
{
	return m_bkColor;
}

void CUMLEntity::SetBkColor( COLORREF bkColor )
{
	m_bkColor = bkColor;
}

CRect CUMLEntity::GetLinkMarkerRect( int type ) const
{

	int halfside = this->GetMarkerSize().cx / 2;
	CRect rect( -1,- 1, -1, -1 );
	CPoint point = GetLinkPosition( type );

	rect.left	= point.x - halfside;
	rect.right	= point.x + halfside;
	rect.top	= point.y - halfside;
	rect.bottom	= point.y + halfside;

	return rect;

}

void CUMLEntity::SetDefaultSize( CSize sz )
{

	m_defaultSize = sz;

}

CSize CUMLEntity::GetDefaultSize() const
{

	return m_defaultSize;

}

void CUMLEntity::SetRect( double left, double top, double right, double bottom )
{

	SetLeft( left );
	SetTop( top );
	SetRight( right );
	SetBottom( bottom );

	if( GetMinimumSize().cx != -1 )
		if( GetRect().Width() < GetMinimumSize().cx )
			SetRight( GetLeft() + GetMinimumSize().cx );

	if( GetMinimumSize().cy != -1 )
		if( GetRect().Height() < GetMinimumSize().cy )
			SetBottom( GetTop() + GetMinimumSize().cy );

	if( GetMaximumSize().cx != -1 )
		if( GetRect().Width() > GetMaximumSize().cx )
			SetRight( GetLeft() + GetMaximumSize().cx );

	if( GetMaximumSize().cy != -1 )
		if( GetRect().Height() > GetMaximumSize().cy )
			SetBottom( GetTop() + GetMaximumSize().cy );

}

void CUMLEntity::SetDisplayOptions( int displayOptions )
{

	m_displayOptions = displayOptions;
	CalcRestraints();

}

int CUMLEntity::GetDisplayOptions() const
{

	return m_displayOptions;

}

void CUMLEntity::SetOldId( const CString& oldid )
{

	m_oldid = oldid;

}

CString CUMLEntity::GetOldId() const
{

	return m_oldid;

}

void CUMLEntity::CalcRestraints()
{
	// No specific default implementation
}

CUMLEntityContainer* CUMLEntity::GetUMLContainer() const 
{

	return reinterpret_cast< CUMLEntityContainer* >( GetParent() );

}

void CUMLEntity::SetStereotype( const CString& value )
{

	m_stereotype = value;

}

CString CUMLEntity::GetStereotype() const
{

	return m_stereotype;

}

BOOL CUMLEntity::FromString( const CString& str )
{

	BOOL result = FALSE;
	CString data( str );

	if( LoadFromString( data ) )
	{
		CTokenizer tok( data );

		CString package;
		CString fontName;
		int		bkColor;
		int count = 0;

		tok.GetAt( count++, package );
		tok.GetAt( count++, fontName );
		tok.GetAt( count++, bkColor );

		UnmakeSaveString( package );

		SetPackage( package );
		SetFont( fontName );
		SetBkColor( static_cast< COLORREF >( bkColor ) );

		CalcRestraints();
		result = TRUE;
	}

	return result;

}

CString CUMLEntity::GetString() const
{

	CString str;
	CString package = GetPackage();

	MakeSaveString( package );

	str.Format( _T( ",%s,%s,%i;" ), 
			package,
			GetFont(),
			static_cast< int >( GetBkColor() )
		);

	str = GetDefaultGetString() + str;
	return str;

}

