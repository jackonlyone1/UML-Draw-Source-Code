#ifndef _CUMLENTITYDUMMY_H_60335CF6_7501_4498_854828EEA6D9
#define _CUMLENTITYDUMMY_H_60335CF6_7501_4498_854828EEA6D9


#include "UMLEntity.h"

 
//===========================================================================
// Summary:
//     The CUMLEntityDummy class derived from CUMLEntity
//      U M L Entity Dummy
//===========================================================================

class CUMLEntityDummy : public CUMLEntity
{
public:
	// Construction/destruction
	
	//-----------------------------------------------------------------------
	// Summary:
	// U M L Entity Dummy, Constructs a CUMLEntityDummy object.
	//		Returns A  value.
	CUMLEntityDummy();
	
	//-----------------------------------------------------------------------
	// Summary:
	// C U M L Entity Dummy, Destructor of class CUMLEntityDummy
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value.
	virtual ~CUMLEntityDummy();

// Operations
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Hit Code, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.  
	// Parameters:
	//		point---Specifies A CPoint type value.
	virtual int GetHitCode( CPoint point ) const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Link Code, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.  
	// Parameters:
	//		point---Specifies A CPoint type value.
	virtual int GetLinkCode( CPoint point ) const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Selected, Determines if the given value is correct or exist.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns TRUE on success; FALSE otherwise.  
	// Parameters:
	//		---Specifies a  object.
	virtual BOOL IsSelected( ) const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Call this function to select the given item.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		select---Specifies A Boolean value.
	virtual void Select( BOOL select );
	
	//-----------------------------------------------------------------------
	// Summary:
	// Body In Rectangle, None Description.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns TRUE on success; FALSE otherwise.  
	// Parameters:
	//		rect---Specifies A CRect type value.
	virtual BOOL BodyInRect( CRect rect ) const;

};

#endif //_CUMLENTITYDUMMY_H_60335CF6_7501_4498_854828EEA6D9
