#if !defined(AFX_UMLENTITY_H__8BBDE424_2729_426C_89EC_B3E3E1021F92__INCLUDED_)
#define AFX_UMLENTITY_H__8BBDE424_2729_426C_89EC_B3E3E1021F92__INCLUDED_

#include "DiagramEntity.h"
//#include "UMLPackagePropertyDialog.h"

class CUMLEntityContainer;

// Link types
#define LINK_NONE					0
#define LINK_LEFT					1
#define LINK_RIGHT					2
#define LINK_TOP					4
#define LINK_BOTTOM					8

#define LINK_ALL					15

#define LINK_START					16
#define LINK_END					32

#define CMD_OPEN					199
#define CMD_IMPORT					198
#define CMD_FLIP					197

#define DISPLAY_ALL								0
#define DISPLAY_ONLY_PUBLIC						1
#define DISPLAY_NO_MARKERS						2
#define DISPLAY_NO_ATTRIBUTES					4
#define DISPLAY_NO_OPERATIONS					8
#define DISPLAY_NO_OPERATION_ATTRIBUTE_NAMES	16

#define EXPORT_CPP					0
#define EXPORT_H					1
#define EXPORT_HTML					2

#define ENTITY_TYPE_NONE			0
#define ENTITY_TYPE_STATIC			1
#define ENTITY_TYPE_ABSTRACT		2
#define ENTITY_TYPE_VIRTUAL			4

#define ACCESS_TYPE_PRIVATE			0
#define ACCESS_TYPE_PROTECTED		1
#define ACCESS_TYPE_PUBLIC			2

 
//===========================================================================
// Summary:
//     The CUMLEntity class derived from CDiagramEntity
//      U M L Entity
//===========================================================================

class CUMLEntity : public CDiagramEntity
{

public:
// Construction/initialization/destruction
	
	//-----------------------------------------------------------------------
	// Summary:
	// U M L Entity, Constructs a CUMLEntity object.
	//		Returns A  value.
	CUMLEntity();
	
	//-----------------------------------------------------------------------
	// Summary:
	// C U M L Entity, Destructor of class CUMLEntity
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value.
	virtual	~CUMLEntity();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clone this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CDiagramEntity,or NULL if the call failed
	virtual CDiagramEntity* Clone();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create From String, You construct a CUMLEntity object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is a static function.
	//		Returns a pointer to the object CDiagramEntity,or NULL if the call failed  
	// Parameters:
	//		str---Specifies A CString type value.
	static	CDiagramEntity* CreateFromString( const CString& str );

	
	//-----------------------------------------------------------------------
	// Summary:
	// Get String, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CString type value.
	virtual CString GetString() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// From String, None Description.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns TRUE on success; FALSE otherwise.  
	// Parameters:
	//		str---Specifies A CString type value.
	virtual BOOL	FromString( const CString& str );

// Implementation
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Link Position, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CPoint type value.  
	// Parameters:
	//		type---Specifies A integer value.
	virtual CPoint	GetLinkPosition( int type ) const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Link Code, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.  
	// Parameters:
	//		point---Specifies A CPoint type value.
	virtual int		GetLinkCode( CPoint point ) const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Link Marker Rectangle, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CRect type value.  
	// Parameters:
	//		type---Specifies A integer value.
	virtual CRect	GetLinkMarkerRect( int type ) const;

	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Rectangle, Sets a specify value to current class CUMLEntity
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		left---Specifies a double left object.  
	//		top---Specifies a double top object.  
	//		right---Specifies a double right object.  
	//		bottom---Specifies a double bottom object.
	virtual void	SetRect( double left, double top, double right, double bottom );
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create a duplicate copy of this object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		obj---A pointer to the CDiagramEntity or NULL if the call failed.
	virtual void	Copy( CDiagramEntity* obj );

	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Package, Sets a specify value to current class CUMLEntity
	// Parameters:
	//		package---Specifies A CString type value.
	void			SetPackage( const CString& package );
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Package, Returns the specified value.
	//		Returns a CString type value.
	CString			GetPackage() const;

	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Background Color, Returns the specified value.
	//		Returns A 32-bit value used as a color value.
	COLORREF		GetBkColor() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Background Color, Sets a specify value to current class CUMLEntity
	// Parameters:
	//		bkColor---Color, Specifies A 32-bit value used as a color value.
	void			SetBkColor( COLORREF bkColor );
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Default Size, Returns the specified value.
	//		Returns a CSize type value.
	CSize			GetDefaultSize() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Default Size, Sets a specify value to current class CUMLEntity
	// Parameters:
	//		sz---Specifies A CSize type value.
	void			SetDefaultSize( CSize sz );

	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Display Options, Sets a specify value to current class CUMLEntity
	// Parameters:
	//		displayOptions---Options, Specifies A integer value.
	void			SetDisplayOptions( int displayOptions );
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Display Options, Returns the specified value.
	//		Returns a int type value.
	int				GetDisplayOptions() const;

	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Old Id, Sets a specify value to current class CUMLEntity
	// Parameters:
	//		oldid---Specifies A CString type value.
	void			SetOldId( const CString& oldid );
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Old Id, Returns the specified value.
	//		Returns a CString type value.
	CString			GetOldId() const;

	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Stereotype, Sets a specify value to current class CUMLEntity
	// Parameters:
	//		value---Specifies A CString type value.
	void			SetStereotype( const CString& value );
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Stereotype, Returns the specified value.
	//		Returns a CString type value.
	CString			GetStereotype() const;

	
	//-----------------------------------------------------------------------
	// Summary:
	// Calculate Restraints, None Description.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void	CalcRestraints();

	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Initial, Determines if the given value is correct or exist.
	//		Returns A Boolean value.
	bool IsInit() {return m_bInit;}

protected:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Get U M L Container, Returns the specified value.
	//		Returns a pointer to the object CUMLEntityContainer,or NULL if the call failed
	CUMLEntityContainer* GetUMLContainer() const;

private:
// Private data
 
	// You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString			m_package;
 
	// Color, This member sets A 32-bit value used as a color value.  
	COLORREF		m_bkColor;
 
	// Size, This member sets a CSize value.  
	CSize			m_defaultSize;
 
	// Options, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_displayOptions;
 
	// You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString			m_stereotype;

 
	// You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString			m_oldid;

 
	// Initial, Specify A Boolean value.  
	bool m_bInit;
};

#endif // !defined(AFX_UMLENTITY_H__8BBDE424_2729_426C_89EC_B3E3E1021F92__INCLUDED_)
