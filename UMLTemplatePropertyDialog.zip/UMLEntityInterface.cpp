
#include "stdafx.h"
#include "UMLEntityInterface.h"
#include "Tokenizer.h"
#include "UMLEntityContainer.h"
#include "StringHelpers.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

CUMLEntityInterface::CUMLEntityInterface()
{

	SetDefaultSize( CSize( 32, 32 ) );

	CString title;
	title.LoadString( IDS_UML_INTERFACE );
	SetTitle( title );

	SetType( _T( "uml_interface" ) );
	SetConstraints( GetDefaultSize(), GetDefaultSize() );

	SetBkColor( RGB( 255, 255, 217 ) );

	SetPropertyDialog( &m_dlg, CUMLInterfacePropertyDialog::IDD );

}

CUMLEntityInterface::~CUMLEntityInterface()
{

	if( m_dlg.m_hWnd )
		m_dlg.DestroyWindow();

}

CDiagramEntity* CUMLEntityInterface::Clone()
{

	CUMLEntityInterface* obj = new CUMLEntityInterface;
	obj->Copy( this );
	return obj;

}

CDiagramEntity* CUMLEntityInterface::CreateFromString( const CString& str )
{

	CUMLEntityInterface* obj = new CUMLEntityInterface;
	if(!obj->FromString( str ) )
	{
		delete obj;
		obj = NULL;
	}

	return obj;

}

void CUMLEntityInterface::Draw( CDC* dc, CRect rect )
{

	int cutoff = round( static_cast< double >( GetMarkerSize().cx ));
	int height = GetFontSize();
	dc->SelectStockObject( BLACK_PEN );
	CBrush bk;
	bk.CreateSolidBrush( GetBkColor() );
	dc->SelectObject( &bk );

	dc->Ellipse( rect );

	CString str = GetTitle();
	if( str )
	{
		CFont font;
		dc->SetBkMode( TRANSPARENT );
		font.CreateFont( -height, 0,0,0,FW_BOLD,0,0,0,0,0,0,0,0, GetFont() );
		CFont* oldfont = dc->SelectObject( &font );

		CRect textRect( rect );
		textRect.bottom = textRect.top;
		textRect.top -= round( 14.0 );

		int width = dc->GetTextExtent( str ).cx + cutoff * 2;
		int diff = width - textRect.Width();
		if( diff > 0 )
		{
			textRect.left -= diff / 2;
			textRect.right += diff / 2;
		}

		dc->DrawText( str, textRect, DT_SINGLELINE | DT_CENTER );
		dc->SelectObject( oldfont );
	}

	dc->SelectStockObject( BLACK_PEN );
	dc->SelectStockObject( WHITE_BRUSH );

}

int CUMLEntityInterface::GetLinkCode( CPoint point ) const
{

	int result = LINK_NONE;
	CRect rect;

	rect = GetLinkMarkerRect( LINK_LEFT );
	if( rect.PtInRect( point ) )
		result = LINK_LEFT;

	rect = GetLinkMarkerRect( LINK_TOP );
	if( rect.PtInRect( point ) )
		result = LINK_TOP;

	rect = GetLinkMarkerRect( LINK_RIGHT );
	if( rect.PtInRect( point ) )
		result = LINK_RIGHT;

	rect = GetLinkMarkerRect( LINK_BOTTOM );
	if( rect.PtInRect( point ) )
		result = LINK_BOTTOM;

	return result;

}

HCURSOR CUMLEntityInterface::GetCursor( int hit ) const
{

	HCURSOR cursor = LoadCursor( NULL, IDC_ARROW );
	if( hit == DEHT_BODY )
		cursor = LoadCursor( NULL, IDC_SIZEALL );

	return cursor;

}

void CUMLEntityInterface::DrawSelectionMarkers( CDC* dc, CRect rect ) const
{

	// Draw selection markers
	CRect rectSelect;

	dc->SelectStockObject( BLACK_BRUSH );
	rectSelect = GetSelectionMarkerRect( DEHT_TOPLEFT, rect );
	dc->Rectangle( rectSelect );

	rectSelect = GetSelectionMarkerRect( DEHT_TOPRIGHT, rect );
	dc->Rectangle( rectSelect );

	rectSelect = GetSelectionMarkerRect( DEHT_BOTTOMLEFT, rect );
	dc->Rectangle( rectSelect );

	rectSelect = GetSelectionMarkerRect( DEHT_BOTTOMRIGHT, rect );
	dc->Rectangle( rectSelect );

}

CString CUMLEntityInterface::Export( UINT format ) const
{

	CString result;

	if( format == EXPORT_HTML )
	{
		CRect rect = GetRect();

		int font_size = GetFontSize();
		int cut = GetMarkerSize().cx;

		CString color = ColorrefToString( GetBkColor() );

		CRect textRect( rect );
		textRect.bottom = textRect.top;
		textRect.top -= font_size + 2;

		CDC* dc = CWnd::GetDesktopWindow()->GetDC();
		CFont font;
		font.CreateFont( -font_size, 0,0,0,FW_BOLD,0,0,0,0,0,0,0,0, GetFont() );
		CFont* oldfont = dc->SelectObject( &font );
		int width = dc->GetTextExtent( GetTitle() ).cx + cut * 2;
		dc->SelectObject( oldfont );
		CWnd::GetDesktopWindow()->ReleaseDC( dc );

		int diff = width - textRect.Width();
		if( diff > 0 )
		{
			textRect.left -= diff / 2;
			textRect.right += diff / 2;
		}

		result.Format( _T( "<div style='position:absolute;left:%i;top:%i;width:32;height:32;background-color:#%s;background-image:url(\"images/interface.gif\");background-repeat:no-repeat;'>&nbsp;</div>\n<div style='position:absolute;left:%i;top:%i;width:%i;height:%i;font-family:%s;font-size:%i;font-weight:bold;text-align:center;'>%s</div>" ),
			rect.left, rect.top, color, textRect.left, textRect.top, textRect.Width(), textRect.Height(), GetFont(), font_size, GetTitle() );
	}

	return result;

}
