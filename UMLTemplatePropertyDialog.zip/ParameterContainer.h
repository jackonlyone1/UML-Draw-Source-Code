#ifndef _CPARAMETERCONTAINER_H_2B9B2375_842D_4DD1_92551EE6776
#define _CPARAMETERCONTAINER_H_2B9B2375_842D_4DD1_92551EE6776

///////////////////////////////////////////////////////////
// File :		ParameterContainer.h
// Created :	06/06/04
//
#include "Parameter.h"

 
//===========================================================================
// Summary:
//      To use a CParameterContainer object, just call the constructor.
//      Parameter Container
//===========================================================================

class CParameterContainer
{
public:
	// Construction/destruction
	
	//-----------------------------------------------------------------------
	// Summary:
	// Parameter Container, Constructs a CParameterContainer object.
	//		Returns A  value.
	CParameterContainer();
	
	//-----------------------------------------------------------------------
	// Summary:
	// C Parameter Container, Destructor of class CParameterContainer
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value.
	virtual ~CParameterContainer();

	
	//-----------------------------------------------------------------------
	// Summary:
	// None Description.
	//		Returns TRUE on success; FALSE otherwise.  
	// Parameters:
	//		parameters---Specifies a const CParameterContainer& parameters object.
	BOOL operator==( const CParameterContainer& parameters );
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create a duplicate copy of this object.
	// Parameters:
	//		parameters---Specifies a CParameterContainer& parameters object.
	void Copy( CParameterContainer& parameters );

// Operations
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Size, Returns the specified value.
	//		Returns a int type value.  
	// Parameters:
	//		---Specifies a  object.
	int GetSize( ) const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get At, Returns the specified value.
	//		Returns a pointer to the object CParameter,or NULL if the call failed  
	// Parameters:
	//		index---Specifies A integer value.
	CParameter* GetAt( int index ) const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove At, Call this function to remove a specify value from the specify object.
	// Parameters:
	//		index---Specifies A integer value.
	void RemoveAt( int index );
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove All, Call this function to remove a specify value from the specify object.
	// Parameters:
	//		---Specifies a  object.
	void RemoveAll( );
	
	//-----------------------------------------------------------------------
	// Summary:
	// Call this function to remove a specify value from the specify object.
	// Parameters:
	//		parameter---A pointer to the CParameter or NULL if the call failed.
	void Remove( CParameter* parameter );
	
	//-----------------------------------------------------------------------
	// Summary:
	// Adds an object to the specify list.
	// Parameters:
	//		parameter---A pointer to the CParameter or NULL if the call failed.
	void Add( CParameter* parameter );

	
	//-----------------------------------------------------------------------
	// Summary:
	// Get String, Returns the specified value.
	//		Returns a CString type value.  
	// Parameters:
	//		format---Specifies A integer value.
	CString GetString( int format = STRING_FORMAT_SAVE ) const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// To String, None Description.
	//		Returns a CString type value.  
	// Parameters:
	//		nooperationattributenames---Specifies A Boolean value.
	CString ToString( BOOL nooperationattributenames ) const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// From String, None Description.
	// Parameters:
	//		str---Specifies A CString type value.
	void	FromString( const CString& str );

// Attributes
private:
 
	// This member specify CObArray object.  
	CObArray m_parameters;


};

#endif //_CPARAMETERCONTAINER_H_2B9B2375_842D_4DD1_92551EE6776
