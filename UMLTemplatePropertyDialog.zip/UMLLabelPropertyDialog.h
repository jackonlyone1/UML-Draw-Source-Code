#if !defined(AFX_UMLLABELPROPERTYDIALOG_H__2FB127AA_9D6C_46CD_82AA_25DECE00338B__INCLUDED_)
#define AFX_UMLLABELPROPERTYDIALOG_H__2FB127AA_9D6C_46CD_82AA_25DECE00338B__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// UMLLabelPropertyDialog.h : header file
//

#include "DiagramPropertyDlg.h"
#include "resource.h"

/////////////////////////////////////////////////////////////////////////////
// CUMLLabelPropertyDialog dialog

 
//===========================================================================
// Summary:
//     The CUMLLabelPropertyDialog class derived from CDiagramPropertyDlg
//      U M L Label Property Dialog
//===========================================================================

class CUMLLabelPropertyDialog : public CDiagramPropertyDlg
{

// Construction
public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// U M L Label Property Dialog, Constructs a CUMLLabelPropertyDialog object.
	//		Returns A  value.  
	// Parameters:
	//		pParent---Parent, A pointer to the CWnd or NULL if the call failed.
	CUMLLabelPropertyDialog(CWnd* pParent = NULL);
	
	//-----------------------------------------------------------------------
	// Summary:
	// C U M L Label Property Dialog, Destructor of class CUMLLabelPropertyDialog
	//		Returns A  value.
	~CUMLLabelPropertyDialog();

	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Values, Sets a specify value to current class CUMLLabelPropertyDialog
	// This member function is also a virtual function, you can Override it if you need,
	virtual void SetValues();

// Dialog Data
	//{{AFX_DATA(CUMLLabelPropertyDialog)
	enum { IDD = IDD_UML_PROP_LABEL };
 
	// You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString	m_text;
	//}}AFX_DATA

// Overrides
	//{{AFX_VIRTUAL(CUMLLabelPropertyDialog)
	protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Data Exchange, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDX---D X, A pointer to the CDataExchange or NULL if the call failed.
	virtual void DoDataExchange(CDataExchange* pDX);
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CUMLLabelPropertyDialog)
	
	//-----------------------------------------------------------------------
	// Summary:
	// On O K, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void OnOK();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Cancel, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void OnCancel();
	//}}AFX_MSG
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Button Font, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnButtonFont();
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ M E S S A G E_ M A P, None Description.
	//		Returns A  value.
	DECLARE_MESSAGE_MAP()

private:

 
	// You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString		m_font;
 
	// This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int			m_pointsize;
 
	// This member sets TRUE if it is right.  
	BOOL		m_bold;
 
	// This member sets TRUE if it is right.  
	BOOL		m_italic;
 
	// This member sets TRUE if it is right.  
	BOOL		m_underline;

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_UMLLABELPROPERTYDIALOG_H__2FB127AA_9D6C_46CD_82AA_25DECE00338B__INCLUDED_)
