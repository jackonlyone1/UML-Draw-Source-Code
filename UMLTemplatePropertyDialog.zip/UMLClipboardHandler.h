
#ifndef _UMLCLIPBOARDHANDLER_H_
#define _UMLCLIPBOARDHANDLER_H_

#include "DiagramClipboardHandler.h"

 
//===========================================================================
// Summary:
//     The CUMLClipboardHandler class derived from CDiagramClipboardHandler
//      U M L Clipboard Handler
//===========================================================================

class CUMLClipboardHandler : public CDiagramClipboardHandler
{
public:
// Construction/initialization/desturction
	
	//-----------------------------------------------------------------------
	// Summary:
	// U M L Clipboard Handler, Constructs a CUMLClipboardHandler object.
	//		Returns A  value.
	CUMLClipboardHandler();
	
	//-----------------------------------------------------------------------
	// Summary:
	// C U M L Clipboard Handler, Destructor of class CUMLClipboardHandler
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value.
	virtual ~CUMLClipboardHandler();

// Overrides
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create a duplicate copy of this object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		obj---A pointer to the CDiagramEntity or NULL if the call failed.
	virtual void	Copy( CDiagramEntity* obj );
	
	//-----------------------------------------------------------------------
	// Summary:
	// Copy All Selected, Create a duplicate copy of this object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		container---A pointer to the CDiagramEntityContainer or NULL if the call failed.
	virtual void	CopyAllSelected( CDiagramEntityContainer* container );
	
	//-----------------------------------------------------------------------
	// Summary:
	// None Description.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		container---A pointer to the CDiagramEntityContainer or NULL if the call failed.
	virtual void	Paste( CDiagramEntityContainer* container );

private:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Fix Links, None Description.

	void			FixLinks();

};

#endif // _UMLCLIPBOARDHANDLER_H_
