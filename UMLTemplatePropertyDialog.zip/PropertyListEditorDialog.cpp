

#include "stdafx.h"
#include "PropertyListEditorDialog.h"
#include "Tokenizer.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPropertyListEditorDialog dialog

CPropertyListEditorDialog::CPropertyListEditorDialog(CWnd* pParent /*=NULL*/)
	: CDialog(CPropertyListEditorDialog::IDD, pParent) 
{
	//{{AFX_DATA_INIT(CPropertyListEditorDialog)
	m_tag = _T("");
	m_value = _T("");
	//}}AFX_DATA_INIT
}


void CPropertyListEditorDialog::DoDataExchange(CDataExchange* pDX) 
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPropertyListEditorDialog)
	DDX_Control(pDX, IDC_COMBO_TAG, m_tagCtrl);
	DDX_Control(pDX, IDC_LIST_TAGS, m_tags);
	DDX_Text(pDX, IDC_COMBO_TAG, m_tag);
	DDX_Text(pDX, IDC_EDIT_VALUE, m_value);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPropertyListEditorDialog, CDialog)
	//{{AFX_MSG_MAP(CPropertyListEditorDialog)
	ON_BN_CLICKED(IDC_BUTTON_ADD, OnButtonAdd)
	ON_BN_CLICKED(IDC_BUTTON_DELETE, OnButtonDelete)
	ON_BN_CLICKED(IDC_BUTTON_UPDATE, OnButtonUpdate)
	ON_BN_CLICKED(IDC_BUTTON_CLOSE, OnButtonClose)
	//}}AFX_MSG_MAP
	ON_REGISTERED_MESSAGE(rwm_EXLISTBOX_SELCHANGE, OnListboxSelChange)
	ON_REGISTERED_MESSAGE(rwm_EXLISTBOX_DELETE, OnListboxDelete)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPropertyListEditorDialog message handlers

void CPropertyListEditorDialog::OnOK()  
{

	m_container.RemoveAll();
	int max = m_tags.GetCount();
	for( int t = 0 ; t < max ; t++ )
	{
		CString tag;
		CString value;

		m_tags.GetText( t, tag );
		int tab = tag.Find( _TCHAR( '\t' ) );
		if( tab != -1 )
		{
			value = tag.Right( tag.GetLength() - ( tab + 1 ) );
			tag = tag.Left( tab );
		}

		CProperty* prop = new CProperty( tag, value );
		m_container.Add( prop );

	}

	CDialog::OnOK();
}

void CPropertyListEditorDialog::OnButtonAdd()  
{

	UpdateData();
	if( m_tag.IsEmpty() )
	{
		AfxMessageBox( IDS_UML_PROPERTY_LIST_TAG_MUST_HAVE_A_VALUE );
	}
	else
	{

		CString tag( m_tag );
		if( m_value.GetLength() )
			tag += _T( "\t" ) + m_value;
		m_tags.AddString( tag );
		m_tag = _T( "" );
		m_value = _T( "" );
		m_tagCtrl.SetFocus();
		UpdateData( FALSE );

	}
	
}

void CPropertyListEditorDialog::OnButtonDelete()  
{

	int index = m_tags.GetCurSel();
	if( index != LB_ERR )
	{

		m_tags.DeleteString( index );

		if( index < m_tags.GetCount() )
		{
			m_tags.SetCurSel( index );
			m_tags.GetText( index, m_tag );
			int tab = m_tag.Find( _TCHAR( '\t' ) );
			if( tab != -1 )
			{
				m_value = m_tag.Right( m_tag.GetLength() - ( tab + 1 ) );
				m_tag = m_tag.Left( tab );
			}

			UpdateData( FALSE );
		}
	}
	
}

void CPropertyListEditorDialog::OnButtonUpdate()  
{

	int index = m_tags.GetCurSel();
	if( index != LB_ERR )
	{
		UpdateData();

		m_tags.DeleteString( index );

		CString tag( m_tag );
		if( m_value.GetLength() )
			tag += _T( "\t" ) + m_value;
		m_tags.InsertString( index, tag );

		m_tags.SetCurSel( index );

	}	

}

BOOL CPropertyListEditorDialog::OnInitDialog()  
{

	CDialog::OnInitDialog();

	int max = m_container.GetSize();
	for( int t = 0 ; t < max ; t++ )
	{

		CProperty* prop = m_container.GetAt( t );
		CString tag( prop->key );
		if( prop->value.GetLength() )
			tag += _T( "\t" ) + prop->value;

		m_tags.AddString( tag );
		
	}

	return TRUE;

}

void CPropertyListEditorDialog::SetProperties( CPropertyContainer& container ) 
{

	m_container.Copy( container );

}

CPropertyContainer* CPropertyListEditorDialog::GetProperties() 
{

	return &m_container;

}

LRESULT CPropertyListEditorDialog::OnListboxDelete( WPARAM, LPARAM ) 
{

	OnButtonDelete();
	return 0;

}

LRESULT CPropertyListEditorDialog::OnListboxSelChange( WPARAM, LPARAM ) 
{

	int index = m_tags.GetCurSel();
	if( index != LB_ERR )
	{
		m_tags.GetText( index, m_tag );
		int tab = m_tag.Find( _TCHAR( '\t' ) );
		if( tab != -1 )
		{
			m_value = m_tag.Right( m_tag.GetLength() - ( tab + 1 ) );
			m_tag = m_tag.Left( tab );
		}
		else
			m_value = _T( "" );

		UpdateData( FALSE );

	}

	return 0;

}

void CPropertyListEditorDialog::OnButtonClose()  
{

	UpdateData();
	if( !m_tag.IsEmpty() )
		OnButtonAdd();

	OnOK();

}
