#ifndef _UMLENTITYPACKAGE_H_
#define _UMLENTITYPACKAGE_H_

#include "UMLEntity.h"
#include "UMLPackagePropertyDialog.h"

 
//===========================================================================
// Summary:
//     The CUMLEntityPackage class derived from CUMLEntity
//      U M L Entity Package
//===========================================================================

class CUMLEntityPackage : public CUMLEntity
{
public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// U M L Entity Package, Constructs a CUMLEntityPackage object.
	//		Returns A  value.
	CUMLEntityPackage();
	
	//-----------------------------------------------------------------------
	// Summary:
	// C U M L Entity Package, Destructor of class CUMLEntityPackage
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value.
	virtual ~CUMLEntityPackage();

	
	//-----------------------------------------------------------------------
	// Summary:
	// Clone this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CDiagramEntity,or NULL if the call failed
	virtual CDiagramEntity* Clone();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create From String, You construct a CUMLEntityPackage object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is a static function.
	//		Returns a pointer to the object CDiagramEntity,or NULL if the call failed  
	// Parameters:
	//		str---Specifies A CString type value.
	static	CDiagramEntity* CreateFromString( const CString& str );
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draws current object to the specify device.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---A pointer to the CDC or NULL if the call failed.  
	//		rect---Specifies A CRect type value.
	virtual void Draw( CDC* dc, CRect rect );

	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Link Position, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CPoint type value.  
	// Parameters:
	//		type---Specifies A integer value.
	virtual CPoint	GetLinkPosition( int type ) const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Show Popup, Call this function to show the specify object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		point---Specifies A CPoint type value.  
	//		parent---A pointer to the CWnd or NULL if the call failed.
	virtual void	ShowPopup( CPoint point, CWnd* parent );
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Title, Sets a specify value to current class CUMLEntityPackage
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		title---Specifies A CString type value.
	virtual void	SetTitle( CString title );
	
	//-----------------------------------------------------------------------
	// Summary:
	// None Description.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CString type value.  
	// Parameters:
	//		format---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual CString	Export( UINT format = 0 ) const;

	
	//-----------------------------------------------------------------------
	// Summary:
	// Modify Title, None Description.
	//		Returns TRUE on success; FALSE otherwise.  
	// Parameters:
	//		title---Specifies A CString type value.
	BOOL			ModifyTitle( const CString& title );
	
	//-----------------------------------------------------------------------
	// Summary:
	// Calculate Restraints, None Description.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void	CalcRestraints();

private:
 
	// This member specify CUMLPackagePropertyDialog object.  
	CUMLPackagePropertyDialog	m_dlg;

	
	//-----------------------------------------------------------------------
	// Summary:
	// Export H T M L, None Description.
	//		Returns a CString type value.
	CString			ExportHTML() const;

};

#endif //_UMLENTITYPACKAGE_H_
