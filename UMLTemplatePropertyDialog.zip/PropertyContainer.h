#ifndef _CPROPERTYCONTAINER_H_6B8221AA_8977_4557_AF6D36C93978
#define _CPROPERTYCONTAINER_H_6B8221AA_8977_4557_AF6D36C93978

#include "Property.h"

 
//===========================================================================
// Summary:
//      To use a CPropertyContainer object, just call the constructor.
//      Property Container
//===========================================================================

class CPropertyContainer 
{
public:
	// Construction/destruction
	
	//-----------------------------------------------------------------------
	// Summary:
	// Property Container, Constructs a CPropertyContainer object.
	//		Returns A  value.
	CPropertyContainer();
	
	//-----------------------------------------------------------------------
	// Summary:
	// C Property Container, Destructor of class CPropertyContainer
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value.
	virtual ~CPropertyContainer();

	
	//-----------------------------------------------------------------------
	// Summary:
	// Create a duplicate copy of this object.
	// Parameters:
	//		properties---Specifies a CPropertyContainer& properties object.
	void Copy( CPropertyContainer& properties );

// Operations
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Size, Returns the specified value.
	//		Returns a int type value.  
	// Parameters:
	//		---Specifies a  object.
	int			GetSize( ) const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get At, Returns the specified value.
	//		Returns a pointer to the object CProperty,or NULL if the call failed  
	// Parameters:
	//		index---Specifies A integer value.
	CProperty*	GetAt( int index ) const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove At, Call this function to remove a specify value from the specify object.
	// Parameters:
	//		index---Specifies A integer value.
	void		RemoveAt( int index );
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove All, Call this function to remove a specify value from the specify object.
	// Parameters:
	//		---Specifies a  object.
	void		RemoveAll( );
	
	//-----------------------------------------------------------------------
	// Summary:
	// Adds an object to the specify list.
	// Parameters:
	//		property---A pointer to the CProperty or NULL if the call failed.
	void		Add( CProperty* property );
	
	//-----------------------------------------------------------------------
	// Summary:
	// Adds an object to the specify list.
	// Parameters:
	//		tag---Specifies A CString type value.  
	//		val---Specifies A CString type value.
	void		Add( const CString& tag, const CString& val = _T( "" ) );
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get String, Returns the specified value.
	//		Returns a CString type value.  
	// Parameters:
	//		format---Specifies A integer value.
	CString		GetString( int format = STRING_FORMAT_SAVE ) const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// From String, None Description.
	// Parameters:
	//		str---Specifies A CString type value.
	void		FromString( const CString& str );

	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Property Value, Returns the specified property value.
	//		Returns a CString type value.  
	// Parameters:
	//		tag---Specifies A CString type value.
	CString		GetPropertyValue( const CString& tag ) const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Property Value, Sets a specify value to current class CPropertyContainer
	// Parameters:
	//		tag---Specifies A CString type value.  
	//		value---Specifies A CString type value.
	void		SetPropertyValue( const CString& tag, const CString& value );
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove Property, Call this function to remove a specify value from the specify object.
	// Parameters:
	//		tag---Specifies A CString type value.
	void		RemoveProperty( const CString& tag );

// Attributes
private:
 
	// This member specify CObArray object.  
	CObArray m_properties;

	// Private helpers
	
	//-----------------------------------------------------------------------
	// Summary:
	// Find Property, Searches the list sequentially to find the first CObject pointer matching the specified CObject pointer. 
	//		Returns a pointer to the object CProperty,or NULL if the call failed  
	// Parameters:
	//		tag---Specifies A CString type value.
	CProperty* FindProperty( const CString& tag );

};

#endif //_CPROPERTYCONTAINER_H_6B8221AA_8977_4557_AF6D36C93978
