
#include "stdafx.h"
#include "UMLClipboardHandler.h"
#include "LinkFactory.h"
#include "UMLLineSegment.h"
#include "UMLEntityContainer.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


CUMLClipboardHandler::CUMLClipboardHandler()
{
}

CUMLClipboardHandler::~CUMLClipboardHandler()
{

	ClearPaste();

}

void CUMLClipboardHandler::Copy( CDiagramEntity* obj )
{

	if( obj )
	{
		ClearPaste();
		CDiagramEntity* newobj = obj->Clone();
		newobj->Select( TRUE );
		newobj->MoveRect( 10, 10 );
		GetData()->Add( newobj );
		FixLinks();
	}

}

void CUMLClipboardHandler::CopyAllSelected( CDiagramEntityContainer* container )
{

	CDiagramClipboardHandler::CopyAllSelected( container );
	FixLinks();

}

void CUMLClipboardHandler::Paste( CDiagramEntityContainer* container )
{

	CUMLEntityContainer* objs = static_cast< CUMLEntityContainer* >( container );
	int count = GetData()->GetSize();
	CString package = objs->GetPackage();
	for( int t = 0 ; t < count ; t++ )
	{

		CUMLEntity* obj = static_cast< CUMLEntity* >( GetData()->GetAt( t ) );
		obj->SetPackage( package );

	}

	CDiagramClipboardHandler::Paste( container );
	objs->FixLinks( objs->GetData() );
	objs->DeleteDanglingLines();

}


void CUMLClipboardHandler::FixLinks()
{

	int count = GetData()->GetSize();
	for( int t = 0 ; t < count ; t++ )
	{

		CUMLEntity* obj = static_cast< CUMLEntity* >( GetData()->GetAt( t ) );
		if( obj->GetOldId().GetLength() )
		{
			for( int i = 0 ; i < count ; i++ )
			{
				if( t != i )
				{
					CUMLLineSegment* line = static_cast< CUMLLineSegment* >( GetData()->GetAt( i ) );
					if( line )
					{
						if( line->GetLink( LINK_START ) == obj->GetOldId() )
							line->SetLink( LINK_START, obj->GetName() );
						if( line->GetLink( LINK_END ) == obj->GetOldId() )
							line->SetLink( LINK_END, obj->GetName() );
					}
				}
			}

			obj->SetOldId( _T( "" ) );
		}
	}

}
