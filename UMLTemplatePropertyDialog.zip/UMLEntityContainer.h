#ifndef _UMLENTITYCONTAINER_H_
#define _UMLENTITYCONTAINER_H_

#include "DiagramEntityContainer.h"
#include "DiagramEntity.h"
#include "Tokenizer.h"
#include "UMLEntity.h"
#include "UMLLineSegment.h"
#include "UMLEntityClass.h"
#include "UMLEntityDummy.h"
#include "UMLUndoItem.h"

 
//===========================================================================
// Summary:
//     The CUMLEntityContainer class derived from CDiagramEntityContainer
//      U M L Entity Container
//===========================================================================

class CUMLEntityContainer : public CDiagramEntityContainer {

public:
// Construction/initialization/destruction
	
	//-----------------------------------------------------------------------
	// Summary:
	// U M L Entity Container, Constructs a CUMLEntityContainer object.
	//		Returns A  value.
	CUMLEntityContainer();
	
	//-----------------------------------------------------------------------
	// Summary:
	// C U M L Entity Container, Destructor of class CUMLEntityContainer
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value.
	virtual ~CUMLEntityContainer();

// Implementation

// Overrides
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove At, Call this function to remove a specify value from the specify object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		index---Specifies A integer value.
	virtual void			RemoveAt( int index );
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove All Selected, Call this function to remove a specify value from the specify object.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void			RemoveAllSelected();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get At, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CDiagramEntity,or NULL if the call failed  
	// Parameters:
	//		index---Specifies A integer value.
	virtual CDiagramEntity* GetAt( int index ) const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get String, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CString type value.
	virtual CString			GetString() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// From String, None Description.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns TRUE on success; FALSE otherwise.  
	// Parameters:
	//		str---Specifies A CString type value.
	virtual BOOL			FromString( const CString& str );
	
	//-----------------------------------------------------------------------
	// Summary:
	// None Description.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void			Undo();
	
	//-----------------------------------------------------------------------
	// Summary:
	// None Description.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void			Snapshot();
	
	//-----------------------------------------------------------------------
	// Summary:
	// None Description.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		stra---Specifies A CString type value.  
	//		format---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual void			Export( CStringArray& stra, UINT format = 0 ) const;

	// Objects
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Named Object, Returns the specified value.
	//		Returns a pointer to the object CUMLEntity,or NULL if the call failed  
	// Parameters:
	//		name---Specifies A CString type value.
	CUMLEntity*		GetNamedObject( const CString& name ) const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Titled Object, Returns the specified value.
	//		Returns a pointer to the object CUMLEntity,or NULL if the call failed  
	// Parameters:
	//		name---Specifies A CString type value.
	CUMLEntity*		GetTitledObject( const CString& name ) const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Selected Object, Returns the specified value.
	//		Returns a pointer to the object CDiagramEntity,or NULL if the call failed
	CDiagramEntity*	GetSelectedObject() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Adjust Linked Objects, None Description.
	// Parameters:
	//		in---A pointer to the CUMLEntity or NULL if the call failed.  
	//		filter---A pointer to the CUMLEntity or NULL if the call failed.
	void			AdjustLinkedObjects( CUMLEntity* in, CUMLEntity* filter = NULL );
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Object At, Returns the specified value.
	//		Returns a pointer to the object CUMLEntity,or NULL if the call failed  
	// Parameters:
	//		index---Specifies A integer value.
	CUMLEntity*		GetObjectAt( int index ) const;

	// Selection
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Select Count, Returns the specified value.
	//		Returns a int type value.
	int				GetSelectCount() const;

	// Segment iterators
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Next Segment, Returns the specified value.
	//		Returns a pointer to the object CUMLLineSegment,or NULL if the call failed  
	// Parameters:
	//		from---A pointer to the CUMLLineSegment or NULL if the call failed.
	CUMLLineSegment*	GetNextSegment( CUMLLineSegment* from ) const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Prev Segment, Returns the specified value.
	//		Returns a pointer to the object CUMLLineSegment,or NULL if the call failed  
	// Parameters:
	//		from---A pointer to the CUMLLineSegment or NULL if the call failed.
	CUMLLineSegment*	GetPrevSegment( CUMLLineSegment* from ) const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Start Segment, Returns the specified value.
	//		Returns a pointer to the object CUMLLineSegment,or NULL if the call failed  
	// Parameters:
	//		from---A pointer to the CUMLLineSegment or NULL if the call failed.
	CUMLLineSegment*	GetStartSegment( CUMLLineSegment* from ) const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get End Segment, Returns the specified value.
	//		Returns a pointer to the object CUMLLineSegment,or NULL if the call failed  
	// Parameters:
	//		from---A pointer to the CUMLLineSegment or NULL if the call failed.
	CUMLLineSegment*	GetEndSegment( CUMLLineSegment* from ) const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Start Node, Returns the specified value.
	//		Returns a pointer to the object CUMLEntity,or NULL if the call failed  
	// Parameters:
	//		from---A pointer to the CUMLLineSegment or NULL if the call failed.
	CUMLEntity*			GetStartNode( CUMLLineSegment* from ) const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get End Node, Returns the specified value.
	//		Returns a pointer to the object CUMLEntity,or NULL if the call failed  
	// Parameters:
	//		from---A pointer to the CUMLLineSegment or NULL if the call failed.
	CUMLEntity*			GetEndNode( CUMLLineSegment* from ) const;

	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Link Between, Returns the specified value.
	//		Returns a pointer to the object CUMLLineSegment,or NULL if the call failed  
	// Parameters:
	//		start---A pointer to the CUMLEntity or NULL if the call failed.  
	//		end---A pointer to the CUMLEntity or NULL if the call failed.
	CUMLLineSegment*	GetLinkBetween( CUMLEntity* start, CUMLEntity* end ) const;

	// Lines
	
	//-----------------------------------------------------------------------
	// Summary:
	// Delete Dangling Lines, Deletes the given object.

	void		DeleteDanglingLines();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Reduce Line, None Description.
	// Parameters:
	//		line---A pointer to the CUMLLineSegment or NULL if the call failed.
	void		ReduceLine( CUMLLineSegment* line );
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Default Line Style, Sets a specify value to current class CUMLEntityContainer
	// Parameters:
	//		line---A pointer to the CUMLLineSegment or NULL if the call failed.
	void		SetDefaultLineStyle( CUMLLineSegment* line );
	
	//-----------------------------------------------------------------------
	// Summary:
	// Line Selected, None Description.
	//		Returns TRUE on success; FALSE otherwise.  
	// Parameters:
	//		line---A pointer to the CUMLLineSegment or NULL if the call failed.
	BOOL		LineSelected( CUMLLineSegment* line ) const;

	// Links
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Link Selected, Determines if the given value is correct or exist.
	//		Returns TRUE on success; FALSE otherwise.
	BOOL		IsLinkSelected() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Flip Link, None Description.

	void		FlipLink();

	// Packages
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Package, Sets a specify value to current class CUMLEntityContainer
	// Parameters:
	//		package---Specifies A CString type value.
	void		SetPackage( const CString& package );
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Package, Returns the specified value.
	//		Returns a CString type value.
	CString		GetPackage() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Package Exists, None Description.
	//		Returns TRUE on success; FALSE otherwise.  
	// Parameters:
	//		name---Specifies A CString type value.  
	//		filter---A pointer to the CUMLEntity or NULL if the call failed.
	BOOL		PackageExists( const CString& name, CUMLEntity* filter );

	// Accessors
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Display Options, Sets a specify value to current class CUMLEntityContainer
	// Parameters:
	//		displayOption---Option, Specifies A integer value.
	void		SetDisplayOptions( int displayOption );
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Display Options, Returns the specified value.
	//		Returns a int type value.
	int			GetDisplayOptions() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Color, Sets a specify value to current class CUMLEntityContainer
	// Parameters:
	//		color---Specifies A 32-bit value used as a color value.
	void		SetColor( COLORREF color );
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Color, Returns the specified value.
	//		Returns A 32-bit value used as a color value.
	COLORREF	GetColor() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Project Name, Sets a specify value to current class CUMLEntityContainer
	// Parameters:
	//		value---Specifies A CString type value.
	void		SetProjectName( const CString& value );
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Project Name, Returns the specified value.
	//		Returns a CString type value.
	CString		GetProjectName() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Project Location, Sets a specify value to current class CUMLEntityContainer
	// Parameters:
	//		value---Specifies A CString type value.
	void		SetProjectLocation( const CString& value );
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Project Location, Returns the specified value.
	//		Returns a CString type value.
	CString		GetProjectLocation() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Error Message, Sets a specify value to current class CUMLEntityContainer
	// Parameters:
	//		error---Specifies A CString type value.
	void		SetErrorMessage( const CString& error );
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Error Message, Returns the specified value.
	//		Returns a CString type value.
	CString		GetErrorMessage() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Strip Leading Class Character, Sets a specify value to current class CUMLEntityContainer
	// Parameters:
	//		stripLeadingClassLetter---Leading Class Letter, Specifies A Boolean value.
	void		SetStripLeadingClassCharacter( BOOL stripLeadingClassLetter );
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Strip Leading Class Character, Returns the specified value.
	//		Returns TRUE on success; FALSE otherwise.
	BOOL		GetStripLeadingClassCharacter() const;

	// I/O
	
	//-----------------------------------------------------------------------
	// Summary:
	// Call this function to save the specify data to a file.
	// Parameters:
	//		ar---Specifies a CArchive& ar object.
	void		Save( CArchive& ar );
	
	//-----------------------------------------------------------------------
	// Summary:
	// Call this function to save the specify data to a file.
	// Parameters:
	//		filename---Specifies A CString type value.
	void		Save( CString& filename );
	
	//-----------------------------------------------------------------------
	// Summary:
	// Call this function to read a specified number of bytes from the archive.
	// Parameters:
	//		ar---Specifies a CArchive& ar object.
	void		Load( CArchive& ar );
	
	//-----------------------------------------------------------------------
	// Summary:
	// Call this function to read a specified number of bytes from the archive.
	// Parameters:
	//		filename---Specifies A CString type value.
	void		Load( CString& filename );
	
	//-----------------------------------------------------------------------
	// Summary:
	// None Description.

	void		Import();

	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Include List, Returns the specified value.
	// Parameters:
	//		inobj---A pointer to the CUMLEntityClass or NULL if the call failed.  
	//		stringarray---Specifies A CString type value.
	void		GetIncludeList( CUMLEntityClass* inobj, CStringArray& stringarray ) const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Dependency List, Returns the specified value.
	// Parameters:
	//		inobj---A pointer to the CUMLEntityClass or NULL if the call failed.  
	//		stringarray---Specifies A CString type value.
	void		GetDependencyList( CUMLEntityClass* inobj, CStringArray& stringarray ) const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Virtualize Classes, None Description.
	//		Returns TRUE on success; FALSE otherwise.
	BOOL		VirtualizeClasses();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Base Class Classes, None Description.
	//		Returns TRUE on success; FALSE otherwise.
	BOOL		BaseClassClasses();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Interfaces To Classes, Adds an object to the specify list.
	//		Returns TRUE on success; FALSE otherwise.
	BOOL		AddInterfacesToClasses();

	// Misc
	
	//-----------------------------------------------------------------------
	// Summary:
	// Fix Links, None Description.
	// Parameters:
	//		*arr---A pointer to the CObArray  or NULL if the call failed.
	void		FixLinks( CObArray *arr );
	
	//-----------------------------------------------------------------------
	// Summary:
	// Calculate Minimum Restraints, None Description.
	//		Returns a CSize type value.  
	// Parameters:
	//		name---Specifies A CString type value.
	CSize		CalcMinimumRestraints( const CString& name );
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Object Path, Returns the specified value.
	//		Returns a CString type value.  
	// Parameters:
	//		inobj---A pointer to the CUMLEntity or NULL if the call failed.
	CString		GetObjectPath( CUMLEntity* inobj ) const;

private:
// Private helpers
	
	//-----------------------------------------------------------------------
	// Summary:
	// Delete Line, Deletes the given object.
	// Parameters:
	//		from---A pointer to the CUMLLineSegment or NULL if the call failed.
	void		DeleteLine( CUMLLineSegment* from );
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Link Position, Returns the specified value.
	//		Returns a CPoint type value.  
	// Parameters:
	//		obj---A pointer to the CUMLEntity or NULL if the call failed.  
	//		line---A pointer to the CUMLLineSegment or NULL if the call failed.
	CPoint		GetLinkPosition( CUMLEntity* obj, CUMLLineSegment* line ) const;

 
	// You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString			m_package; // Current package
 
	// Options, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_displayOptions; // Current display options
 
	// This member sets A 32-bit value used as a color value.  
	COLORREF		m_color; // Current bg color
 
	// You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString			m_project; // Current project name
 
	// You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString			m_location; // Current pjoject location
 
	// Leading Class Letter, This member sets TRUE if it is right.  
	BOOL			m_stripLeadingClassLetter; // TRUE if leading char should be stripped when creating file names
 
	// This member specify CUMLEntityDummy object.  
	CUMLEntityDummy	m_dummy; // Dummy object (for objects in other packages)
 
	// You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString			m_error; // Current error, if any

	
	//-----------------------------------------------------------------------
	// Summary:
	// Export H T M L, None Description.
	// Parameters:
	//		stra---Specifies A CString type value.
	void			ExportHTML( CStringArray& stra ) const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Export C P P, None Description.

	void			ExportCPP() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Export H, None Description.

	void			ExportH() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Base Class Array, Returns the specified value.
	// Parameters:
	//		obj---A pointer to the CUMLEntityClass or NULL if the call failed.  
	//		array---Specifies A CString type value.  
	//		arrayAccess---Access, Specifies A CString type value.
	void			GetBaseClassArray( CUMLEntityClass* obj, CStringArray& array, CStringArray& arrayAccess ) const;

	
	//-----------------------------------------------------------------------
	// Summary:
	// In Classlist, None Description.
	//		Returns TRUE on success; FALSE otherwise.  
	// Parameters:
	//		name---Specifies A CString type value.  
	//		stra---Specifies A CString type value.
	BOOL			InClasslist( const CString& name,  const CStringArray& stra ) const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Class List, Returns the specified value.
	// Parameters:
	//		stra---Specifies A CString type value.
	void			GetClassList( CStringArray& stra ) const;

	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Total Height, Returns the specified value.
	//		Returns a int type value.
	int				GetTotalHeight() const;

	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Private Link, Determines if the given value is correct or exist.
	//		Returns TRUE on success; FALSE otherwise.  
	// Parameters:
	//		link---A pointer to the CUMLLineSegment or NULL if the call failed.
	BOOL			IsPrivateLink( CUMLLineSegment* link ) const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Protected Link, Determines if the given value is correct or exist.
	//		Returns TRUE on success; FALSE otherwise.  
	// Parameters:
	//		link---A pointer to the CUMLLineSegment or NULL if the call failed.
	BOOL			IsProtectedLink( CUMLLineSegment* link ) const;

};

#endif // _UMLENTITYCONTAINER_H_
