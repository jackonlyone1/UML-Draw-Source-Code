
#include "stdafx.h"
#include "UMLNotePropertyDialog.h"
#include "UMLEntityNote.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CUMLNotePropertyDialog dialog

CUMLNotePropertyDialog::CUMLNotePropertyDialog(CWnd* pParent /*=NULL*/)
	: CDiagramPropertyDlg(CUMLNotePropertyDialog::IDD, pParent)
{

	//{{AFX_DATA_INIT(CUMLNotePropertyDialog)
	m_text = _T("");
	//}}AFX_DATA_INIT

}

CUMLNotePropertyDialog::~CUMLNotePropertyDialog()
{
}

void CUMLNotePropertyDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CUMLNotePropertyDialog)
	DDX_Text(pDX, IDC_EDIT_TEXT, m_text);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CUMLNotePropertyDialog, CDialog)
	//{{AFX_MSG_MAP(CUMLNotePropertyDialog)
	ON_BN_CLICKED(IDC_BUTTON_FONT, OnButtonFont)
	ON_BN_CLICKED(IDC_BUTTON_COLOR, OnButtonColor)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CUMLNotePropertyDialog message handlers

void CUMLNotePropertyDialog::OnOK() 
{

	CUMLEntityNote* uml = static_cast< CUMLEntityNote* >( GetEntity() );

	UpdateData();
	uml->SetTitle( m_text );
	uml->SetBkColor( m_color );
	uml->SetFont( m_font );
	Redraw();
	ShowWindow( SW_HIDE );
	GetRedrawWnd()->SetFocus();

}

void CUMLNotePropertyDialog::OnCancel() 
{

	CDialog::OnCancel();
	GetRedrawWnd()->SetFocus();

}

/////////////////////////////////////////////////////////////////////////////
// CUMLNotePropertyDialog overrides

void CUMLNotePropertyDialog::SetValues() 
{

	CUMLEntityNote* uml = static_cast< CUMLEntityNote* >( GetEntity() );

	m_text = uml->GetTitle();
	m_color = uml->GetBkColor();
	m_font = uml->GetFont();

}

void CUMLNotePropertyDialog::OnButtonFont()
{

	CFont font;
	CUMLEntityNote* uml = static_cast< CUMLEntityNote* >( GetEntity() );
	font.CreatePointFont( 120, uml->GetFont() );
	LOGFONT lf;
	font.GetLogFont( &lf );
	CFontDialog	dlg( &lf );
	if( dlg.DoModal() == IDOK )
		m_font = dlg.GetFaceName();
	
}

void CUMLNotePropertyDialog::OnButtonColor() 
{

	CUMLEntityNote* uml = static_cast< CUMLEntityNote* >( GetEntity() );
	COLORREF color = uml->GetBkColor();
	CColorDialog	dlg( color );
	if( dlg.DoModal() == IDOK )
		m_color = dlg.GetColor();
	
}
