
#include "stdafx.h"
#include "UMLLineSegment.h"
#include "UMLEntityContainer.h"
#include "DiagramLine.h"
#include "Tokenizer.h"
#include "StringHelpers.h"

#include <math.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


//////////////////////////////////////////
// LineDDA callbacks from CDiagramLine
//

VOID CALLBACK HitTest( int X, int Y, LPARAM data );
VOID CALLBACK HitTestRect( int X, int Y, LPARAM data );

CUMLLineSegment::CUMLLineSegment() 
{

	SetPropertyDialog( &m_dlg, CUMLLinkPropertyDialog::IDD );

	SetLinkType( LINK_START, 0 );
	SetLinkType( LINK_END, 0 );

	SetMinimumSize( CSize( -1, -1 ) );
	SetMaximumSize( CSize( -1, -1 ) );
	SetType( _T( "uml_line" ) );
	SetTitle( _T( "" ) );
	SetStyle( 0 );
	SetStartLabel( _T( "" ) );
	SetEndLabel( _T( "" ) );

	SetOffset( LINK_START, 0 );
	SetOffset( LINK_END, 0 );

}

CUMLLineSegment::~CUMLLineSegment() 
{

	if( m_dlg.m_hWnd )
		m_dlg.DestroyWindow();

}

CDiagramEntity* CUMLLineSegment::Clone() 
{

	CUMLLineSegment* obj = new CUMLLineSegment;
	obj->Copy( this );
	return obj;

}

void CUMLLineSegment::Draw( CDC* dc, CRect rect ) 
{

	int mode = dc->SetBkMode( TRANSPARENT );

	if( !( GetStyle() & STYLE_INVISIBLE ) )
	{
		CPen pen;
		if( GetStyle() & STYLE_DASHED )
			pen.CreatePen( PS_DOT, 0, RGB( 0, 0, 0 ) );
		else
			pen.CreatePen( PS_SOLID, 0, RGB( 0, 0, 0 ) );

		CPen* oldpen = dc->SelectObject( &pen );

		// Draw line
		dc->MoveTo( rect.TopLeft() );
		dc->LineTo( rect.BottomRight() );

		dc->SelectObject( oldpen );
	}

	dc->SelectStockObject( BLACK_PEN );
	dc->SelectStockObject( BLACK_BRUSH );

	int cut = round( static_cast< double >( GetMarkerSize().cx ) / 2 );
	int cy = round( 14.0 );

	CFont font;
	font.CreateFont( -GetFontSize(), 0,0,0,FW_NORMAL,0,0,0,0,0,0,0,0, GetFont() );
	CFont* oldfont = dc->SelectObject( &font );

	/////////////////////////////////////////////////////////////
	// Draw title

	CString str = GetTitle();
	if( str.GetLength() )
	{

		CRect rectTemp( rect );
		rectTemp.NormalizeRect();
		CRect r( rect.right - cut, rect.top, rect.right - ( rectTemp.Width() + cut ), rect.bottom );
		if( IsHorizontal() )
		{
			CRect r( rect.left, rect.top - ( cy + cut ), rect.right, rect.bottom );
			r.NormalizeRect();
			dc->DrawText( str, r, DT_NOPREFIX | DT_SINGLELINE | DT_CENTER );
		}
		else
		{
			CRect r( rect.right - ( dc->GetTextExtent( str ).cx + cut * 2 ), rect.top, rect.right - cut, rect.bottom );
			r.NormalizeRect();
			dc->DrawText( str, r, DT_NOPREFIX | DT_SINGLELINE | DT_VCENTER | DT_RIGHT );
		}

	}

	/////////////////////////////////////////////////////////////
	// Draw labels

	str = GetStartLabel();
	if( str.GetLength() )
	{
		CRect rectTemp( rect );
		if( IsHorizontal() )
		{
			rectTemp.bottom = rectTemp.top - cut;
			rectTemp.top -= cy + cut;

			if( rectTemp.left < rectTemp.right )
			{
				rectTemp.left += cut;
				rectTemp.right -= cut;
				dc->DrawText( str, rectTemp, DT_NOPREFIX | DT_SINGLELINE | DT_VCENTER | DT_LEFT );
			}
			else
			{
				int temp = rectTemp.left;
				rectTemp.left = rectTemp.right + cut;
				rectTemp.right = temp - cut;
				dc->DrawText( str, rectTemp, DT_NOPREFIX | DT_SINGLELINE | DT_VCENTER | DT_RIGHT );
			}

		}
		else
		{
			rectTemp.left -= dc->GetTextExtent( str ).cx + 2 * cut;
			rectTemp.right -= cut;
			if( rectTemp.top < rectTemp.bottom )
				rectTemp.bottom = rectTemp.top + cy;
			else
			{
				rectTemp.top -= cy;
				rectTemp.bottom = rectTemp.top + cy;
			}

			dc->DrawText( str, rectTemp, DT_NOPREFIX | DT_SINGLELINE | DT_VCENTER | DT_RIGHT );
		}

	}

	str = GetSecondaryStartLabel();
	if( str.GetLength() )
	{
		CRect rectTemp( rect );
		if( IsHorizontal() )
		{
			rectTemp.bottom += cy + cut;
			rectTemp.top += cut;

			if( rectTemp.left < rectTemp.right )
			{
				rectTemp.left += cut;
				rectTemp.right -= cut;
				dc->DrawText( str, rectTemp, DT_NOPREFIX | DT_SINGLELINE | DT_VCENTER | DT_LEFT );
			}
			else
			{
				int temp = rectTemp.left;
				rectTemp.left = rectTemp.right + cut;
				rectTemp.right = temp - cut;
				dc->DrawText( str, rectTemp, DT_NOPREFIX | DT_SINGLELINE | DT_VCENTER | DT_RIGHT );
			}

		}
		else
		{
			rectTemp.right += dc->GetTextExtent( str ).cx + 2 * cut;
			rectTemp.left += cut;

			if( rectTemp.top < rectTemp.bottom )
				rectTemp.bottom = rectTemp.top + cy;
			else
			{
				rectTemp.top -= cy;
				rectTemp.bottom = rectTemp.top + cy;
			}

			dc->DrawText( str, rectTemp, DT_NOPREFIX | DT_SINGLELINE | DT_VCENTER | DT_RIGHT );
		}

	}

	str = GetEndLabel();
	if( str.GetLength() )
	{
		CRect rectTemp( rect );
		if( IsHorizontal() )
		{
			rectTemp.bottom = rectTemp.top - cut;
			rectTemp.top -= cy + cut;

			if( rectTemp.left < rectTemp.right )
			{
				rectTemp.left += cut;
				rectTemp.right -= cut;
				dc->DrawText( str, rectTemp, DT_NOPREFIX | DT_SINGLELINE | DT_VCENTER | DT_RIGHT );
			}
			else
			{
				int temp = rectTemp.left;
				rectTemp.left = rectTemp.right + cut;
				rectTemp.right = temp - cut;
				dc->DrawText( str, rectTemp, DT_NOPREFIX | DT_SINGLELINE | DT_VCENTER | DT_LEFT );
			}

		}
		else
		{
			rectTemp.left -= dc->GetTextExtent( str ).cx + 2 * cut;
			rectTemp.right -= cut;
			if( rectTemp.top < rectTemp.bottom )
				rectTemp.top = rectTemp.bottom - cy;
			else
			{
				rectTemp.top = rectTemp.bottom;
				rectTemp.bottom = rectTemp.top + cy;
			}
			dc->DrawText( str, rectTemp, DT_NOPREFIX | DT_SINGLELINE | DT_VCENTER | DT_RIGHT );
		}
	}

	str = GetSecondaryEndLabel();
	if( str.GetLength() )
	{
		CRect rectTemp( rect );
		if( IsHorizontal() )
		{
			rectTemp.bottom += cy + cut;
			rectTemp.top += cut;

			if( rectTemp.left < rectTemp.right )
			{
				rectTemp.left += cut;
				rectTemp.right -= cut;
				dc->DrawText( str, rectTemp, DT_NOPREFIX | DT_SINGLELINE | DT_VCENTER | DT_RIGHT );
			}
			else
			{
				int temp = rectTemp.left;
				rectTemp.left = rectTemp.right + cut;
				rectTemp.right = temp - cut;
				dc->DrawText( str, rectTemp, DT_NOPREFIX | DT_SINGLELINE | DT_VCENTER | DT_LEFT );
			}

		}
		else
		{
			rectTemp.right += dc->GetTextExtent( str ).cx + 2 * cut;
			rectTemp.left += cut;
			if( rectTemp.top < rectTemp.bottom )
				rectTemp.top = rectTemp.bottom - cy;
			else
			{
				rectTemp.top = rectTemp.bottom;
				rectTemp.bottom = rectTemp.top + cy;
			}
			dc->DrawText( str, rectTemp, DT_NOPREFIX | DT_SINGLELINE | DT_VCENTER | DT_RIGHT );
		}
	}

	/////////////////////////////////////////////////////////////
	// Draw markers

	int hgt = GetMarkerSize().cy / 2;
	if( GetStyle() & STYLE_FILLED_DIAMOND )
	{
		CRect diamond;

		double x2 = GetLeft();
		double x1 = GetRight();
		double y2 = GetTop();
		double y1 = GetBottom();

		if( !( GetLinkType( LINK_END ) & LINK_ALL ) && 
			( GetLinkType( LINK_START ) & LINK_ALL ) )
		{
			x2 = GetRight();
			x1 = GetLeft();
			y2 = GetBottom();
			y1 = GetTop();
		}

		if( IsHorizontal() )
		{
			diamond.left = round( x1 );
			diamond.top = round( ( y1 - hgt ) );
			diamond.bottom = diamond.top + round( hgt * 2 );
			if( x1 < x2 )
				diamond.right = diamond.left + round( hgt * 4 );
			else
				diamond.right = diamond.left - round( hgt * 4 );

			diamond.NormalizeRect();

		}
		else
		{

			diamond.top = round( y1 );
			diamond.left = round( ( x1 - hgt ) );
			diamond.right = diamond.left + round( hgt * 2 );
			if( y1 < y2 )
				diamond.bottom = diamond.top + round( hgt * 4 );
			else
				diamond.bottom = diamond.top - round( hgt * 4 );

			rect.NormalizeRect();

		}

		DrawDiamond( dc, diamond );
	}

	if( GetStyle() & STYLE_CIRCLECROSS )
	{

		CSize marker( 16, 16 );
		CPoint pos = GetStyleMarkerRect( LINK_END, marker );
		CRect circ( round( static_cast< double >( pos.x ) ), round( static_cast< double >( pos.y ) ), round( static_cast< double >( pos.x + marker.cx ) ), round( static_cast< double >( pos.y + marker.cy ) ) );

		dc->SelectStockObject( BLACK_PEN );
		dc->SelectStockObject( WHITE_BRUSH );

		dc->Ellipse( &circ );

		dc->MoveTo( circ.left + circ.Width() / 2, circ.top );
		dc->LineTo( circ.left + circ.Width() / 2, circ.bottom );

		dc->MoveTo( circ.left, circ.top + circ.Height() / 2 );
		dc->LineTo( circ.right, circ.top + circ.Height() / 2 );

	}

	if( GetStyle() & STYLE_ARROWHEAD )
		DrawInheritanceArrow( dc );

	if( GetStyle() & STYLE_FILLED_ARROWHEAD )
		DrawDirectionArrow( dc );

	/////////////////////////////////////////////////////////////
	// Cleaning up

	dc->SetBkMode( mode );
	dc->SelectObject( oldfont );
	dc->SelectStockObject( WHITE_BRUSH );

}

CDiagramEntity* CUMLLineSegment::CreateFromString( const CString& str ) 
{

	CUMLLineSegment* obj = new CUMLLineSegment;
	if(!obj->FromString( str ) )
	{
		delete obj;
		obj = NULL;
	}

	return obj;

}

int CUMLLineSegment::GetHitCode( CPoint point ) const 
{

	int result = DEHT_NONE;

	CRect rect = GetRect();

	hitParams hit;
	hit.hit = FALSE;
	hit.x = point.x;
	hit.y = point.y;

	LineDDA(	static_cast< int >( GetLeft() ), 
				static_cast< int >( GetTop() ), 
				static_cast< int >( GetRight() ), 
				static_cast< int >( GetBottom() ), 
				HitTest, 
				(LPARAM) &hit );

	if( hit.hit )
		result = DEHT_BODY;

	CRect rectTest;

	rectTest = GetSelectionMarkerRect( DEHT_TOPLEFT, rect );
	if( rectTest.PtInRect( point ) )
		result = DEHT_TOPLEFT;

	rectTest = GetSelectionMarkerRect( DEHT_BOTTOMRIGHT, rect );
	if( rectTest.PtInRect( point ) )
		result = DEHT_BOTTOMRIGHT;

	return result;

}

HCURSOR CUMLLineSegment::GetCursor( int hit ) const 
{

	HCURSOR cursor = NULL;
	switch( hit )
	{
		case DEHT_BODY:
		case DEHT_TOPLEFT:
		case DEHT_BOTTOMRIGHT:
		cursor = LoadCursor( NULL, IDC_SIZEALL );
		break;
	}

	return cursor;

}

void CUMLLineSegment::DrawSelectionMarkers( CDC* dc, CRect rect ) const 
{

	CRect rectSelect;

	dc->SelectStockObject( BLACK_PEN );
	dc->SelectStockObject( BLACK_BRUSH );

	rectSelect = GetSelectionMarkerRect( DEHT_TOPLEFT, rect );
	dc->Rectangle( rectSelect );

	rectSelect = GetSelectionMarkerRect( DEHT_BOTTOMRIGHT, rect );
	dc->Rectangle( rectSelect );


}

void CUMLLineSegment::SetRect( CRect rect ) 
{

	if( GetLeft() - GetRight() != 0 || GetTop() - GetBottom() != 0 )
	{
		if( IsHorizontal() )
		{
			if( rect.top == static_cast< int >( GetTop() ) )
				rect.bottom = rect.top;
			else
				rect.top = rect.bottom;
		}
		else
		{
			if( rect.left == static_cast< int >( GetLeft() ) )
				rect.right = rect.left;
			else
				rect.left = rect.right;
		}
	}

	SetLeft( rect.left );
	SetTop( rect.top );
	SetRight( rect.right );
	SetBottom( rect.bottom );

}

BOOL CUMLLineSegment::BodyInRect( CRect rect ) const 
{

	BOOL result = FALSE;
	hitParamsRect hit;
	hit.rect = rect;
	hit.hit = FALSE;

	LineDDA(	static_cast< int >( GetLeft() ), 
				static_cast< int >( GetTop() ), 
				static_cast< int >( GetRight() ), 
				static_cast< int >( GetBottom() ), 
				HitTestRect, 
				( LPARAM ) &hit );

	if( hit.hit )
		result = TRUE;

	return result;

}

CPoint CUMLLineSegment::GetLinkPosition( int type ) const 
{

	CPoint point( -1, -1 );
	CRect rect = GetRect();

	switch( type )
	{
		case LINK_START:
			point.x = rect.left;
			point.y = rect.top;
			break;
		case LINK_END:
			point.x = rect.right;
			point.y = rect.bottom;
			break;
	}

	return point;

}

void CUMLLineSegment::SetStyle( int style ) 
{

	m_style = style;

}

void CUMLLineSegment::SetLineStyle( int style ) 
{

	CUMLEntityContainer* objs = GetUMLContainer();
	if( objs )
	{

		CUMLLineSegment* start = objs->GetStartSegment( this );
		while( start )
		{
			start->m_style = STYLE_NONE;
			start = objs->GetNextSegment( start );
		}

		AddLineStyle( style );

	}
	else
		m_style = style;

}

void CUMLLineSegment::AddLineStyle( int style ) 
{

	CUMLEntityContainer* objs = GetUMLContainer();
	if( objs )
	{

		if( style & STYLE_FILLED_ARROWHEAD )
		{
			CUMLLineSegment* start = objs->GetStartSegment( this );
			start->m_style |= style;
		}

		if( style & STYLE_FILLED_DIAMOND || 
			style & STYLE_ARROWHEAD ||
			style & STYLE_CIRCLECROSS )
		{
			CUMLLineSegment* end = objs->GetEndSegment( this );
			end->m_style |= style;
		}

		if( style & STYLE_DASHED || style & STYLE_INVISIBLE )
		{
			CUMLLineSegment* start = objs->GetStartSegment( this );
			while( start )
			{
				start->m_style |= style;
				start = objs->GetNextSegment( start );
			}
		}
	}
	else
		m_style |= style;

}

void CUMLLineSegment::RemoveLineStyle( int style ) 
{

	CUMLEntityContainer* objs = GetUMLContainer();
	if( objs )
	{
		if( style & STYLE_FILLED_DIAMOND ||
			style & STYLE_FILLED_ARROWHEAD )
		{
			CUMLLineSegment* start = objs->GetStartSegment( this );
			start->m_style &= ~style;
		}
		if( style & STYLE_ARROWHEAD ||
			style & STYLE_CIRCLECROSS )
		{
			CUMLLineSegment* end = objs->GetEndSegment( this );
			end->m_style &= ~style;
		}

		if( style & STYLE_DASHED || style & STYLE_INVISIBLE )
		{
			CUMLLineSegment* start = objs->GetStartSegment( this );
			while( start )
			{
				start->m_style &= ~style;
				start = objs->GetNextSegment( start );
			}
		}
	}
	else
		m_style &= ~style;

}

int CUMLLineSegment::GetStyle() const 
{

	return m_style;

}

BOOL CUMLLineSegment::FromString( const CString& str ) 
{

	BOOL result = FALSE;
	CString data( str );

	if( LoadFromString( data ) )
	{

		CTokenizer tok( data );

		CString package;
		CString stereotype;

		CString startLink;
		CString endLink;

		int startLinkType;
		int endLinkType;

		CString	fontName;
		int		bkColor;

		int style;
		CString startLabel;
		CString endLabel;
		CString secondaryStartLabel;
		CString secondaryEndLabel;

		int startOffset;
		int endOffset;

		int count = 0;

		tok.GetAt( count++, package );
		tok.GetAt( count++, stereotype );
		tok.GetAt( count++, startLink );
		tok.GetAt( count++, endLink );
		tok.GetAt( count++, startLinkType );
		tok.GetAt( count++, endLinkType );
		tok.GetAt( count++, style );
		tok.GetAt( count++, fontName );
		tok.GetAt( count++, bkColor );
		tok.GetAt( count++, startLabel );
		tok.GetAt( count++, endLabel );
		tok.GetAt( count++, startOffset );
		tok.GetAt( count++, endOffset );
		tok.GetAt( count++, secondaryStartLabel );
		tok.GetAt( count++, secondaryEndLabel );

		UnmakeSaveString( startLabel );
		UnmakeSaveString( endLabel );
		UnmakeSaveString( secondaryStartLabel );
		UnmakeSaveString( secondaryEndLabel );
		UnmakeSaveString( package );
		UnmakeSaveString( stereotype );

		SetPackage( package );
		SetStereotype( stereotype );
		SetLink( LINK_START, startLink );
		SetLink( LINK_END, endLink );
		SetLinkType( LINK_START, startLinkType );
		SetLinkType( LINK_END, endLinkType );
		SetStyle( style );
		SetFont( fontName );
		SetBkColor( static_cast< COLORREF >( bkColor ) );
		SetStartLabel( startLabel );
		SetEndLabel( endLabel );
		SetOffset( LINK_START, startOffset );
		SetOffset( LINK_END, endOffset );
		SetSecondaryStartLabel( secondaryStartLabel );
		SetSecondaryEndLabel( secondaryEndLabel );

		result = TRUE;

	}

	return result;

}

CString CUMLLineSegment::GetString() const 
{

	CString str;

	CString package = GetPackage();
	CString stereotype = GetStereotype();
	CString startLabel1 = GetStartLabel();
	CString startLabel2 = GetSecondaryStartLabel();
	CString endLabel1 = GetEndLabel();
	CString endLabel2 = GetSecondaryEndLabel();

	MakeSaveString( package );
	MakeSaveString( stereotype );
	MakeSaveString( startLabel1 );
	MakeSaveString( startLabel2 );
	MakeSaveString( endLabel1 );
	MakeSaveString( endLabel2 );

	str.Format( _T( ",%s,%s,%s,%s,%i,%i,%i,%s,%i,%s,%s,%i,%i,%s,%s;" ), 
			package,
			stereotype,
			GetLink( LINK_START ), 
			GetLink( LINK_END ), 
			GetLinkType( LINK_START ), 
			GetLinkType( LINK_END ),
			GetStyle(),
			GetFont(),
			static_cast< int >( GetBkColor() ),
			startLabel1,
			endLabel1,
			GetOffset( LINK_START ),
			GetOffset( LINK_END ),
			startLabel2,
			endLabel2
		);

	str = GetDefaultGetString() + str;
	return str;

}

void CUMLLineSegment::DrawDiamond( CDC* dc, const CRect& rect ) 
{

	dc->SelectStockObject( BLACK_PEN );
	dc->SelectStockObject( BLACK_BRUSH );

	POINT pts[4];
	pts[0].x = rect.left + ( ( rect.right - rect.left ) / 2 );
	pts[0].y = rect.top;
	pts[1].x = rect.right;
	pts[1].y = rect.top + ( ( rect.bottom - rect.top ) / 2 );
	pts[2].x = pts[0].x;
	pts[2].y = rect.bottom;
	pts[3].x = rect.left;
	pts[3].y = pts[1].y;

	dc->Polygon( pts, 4 );

}

CString CUMLLineSegment::GetStartLabel() const 
{

	return m_startLabel;

}

CString CUMLLineSegment::GetEndLabel() const 
{

	return m_endLabel;

}

CString CUMLLineSegment::GetSecondaryStartLabel() const 
{

	return m_secondaryStartLabel;

}

CString CUMLLineSegment::GetSecondaryEndLabel() const 
{

	return m_secondaryEndLabel;

}

void CUMLLineSegment::SetStartLabel( const CString& label ) 
{

	m_startLabel = label;

}

void CUMLLineSegment::SetEndLabel( const CString& label ) 
{

	m_endLabel = label;

}

void CUMLLineSegment::SetSecondaryStartLabel( const CString& label ) 
{

	m_secondaryStartLabel = label;

}

void CUMLLineSegment::SetSecondaryEndLabel( const CString& label ) 
{

	m_secondaryEndLabel = label;

}

BOOL CUMLLineSegment::IsHorizontal() const 
{

	return ( GetTop() == GetBottom() );

}

void CUMLLineSegment::SetRect( double left, double top, double right, double bottom ) 
{
	if( GetLeft() - GetRight() != 0 || GetTop() - GetBottom() != 0 )
	{
		if( IsHorizontal() )
		{
			if( top == GetTop() )
				bottom = top;
			else
				top = bottom;
		}
		else
		{
			if( left == GetLeft() )
				right = left;
			else
				left = right;
		}
	}

	SetTop( top );
	SetLeft( left );
	SetRight( right );
	SetBottom( bottom );

}

void CUMLLineSegment::Copy( CDiagramEntity* obj ) 
{
 	CUMLEntity::Copy( obj );

	CUMLLineSegment* uml = static_cast< CUMLLineSegment* >( obj );
	if( uml )
	{

		SetStyle( uml->GetStyle() );
		SetStartLabel( uml->GetStartLabel() );
		SetEndLabel( uml->GetEndLabel() );
		SetOffset( LINK_START, uml->GetOffset( LINK_START ) );
		SetOffset( LINK_END, uml->GetOffset( LINK_END ) );
		SetLink( LINK_START, uml->GetLink( LINK_START ) );
		SetLink( LINK_END, uml->GetLink( LINK_END ) );
		SetLinkType( LINK_START, uml->GetLinkType( LINK_START ) );
		SetLinkType( LINK_END, uml->GetLinkType( LINK_END ) );

	}

}

int CUMLLineSegment::GetLineStyle() const 
{

	int result = m_style;
	CUMLEntityContainer* objs = GetUMLContainer();
	if( objs )
	{

		CUMLLineSegment* start = objs->GetStartSegment( ( CUMLLineSegment *const ) this );
		CUMLLineSegment* end = objs->GetEndSegment( ( CUMLLineSegment *const ) this );

		result |= start->GetStyle();
		result |= end->GetStyle();

	}

	return result;

}

void CUMLLineSegment::SetLink( int type, const CString& name ) 
{

	switch( type )
	{
		case LINK_START:
			m_start = name;
			break;
		case LINK_END:
			m_end = name;
			break;
	}

}

CString CUMLLineSegment::GetLink( int type ) const 
{

	CString result;

	switch( type )
	{
		case LINK_START:
			result = m_start;
			break;
		case LINK_END:
			result = m_end;
			break;
	}

	return result;

}

void CUMLLineSegment::SetLinkType( int type, int targetType ) 
{

	switch( type )
	{
		case LINK_START:
			m_startType = targetType;
			break;
		case LINK_END:
			m_endType = targetType;
			break;
	}

}

int CUMLLineSegment::GetLinkType( int type ) const 
{

	int result = LINK_NONE;

	switch( type )
	{
		case LINK_START:
			result = m_startType;
			break;
		case LINK_END:
			result = m_endType;
			break;
	}

	return result;

}

int CUMLLineSegment::GetOffset( int type) const 
{

	int result;

	if( type == LINK_START )
		result = m_startOffset;
	else
		result = m_endOffset;

	return result;

}

void CUMLLineSegment::SetOffset( int type, int linkOffset ) 
{

	if( type == LINK_START )
		m_startOffset = linkOffset;
	else
		m_endOffset = linkOffset;

}

int CUMLLineSegment::GetLinkCode( CPoint point ) const 
{

	int result = LINK_NONE;

	CRect rectTest;
	rectTest = GetLinkMarkerRect( LINK_START );
	if( rectTest.PtInRect( point ) )
		result = LINK_START;

	rectTest = GetLinkMarkerRect( LINK_END );
	if( rectTest.PtInRect( point ) )
		result = LINK_END;

	return result;

}

CString CUMLLineSegment::Export( UINT format ) const 
{

	CString result;

	switch( format )
	{
		case EXPORT_HTML:
			result = ExportHTML();
			break;
		case EXPORT_CPP:
			break;
		case EXPORT_H:
			break;
	}

	return result;

}

void CUMLLineSegment::Flip() 
{

	CString tempString;
	int tempInt;

	tempString = GetLink( LINK_END );
	SetLink( LINK_END, GetLink( LINK_START ) );
	SetLink( LINK_START, tempString );

	tempInt = GetLinkType( LINK_END );
	SetLinkType( LINK_END, GetLinkType( LINK_START ) );
	SetLinkType( LINK_START, tempInt );

	tempInt = GetOffset( LINK_END );
	SetOffset( LINK_END, GetOffset( LINK_START ) );
	SetOffset( LINK_START, tempInt );

	CRect rect = GetRect();
	tempInt = rect.right;
	rect.right = rect.left;
	rect.left = tempInt;

	tempInt = rect.bottom;
	rect.bottom = rect.top;
	rect.top = tempInt;

	SetRect( rect );

}

BOOL CUMLLineSegment::IsSingleLineSegment() const 
{

	BOOL result = FALSE;

	if( ( GetLinkType( LINK_START ) & LINK_ALL ) && 
		( GetLinkType( LINK_END ) & LINK_ALL ) ) 
		result = TRUE;

	return result;

}

void CUMLLineSegment::DrawDirectionArrow( CDC* dc ) 
{
	int hgt = GetMarkerSize().cy / 2;

	double x2 = GetLeft();
	double x1 = GetRight();
	double y2 = GetTop();
	double y1 = GetBottom();

	if( !( GetLinkType( LINK_START ) & LINK_ALL ) && 
		( GetLinkType( LINK_END ) & LINK_ALL ) )
	{
		x2 = GetRight();
		x1 = GetLeft();
		y2 = GetBottom();
		y1 = GetTop();
	}

	POINT pts[ 3 ];
	if( IsHorizontal() )
	{
		if( x1 < x2 )
		{
			pts[ 0 ].x = round( ( x2 - hgt * 4 ) );
			pts[ 0 ].y = round( ( y1 - hgt ) );
			pts[ 1 ].x = round( x2 );
			pts[ 1 ].y = round( y1 );
			pts[ 2 ].x = pts[ 0 ].x;
			pts[ 2 ].y = round( ( y1 + hgt ) );
		}
		else
		{
			pts[ 0 ].x = round( ( x2 + hgt * 4 ) );
			pts[ 0 ].y = round( ( y1 - hgt ) );
			pts[ 1 ].x = round( x2 );
			pts[ 1 ].y = round( y1 );
			pts[ 2 ].x = pts[ 0 ].x;
			pts[ 2 ].y = round( ( y1 + hgt ) );
		}
	}
	else
	{
		if( y1 < y2 )
		{
			pts[ 0 ].x = round( ( x2 - hgt ) );
			pts[ 0 ].y = round( ( y2 - hgt * 4 ) );

			pts[ 1 ].x = round( x2 );
			pts[ 1 ].y = round( y2 );

			pts[ 2 ].x = round( ( x2 + hgt ) );
			pts[ 2 ].y = pts[ 0 ].y;
		}
		else
		{
			pts[ 0 ].x = round( ( x2 - hgt ) );
			pts[ 0 ].y = round( ( y2 + hgt * 4 ) );

			pts[ 1 ].x = round( x2 );
			pts[ 1 ].y = round( y2 );

			pts[ 2 ].x = round( ( x2 + hgt ) );
			pts[ 2 ].y = pts[ 0 ].y;
		}
	}

	dc->SelectStockObject( BLACK_PEN );
	dc->SelectStockObject( BLACK_BRUSH );

	dc->Polygon( pts, 3 );

}

void CUMLLineSegment::DrawInheritanceArrow( CDC* dc ) 
{

	int hgt = GetMarkerSize().cy / 2;

	double x1 = GetLeft();
	double x2 = GetRight();
	double y1 = GetTop();
	double y2 = GetBottom();

	if( ( GetLinkType( LINK_START ) & LINK_ALL ) && 
		!( GetLinkType( LINK_END ) & LINK_ALL ) )
	{
		x1 = GetRight();
		x2 = GetLeft();
		y1 = GetBottom();
		y2 = GetTop();
	}

	POINT pts[ 3 ];
	if( IsHorizontal() )
	{
		if( x1 < x2 )
		{
			pts[ 0 ].x = round( ( x2 - hgt * 4 ) );
			pts[ 0 ].y = round( ( y1 - hgt ) );
			pts[ 1 ].x = round( x2 );
			pts[ 1 ].y = round( y1 );
			pts[ 2 ].x = pts[ 0 ].x;
			pts[ 2 ].y = round( ( y1 + hgt ) );
		}
		else
		{
			pts[ 0 ].x = round( ( x2 + hgt * 4 ) );
			pts[ 0 ].y = round( ( y1 - hgt ) );
			pts[ 1 ].x = round( x2 );
			pts[ 1 ].y = round( y1 );
			pts[ 2 ].x = pts[ 0 ].x;
			pts[ 2 ].y = round( ( y1 + hgt ) );
		}
	}
	else
	{
		if( y1 < y2 )
		{
			pts[ 0 ].x = round( ( x2 - hgt ) );
			pts[ 0 ].y = round( ( y2 - hgt * 4 ) );

			pts[ 1 ].x = round( x2 );
			pts[ 1 ].y = round( y2 );

			pts[ 2 ].x = round( ( x2 + hgt ) );
			pts[ 2 ].y = pts[ 0 ].y;
		}
		else
		{
			pts[ 0 ].x = round( ( x2 - hgt ) );
			pts[ 0 ].y = round( ( y2 + hgt * 4 ) );

			pts[ 1 ].x = round( x2 );
			pts[ 1 ].y = round( y2 );

			pts[ 2 ].x = round( ( x2 + hgt ) );
			pts[ 2 ].y = pts[ 0 ].y;
		}
	}

	dc->SelectStockObject( BLACK_PEN );
	dc->SelectStockObject( WHITE_BRUSH );

	dc->Polygon( pts, 3 );

}

CString CUMLLineSegment::ExportHTML() const 
{

	CString result;
	if( !( GetStyle() & STYLE_INVISIBLE ) )
	{

		CRect	rect = GetRect();
		int style = GetStyle();

		rect.NormalizeRect();
		int width = max( 1, rect.Width() );
		int height = max( 1, rect.Height() );

		CString linetype ( _T( "solid" ) );
		if( style & STYLE_DASHED )
			linetype = _T( "dashed" );

		CString orientation( _T( "left" ) );
		if( IsHorizontal() )
			orientation = _T( "top" );

		CString line;
		line.Format( _T( "border-%s:1px %s black" ), orientation, linetype );

		result.Format( _T( "<div style='position:absolute;left:%i;top:%i;width:%i;height:%i;%s;'>&nbsp;</div>" ),
							rect.left,rect.top,width,height,line);

		if( GetStyle() & STYLE_ARROWHEAD )
			result += GetArrowHeadHTML();

		if( GetStyle() & STYLE_CIRCLECROSS )
			result += GetCircleCrossHTML();

		if( GetStyle() & STYLE_FILLED_ARROWHEAD )
			result += GetFilledArrowHeadHTML();

		if( GetStyle() & STYLE_FILLED_DIAMOND )
			result += GetFilledDiamondHTML();

		// Label
		CString label;
		CDC* dc = CWnd::GetDesktopWindow()->GetDC();
		CFont font;
		font.CreateFont( -GetFontSize(), 0,0,0,FW_NORMAL,0,0,0,0,0,0,0,0, GetFont() );
		CFont* oldfont = dc->SelectObject( &font );
		CString str = GetTitle();
		int cut = GetMarkerSize().cx / 2;
		if( str.GetLength() )
		{
			CRect rectTemp = GetRect();
			rectTemp.NormalizeRect();
			CRect r( rect.right - cut, rect.top, rect.right - ( rectTemp.Width() + cut ), rect.bottom );
			if( IsHorizontal() )
			{
				CRect r( rect.left, rect.top - ( 14 + cut ), rect.right, rect.bottom );
				r.NormalizeRect();
				label.Format( _T( "<div style='position:absolute;left:%i;top:%i;width:%i;height:%i;font-family:%s;font-size:12;background-color:transparent;text-align:center;'>%s</div>" ), 
					r.left, r.top, r.Width(), r.Height(), GetFont(), str );
				result += label;
			}
			else
			{
				CRect r( rect.right - ( dc->GetTextExtent( str ).cx + cut * 2 ), rect.top, rect.right - cut, rect.bottom );
				r.NormalizeRect();
				r.top += r.Height() / 2 - 7;
				r.bottom = r.top + 14;
				label.Format( _T( "<div style='position:absolute;left:%i;top:%i;width:%i;height:%i;font-family:%s;font-size:12;background-color:transparent;text-align:right;'>%s</div>" ), 
					r.left, r.top, r.Width(), r.Height(), GetFont(), str );
				result += label;
			}

		}

		str = GetStartLabel();
		if( str.GetLength() )
		{
			CRect rectTemp = GetRect();
			if( IsHorizontal() )
			{
				rectTemp.bottom = rectTemp.top - cut;
				rectTemp.top -= 14 + cut;

				if( rectTemp.left < rectTemp.right )
				{
					rectTemp.left += cut;
					rectTemp.right -= cut;
					label.Format( _T( "<div style='position:absolute;left:%i;top:%i;width:%i;height:%i;font-family:%s;font-size:12;background-color:transparent;text-align:right;'>%s</div>" ), 
						rectTemp.left, rectTemp.top, rectTemp.Width(), rectTemp.Height(), GetFont(), str );
					result += label;
				}
				else
				{
					int temp = rectTemp.left;
					rectTemp.left = rectTemp.right + cut;
					rectTemp.right = temp - cut;
					label.Format( _T( "<div style='position:absolute;left:%i;top:%i;width:%i;height:%i;font-family:%s;font-size:12;background-color:transparent;text-align:left;'>%s</div>" ), 
						rectTemp.left, rectTemp.top, rectTemp.Width(), rectTemp.Height(), GetFont(), str );
					result += label;
				}

			}
			else
			{
				rectTemp.left -= dc->GetTextExtent( str ).cx + 2 * cut;
				rectTemp.right -= cut;
				if( rectTemp.top < rectTemp.bottom )
					rectTemp.bottom = rectTemp.top + 14;
				else
				{
					rectTemp.top -= 14;
					rectTemp.bottom = rectTemp.top + 14;
				}

				label.Format( _T( "<div style='position:absolute;left:%i;top:%i;width:%i;height:%i;font-family:%s;font-size:12;background-color:transparent;text-align:right;'>%s</div>" ), 
					rectTemp.left, rectTemp.top, rectTemp.Width(), rectTemp.Height(), GetFont(), str );
				result += label;
			}

		}

		str = GetSecondaryStartLabel();
		if( str.GetLength() )
		{
			CRect rectTemp = GetRect();
			if( IsHorizontal() )
			{
				rectTemp.bottom += 14 + cut;
				rectTemp.top += cut;

				if( rectTemp.left < rectTemp.right )
				{
					rectTemp.left += cut;
					rectTemp.right -= cut;
					label.Format( _T( "<div style='position:absolute;left:%i;top:%i;width:%i;height:%i;font-family:%s;font-size:12;background-color:transparent;text-align:right;'>%s</div>" ), 
						rectTemp.left, rectTemp.top, rectTemp.Width(), rectTemp.Height(), GetFont(), str );
					result += label;
				}
				else
				{
					int temp = rectTemp.left;
					rectTemp.left = rectTemp.right + cut;
					rectTemp.right = temp - cut;
					label.Format( _T( "<div style='position:absolute;left:%i;top:%i;width:%i;height:%i;font-family:%s;font-size:12;background-color:transparent;text-align:left;'>%s</div>" ), 
						rectTemp.left, rectTemp.top, rectTemp.Width(), rectTemp.Height(), GetFont(), str );
					result += label;
				}

			}
			else
			{
				rectTemp.right += dc->GetTextExtent( str ).cx + 2 * cut;
				rectTemp.left += cut;

				if( rectTemp.top < rectTemp.bottom )
					rectTemp.bottom = rectTemp.top + 14;
				else
				{
					rectTemp.top -= 14;
					rectTemp.bottom = rectTemp.top + 14;
				}

				label.Format( _T( "<div style='position:absolute;left:%i;top:%i;width:%i;height:%i;font-family:%s;font-size:12;background-color:transparent;text-align:right;'>%s</div>" ), 
					rectTemp.left, rectTemp.top, rectTemp.Width(), rectTemp.Height(), GetFont(), str );
				result += label;
			}

		}

		str = GetEndLabel();
		if( str.GetLength() )
		{
			CRect rectTemp = GetRect();
			if( IsHorizontal() )
			{
				rectTemp.bottom = rectTemp.top - cut;
				rectTemp.top -= 14 + cut;

				if( rectTemp.left < rectTemp.right )
				{
					rectTemp.left += cut;
					rectTemp.right -= cut;
					label.Format( _T( "<div style='position:absolute;left:%i;top:%i;width:%i;height:%i;font-family:%s;font-size:12;background-color:transparent;text-align:left;'>%s</div>" ), 
						rectTemp.left, rectTemp.top, rectTemp.Width(), rectTemp.Height(), GetFont(), str );
					result += label;
				}
				else
				{
					int temp = rectTemp.left;
					rectTemp.left = rectTemp.right + cut;
					rectTemp.right = temp - cut;
					label.Format( _T( "<div style='position:absolute;left:%i;top:%i;width:%i;height:%i;font-family:%s;font-size:12;background-color:transparent;text-align:right;'>%s</div>" ), 
						rectTemp.left, rectTemp.top, rectTemp.Width(), rectTemp.Height(), GetFont(), str );
					result += label;
				}

			}
			else
			{
				rectTemp.left -= dc->GetTextExtent( str ).cx + 2 * cut;
				rectTemp.right -= cut;
				if( rectTemp.top < rectTemp.bottom )
					rectTemp.top = rectTemp.bottom - 14;
				else
				{
					rectTemp.top = rectTemp.bottom;
					rectTemp.bottom = rectTemp.top + 14;
				}
				label.Format( _T( "<div style='position:absolute;left:%i;top:%i;width:%i;height:%i;font-family:%s;font-size:12;background-color:transparent;text-align:right;'>%s</div>" ), 
					rectTemp.left, rectTemp.top, rectTemp.Width(), rectTemp.Height(), GetFont(), str );
				result += label;
			}
		}

		str = GetSecondaryEndLabel();
		if( str.GetLength() )
		{
			CRect rectTemp = GetRect();
			if( IsHorizontal() )
			{
				rectTemp.bottom += 14 + cut;
				rectTemp.top += cut;

				if( rectTemp.left < rectTemp.right )
				{
					rectTemp.left += cut;
					rectTemp.right -= cut;
					label.Format( _T( "<div style='position:absolute;left:%i;top:%i;width:%i;height:%i;font-family:%s;font-size:12;background-color:transparent;text-align:left;'>%s</div>" ), 
						rectTemp.left, rectTemp.top, rectTemp.Width(), rectTemp.Height(), GetFont(), str );
					result += label;
				}
				else
				{
					int temp = rectTemp.left;
					rectTemp.left = rectTemp.right + cut;
					rectTemp.right = temp - cut;
					label.Format( _T( "<div style='position:absolute;left:%i;top:%i;width:%i;height:%i;font-family:%s;font-size:12;background-color:transparent;text-align:right;'>%s</div>" ), 
						rectTemp.left, rectTemp.top, rectTemp.Width(), rectTemp.Height(), GetFont(), str );
					result += label;
				}

			}
			else
			{
				rectTemp.right += dc->GetTextExtent( str ).cx + 2 * cut;
				rectTemp.left += cut;
				if( rectTemp.top < rectTemp.bottom )
					rectTemp.top = rectTemp.bottom - 14;
				else
				{
					rectTemp.top = rectTemp.bottom;
					rectTemp.bottom = rectTemp.top + 14;
				}
				label.Format( _T( "<div style='position:absolute;left:%i;top:%i;width:%i;height:%i;font-family:%s;font-size:12;background-color:transparent;text-align:right;'>%s</div>" ), 
					rectTemp.left, rectTemp.top, rectTemp.Width(), rectTemp.Height(), GetFont(), str );
				result += label;
			}
		}

		dc->SelectObject( oldfont );
		CWnd::GetDesktopWindow()->ReleaseDC( dc );
	}

	return result;

}

CString CUMLLineSegment::GetArrowHeadHTML() const 
{

	BOOL invert = TRUE;
	if( !( GetLinkType( LINK_END ) & LINK_ALL ) && 
		( GetLinkType( LINK_START ) & LINK_ALL ) )
		invert = FALSE;

	CString img;
	CRect marker = GetRect();

	int width = 0;
	int height = 0;

	CSize size( 17, 9 );
	if( IsHorizontal() )
	{
		width = size.cx;
		height = size.cy;
		if( !invert )
		{
			if( marker.right > marker.left )
				img = _T( "images/larrow.gif" );
			else
				img = _T( "images/rarrow.gif" );
		}
		else
		{
			if( marker.right < marker.left )
				img = _T( "images/larrow.gif" );
			else
				img = _T( "images/rarrow.gif" );
		}
	}
	else
	{
		width = size.cy;
		height = size.cx;
		if( !invert )
		{
			if( marker.bottom > marker.top )
				img = _T( "images/uarrow.gif" );
			else
				img = _T( "images/darrow.gif" );
		}
		else
		{
			if( marker.bottom < marker.top )
				img = _T( "images/uarrow.gif" );
			else
				img = _T( "images/darrow.gif" );
		}
	}

	CPoint pos = GetStyleMarkerRect( LINK_END, size );

	CString arrow;
	arrow.Format( _T( "<div style='position:absolute;left:%i;top:%i;width:%i;height:%i;background-image:url(\"%s\");background-repeat:no-repeat;'>&nbsp;</div>" ),
		pos.x, pos.y, width, height, img );

	return arrow;

}

CString CUMLLineSegment::GetFilledArrowHeadHTML() const 
{

	BOOL invert = FALSE;
	if( !( GetLinkType( LINK_START ) & LINK_ALL ) && 
		( GetLinkType( LINK_END ) & LINK_ALL ) )
		invert = TRUE;

	CString img;
	CRect marker = GetRect();

	int width = 0;
	int height = 0;

	CSize size( 17, 9 );
	if( IsHorizontal() )
	{
		width = size.cx;
		height = size.cy;
		if( !invert )
		{
			if( marker.right < marker.left )
				img = _T( "images/rfarrow.gif" );
			else
				img = _T( "images/lfarrow.gif" );
		}
		else
		{
			if( marker.right > marker.left )
				img = _T( "images/rfarrow.gif" );
			else
				img = _T( "images/lfarrow.gif" );
		}
	}
	else
	{
		width = size.cy;
		height = size.cx;
		if( !invert )
		{
			if( marker.bottom < marker.top )
				img = _T( "images/dfarrow.gif" );
			else
				img = _T( "images/ufarrow.gif" );
		}
		else
		{
			if( marker.bottom > marker.top )
				img = _T( "images/dfarrow.gif" );
			else
				img = _T( "images/ufarrow.gif" );
		}
	}

	CPoint pos = GetStyleMarkerRect( LINK_START, size );

	CString arrow;
	arrow.Format( _T( "<div style='position:absolute;left:%i;top:%i;width:%i;height:%i;background-image:url(\"%s\");background-repeat:no-repeat;'>&nbsp;</div>" ),
		pos.x, pos.y, width, height, img );

	return arrow;

}

CString CUMLLineSegment::GetFilledDiamondHTML() const 
{

	CString img;

	int width = 0;
	int height = 0;

	CSize size( 16, 9 );
	if( IsHorizontal() )
	{
		width = size.cx;
		height = size.cy;
		img = _T( "images/lrdiamond.gif" );
	}
	else
	{
		width = size.cy;
		height = size.cx;
		img = _T( "images/uddiamond.gif" );
	}

	CPoint pos = GetStyleMarkerRect( LINK_END, size );

	CString arrow;
	arrow.Format( _T( "<div style='position:absolute;left:%i;top:%i;width:%i;height:%i;background-image:url(\"%s\");background-repeat:no-repeat;'>&nbsp;</div>" ),
		pos.x, pos.y, width, height, img );

	return arrow;

}

CString CUMLLineSegment::GetCircleCrossHTML() const 
{

	CString img( _T( "images/partof.gif" ) );

	CSize marker( 16, 16 );
	CPoint pos = GetStyleMarkerRect( LINK_END, marker );

	CString arrow;
	arrow.Format( _T( "<div style='position:absolute;left:%i;top:%i;width:%i;height:%i;background-image:url(\"%s\");background-repeat:no-repeat;'>&nbsp;</div>" ),
		pos.x, pos.y, marker.cx, marker.cy, img );

	return arrow;

}

CPoint CUMLLineSegment::GetStyleMarkerRect( int node, const CSize& size ) const 
{

	CPoint result( 0, 0 );

	int invers = LINK_START;
	if( node == LINK_START )
		invers = LINK_END;

	// We try to find what end of the segment is 
	// really the start/end, that is the end where 
	// a non-line object is attached.
	BOOL invert = FALSE;
	if( !( GetLinkType( node ) & LINK_ALL ) && 
		( GetLinkType( invers ) & LINK_ALL ) )
		invert = TRUE;

	CRect marker = GetRect();

	int width = 0;
	int height = 0;
	int left = 0;
	int top = 0;

	if( node == LINK_END )
	{
		if( IsHorizontal() )
		{
			width = size.cx;
			height = size.cy;
			top = marker.top - height / 2;
			if( !invert )
			{
				if( marker.right < marker.left )
					left = marker.right;
				else
					left = marker.right - width;
			}
			else
			{
				if( marker.right > marker.left )
					left = marker.left;
				else
					left = marker.left - width;
			}
		}
		else
		{
			width = size.cy;
			height = size.cx;
			left = marker.left - width / 2;
			if( !invert )
			{
				if( marker.bottom < marker.top )
					top = marker.bottom;
				else
					top = marker.bottom - height;
			}
			else
			{
				if( marker.bottom > marker.top )
					top = marker.top;
				else
					top = marker.top - height;
			}
		}

		result.x = left;
		result.y = top;

	}
	else
	{
		if( IsHorizontal() )
		{
			width = size.cx;
			height = size.cy;
			top = marker.top - height / 2;
			if( !invert )
			{
				if( marker.right < marker.left )
					left = marker.left - width;
				else
					left = marker.left;
			}
			else
			{
				if( marker.right > marker.left )
					left = marker.right - width;
				else
					left = marker.right;
			}
		}
		else
		{
			width = size.cy;
			height = size.cx;
			left = marker.left - width / 2;
			if( !invert )
			{
				if( marker.bottom < marker.top )
					top = marker.top - height;
				else
					top = marker.top;
			}
			else
			{
				if( marker.bottom > marker.top )
					top = marker.bottom - height;
				else
					top = marker.bottom;
			}
		}

		result.x = left;
		result.y = top;

	}

	return result;

}

BOOL CUMLLineSegment::DoMessage( UINT msg, CDiagramEntity* sender, CWnd* from ) 
{
	BOOL result = TRUE;

	if( msg == CMD_FLIP )
		GetUMLContainer()->FlipLink();
	else
		result = CUMLEntity::DoMessage( msg, sender, from );

	return result;

}

void CUMLLineSegment::ShowPopup( CPoint point, CWnd* parent ) 
{

	CMenu menu;
	menu.LoadMenu( IDR_UML_MENU_LINK );
	menu.GetSubMenu(0)->TrackPopupMenu(TPM_LEFTALIGN | TPM_RIGHTBUTTON, point.x, point.y, parent );

}
