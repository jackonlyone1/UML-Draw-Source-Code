#if !defined(AFX_PROPERTYLISTEDITORDIALOG_H__5F0E7F1B_9386_4958_9694_D7F41CD0EA19__INCLUDED_)
#define AFX_PROPERTYLISTEDITORDIALOG_H__5F0E7F1B_9386_4958_9694_D7F41CD0EA19__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "resource.h"
#include "PropertyContainer.h"
#include "ExListBox.h"

/////////////////////////////////////////////////////////////////////////////
// CPropertyListEditorDialog dialog

 
//===========================================================================
// Summary:
//     The CPropertyListEditorDialog class derived from CDialog
//      Property List Editor Dialog
//===========================================================================

class CPropertyListEditorDialog : public CDialog
{
// Construction
public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Property List Editor Dialog, Constructs a CPropertyListEditorDialog object.
	//		Returns A  value.  
	// Parameters:
	//		pParent---Parent, A pointer to the CWnd or NULL if the call failed.
	CPropertyListEditorDialog(CWnd* pParent = NULL);

// Dialog Data
	//{{AFX_DATA(CPropertyListEditorDialog)
	enum { IDD = IDD_UML_PROP_LIST_EDITOR };
 
	// m_tag Ctrl, This member specify CEdit object.  
	CEdit	m_tagCtrl;
 
	// This member specify CExListBox object.  
	CExListBox	m_tags;
 
	// You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString	m_tag;
 
	// You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString	m_value;
	//}}AFX_DATA

	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Properties, Sets a specify value to current class CPropertyListEditorDialog
	// Parameters:
	//		container---Specifies a CPropertyContainer& container object.
	void SetProperties( CPropertyContainer& container );
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Properties, Returns the specified property value.
	//		Returns a pointer to the object CPropertyContainer,or NULL if the call failed
	CPropertyContainer* GetProperties();

// Overrides
	//{{AFX_VIRTUAL(CPropertyListEditorDialog)
	protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Data Exchange, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDX---D X, A pointer to the CDataExchange or NULL if the call failed.
	virtual void DoDataExchange(CDataExchange* pDX);
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CPropertyListEditorDialog)
	
	//-----------------------------------------------------------------------
	// Summary:
	// On O K, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void OnOK();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Button Add, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnButtonAdd();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Button Delete, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnButtonDelete();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Button Update, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnButtonUpdate();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Button Close, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnButtonClose();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Initial Dialog, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns TRUE on success; FALSE otherwise.
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Listbox Delete, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns A 32-bit value returned from a window procedure or callback function.  
	// Parameters:
	//		id---Provides additional information used in processing the message. The parameter value depends on the message.  
	//		LPARAM---P A R A M, Specifies A lparam value.
	LRESULT OnListboxDelete( WPARAM id, LPARAM );
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Listbox Sel Change, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns A 32-bit value returned from a window procedure or callback function.  
	// Parameters:
	//		id---Provides additional information used in processing the message. The parameter value depends on the message.  
	//		LPARAM---P A R A M, Specifies A lparam value.
	LRESULT	OnListboxSelChange( WPARAM id, LPARAM );

	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ M E S S A G E_ M A P, None Description.
	//		Returns A  value.
	DECLARE_MESSAGE_MAP()

private:
 
	// This member specify CPropertyContainer object.  
	CPropertyContainer	m_container;

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PROPERTYLISTEDITORDIALOG_H__5F0E7F1B_9386_4958_9694_D7F41CD0EA19__INCLUDED_)
