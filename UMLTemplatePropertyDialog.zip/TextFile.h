#ifndef _TEXTFILE_H_
#define _TEXTFILE_H_

 
//===========================================================================
// Summary:
//      To use a CTextFile object, just call the constructor.
//      Text File
//===========================================================================

class CTextFile
{

public:

	// ctor( s )
	
	//-----------------------------------------------------------------------
	// Summary:
	// Text File, Constructs a CTextFile object.
	//		Returns A  value.  
	// Parameters:
	//		ext---Specifies A CString type value.  
	//		eol---Specifies A CString type value.
	CTextFile( const CString& ext = _T( "" ), const CString& eol = _T( "\n" ) );

	// dtor
	
	//-----------------------------------------------------------------------
	// Summary:
	// C Text File, Destructor of class CTextFile
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value.
	virtual ~CTextFile();

	// File operations
	
	//-----------------------------------------------------------------------
	// Summary:
	// Read Text File, Call this function to read the specify data from an archive.
	//		Returns TRUE on success; FALSE otherwise.  
	// Parameters:
	//		filename---Specifies A CString type value.  
	//		contents---Specifies A CString type value.
	BOOL	ReadTextFile( CString& filename, CStringArray& contents );
	
	//-----------------------------------------------------------------------
	// Summary:
	// Read Text File, Call this function to read the specify data from an archive.
	//		Returns TRUE on success; FALSE otherwise.  
	// Parameters:
	//		filename---Specifies A CString type value.  
	//		contents---Specifies A CString type value.
	BOOL	ReadTextFile( CString& filename, CString& contents );

	
	//-----------------------------------------------------------------------
	// Summary:
	// Write Text File, Writes a specified number of bytes to the archive. The archive does not format the bytes.
	//		Returns TRUE on success; FALSE otherwise.  
	// Parameters:
	//		filename---Specifies A CString type value.  
	//		contents---Specifies A CString type value.
	BOOL	WriteTextFile( CString& filename, const CStringArray& contents );
	
	//-----------------------------------------------------------------------
	// Summary:
	// Write Text File, Writes a specified number of bytes to the archive. The archive does not format the bytes.
	//		Returns TRUE on success; FALSE otherwise.  
	// Parameters:
	//		filename---Specifies A CString type value.  
	//		contents---Specifies A CString type value.
	BOOL	WriteTextFile( CString& filename, const CString& contents );

	
	//-----------------------------------------------------------------------
	// Summary:
	// Append File, None Description.
	//		Returns TRUE on success; FALSE otherwise.  
	// Parameters:
	//		filename---Specifies A CString type value.  
	//		contents---Specifies A CString type value.
	BOOL	AppendFile( CString& filename, const CString& contents );
	
	//-----------------------------------------------------------------------
	// Summary:
	// Append File, None Description.
	//		Returns TRUE on success; FALSE otherwise.  
	// Parameters:
	//		filename---Specifies A CString type value.  
	//		contents---Specifies A CString type value.
	BOOL	AppendFile( CString& filename, const CStringArray& contents );

	// Window operations
	
	//-----------------------------------------------------------------------
	// Summary:
	// Call this function to read a specified number of bytes from the archive.
	//		Returns TRUE on success; FALSE otherwise.  
	// Parameters:
	//		filename---Specifies A CString type value.  
	//		edit---A pointer to the CEdit or NULL if the call failed.
	BOOL	Load( CString& filename, CEdit* edit );
	
	//-----------------------------------------------------------------------
	// Summary:
	// Call this function to read a specified number of bytes from the archive.
	//		Returns TRUE on success; FALSE otherwise.  
	// Parameters:
	//		filename---Specifies A CString type value.  
	//		list---A pointer to the CListBox or NULL if the call failed.
	BOOL	Load( CString& filename, CListBox* list );
	
	//-----------------------------------------------------------------------
	// Summary:
	// Call this function to save the specify data to a file.
	//		Returns TRUE on success; FALSE otherwise.  
	// Parameters:
	//		filename---Specifies A CString type value.  
	//		edit---A pointer to the CEdit or NULL if the call failed.
	BOOL	Save( CString& filename, CEdit* edit );
	
	//-----------------------------------------------------------------------
	// Summary:
	// Call this function to save the specify data to a file.
	//		Returns TRUE on success; FALSE otherwise.  
	// Parameters:
	//		filename---Specifies A CString type value.  
	//		list---A pointer to the CListBox or NULL if the call failed.
	BOOL	Save( CString& filename, CListBox* list );

	// Error handling
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Error Message, Returns the specified value.
	//		Returns a CString type value.
	CString GetErrorMessage();

protected:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Filename, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns TRUE on success; FALSE otherwise.  
	// Parameters:
	//		save---Specifies A Boolean value.  
	//		filename---Specifies A CString type value.
	virtual BOOL GetFilename( BOOL save, CString& filename );
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Extension, Returns the specified value.
	//		Returns a CString type value.
	CString GetExtension();

private:

 
	// You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString m_error;
 
	// You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString m_extension;
 
	// You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString m_eol;

	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear Error, Remove the specify data from the list.

	void	ClearError();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Valid Parameter, None Description.
	//		Returns TRUE on success; FALSE otherwise.  
	// Parameters:
	//		wnd---A pointer to the CWnd or NULL if the call failed.
	BOOL	ValidParam( CWnd* wnd );

};

#endif // _TEXTFILE_H_
