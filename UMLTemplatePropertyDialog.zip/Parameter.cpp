

#include "stdafx.h"
#include "Parameter.h"
#include "Tokenizer.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


// Construction/destruction
CParameter::CParameter()
{

	reference = FALSE;
	out = FALSE;
	in = TRUE;

}

CParameter::~CParameter()
{
}

CParameter::CParameter( CParameter* parameter )
{

	name = parameter->name;
	type = parameter->type;
	defaultvalue = parameter->defaultvalue;
	reference = parameter->reference;
	in = parameter->in;
	out = parameter->out;

}

// Implementation
CParameter* CParameter::FromString( const CString& str )
{

	CParameter* result = NULL;

	CTokenizer tok( str, _T( "#" ) );
	int max = tok.GetSize();
	if( max == 6 )
	{
		CString name;
		CString type;
		CString defaultvalue;
		int		reference;
		int		in;
		int		out;
		int count = 0;
		tok.GetAt( count++, name );
		tok.GetAt( count++, type );
		tok.GetAt( count++, defaultvalue );
		tok.GetAt( count++, reference );
		tok.GetAt( count++, in );
		tok.GetAt( count++, out );

		result = new CParameter;
		result->name = name;
		result->type = type;
		result->defaultvalue = defaultvalue;
		result->reference = reference;
		result->in = in;
		result->out = out;

	}

	return result;

}

CString CParameter::GetString( int format ) const
{

	CString result;

	switch( format )
	{
		case STRING_FORMAT_SAVE:

			result.Format( _T( "%s#%s#%s#%i#%i#%i" ),
					name,
					type,
					defaultvalue,
					static_cast< int >( reference ),
					static_cast< int >( in ),
					static_cast< int >( out )
				);

			break;
		case STRING_FORMAT_CPP:
			{

				result = type + _T( " " );
				if( reference )
				{
					if( out ) // alias
						result += _T( "& " );
					else // const ref
						result = _T( "const " ) + result + _T( "& " );
				}
				else
				{
					if( out ) // pointer
						result += _T( "* " );
				}

				result += name;

			}
			break;

		case STRING_FORMAT_H:
			{

				result = type + _T( " " );
				if( reference )
				{
					if( out ) // alias
						result += _T( "& " );
					else // const ref
						result = _T( "const " ) + result + _T( "& " );
				}
				else
				{
					if( out ) // pointer
						result += _T( "* " );
				}

				result += name;

				if( defaultvalue.GetLength() )
					result += _T( " = " ) + defaultvalue;

			}
			break;

		case STRING_FORMAT_UML:
			{

				if( in && out )
					result = _T( "inout " );
				else if( out )
					result = _T( "out " );

				result += name + _T( ":" ) + type;

				if( defaultvalue.GetLength() )
					result += _T( " = " ) + defaultvalue;

			}
			break;
	}

	return result;

}

CString CParameter::ToString( BOOL nooperationattributenames ) const
{

	CString result;

	if( in && out )
		result = _T( "inout " );
	else if( out )
		result = _T( "out " );

	if( !nooperationattributenames )
		result += name + _T( ":" );

	result += type;

	if( defaultvalue.GetLength() )
		result += _T( " = " ) + defaultvalue;

	return result;

}

BOOL CParameter::operator==( const CParameter& parameter )
{

	BOOL result = FALSE;

	if( type == parameter.type &&
		reference == parameter.reference &&
		in == parameter.in &&
		out == parameter.out )
		result = TRUE;

	return result;

}

BOOL CParameter::operator!=( const CParameter& parameter )
{

	return !( *this == parameter );

}
