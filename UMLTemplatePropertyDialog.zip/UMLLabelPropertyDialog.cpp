
#include "stdafx.h"
#include "UMLLabelPropertyDialog.h"
#include "UMLEntityLabel.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CUMLLabelPropertyDialog dialog

CUMLLabelPropertyDialog::CUMLLabelPropertyDialog(CWnd* pParent /*=NULL*/)
	: CDiagramPropertyDlg(CUMLLabelPropertyDialog::IDD, pParent) 
{

	//{{AFX_DATA_INIT(CUMLLabelPropertyDialog)
	m_text = _T("");
	//}}AFX_DATA_INIT

	m_pointsize = 12;
	m_bold = FALSE;
	m_italic = FALSE;
	m_underline = FALSE;

}

CUMLLabelPropertyDialog::~CUMLLabelPropertyDialog() 
{
}

void CUMLLabelPropertyDialog::DoDataExchange(CDataExchange* pDX) 
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CUMLLabelPropertyDialog)
	DDX_Text(pDX, IDC_EDIT_TEXT, m_text);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CUMLLabelPropertyDialog, CDialog)
	//{{AFX_MSG_MAP(CUMLLabelPropertyDialog)
	ON_BN_CLICKED(IDC_BUTTON_FONT, OnButtonFont)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CUMLLabelPropertyDialog message handlers

void CUMLLabelPropertyDialog::OnOK()  
{

	CUMLEntityLabel* uml = static_cast< CUMLEntityLabel* >( GetEntity() );

	UpdateData();
	uml->SetTitle( m_text );
	uml->SetFont( m_font );

	uml->SetBold( m_bold );
	uml->SetItalic( m_italic );
	uml->SetUnderline( m_underline );
	uml->SetFontSize( m_pointsize );

	Redraw();
	ShowWindow( SW_HIDE );
	GetRedrawWnd()->SetFocus();

}

void CUMLLabelPropertyDialog::OnCancel()  
{

	CDialog::OnCancel();
	GetRedrawWnd()->SetFocus();

}

/////////////////////////////////////////////////////////////////////////////
// CUMLLabelPropertyDialog overrides

void CUMLLabelPropertyDialog::SetValues()  
{

	CUMLEntityLabel* uml = static_cast< CUMLEntityLabel* >( GetEntity() );

	m_text = uml->GetTitle();
	m_font = uml->GetFont();
	m_pointsize = uml->GetFontSize();
	m_bold = uml->GetBold();
	m_italic = uml->GetItalic();
	m_underline = uml->GetUnderline();

}

void CUMLLabelPropertyDialog::OnButtonFont()  
{

	CFont font;
	CUMLEntityLabel* uml = static_cast< CUMLEntityLabel* >( GetEntity() );
	font.CreatePointFont( m_pointsize * 10, uml->GetFont() );
	LOGFONT lf;
	font.GetLogFont( &lf );

	lf.lfItalic = ( BYTE ) m_italic;
	lf.lfUnderline = ( BYTE ) m_underline;
	if( m_bold )
		lf.lfWeight = FW_BOLD;

	CFontDialog	dlg( &lf );
	if( dlg.DoModal() == IDOK )
	{
		m_font = dlg.GetFaceName();
		m_pointsize = dlg.GetSize() / 10;
		m_bold = dlg.IsBold();
		m_italic = dlg.IsItalic();
		m_underline = dlg.IsUnderline();
	}
	
}

