
#include "stdafx.h"
#include "PropertyContainer.h"
#include "Tokenizer.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// Construction/destruction
CPropertyContainer::CPropertyContainer()
{
}

CPropertyContainer::~CPropertyContainer()
{

	RemoveAll();

}

void CPropertyContainer::Copy( CPropertyContainer& properties )
{

	RemoveAll();

	int max = properties.GetSize();
	for( int t = 0 ; t < max ; t++ )
		Add( new CProperty( properties.GetAt( t ) ) );

}

// Implementation
int CPropertyContainer::GetSize( ) const
{

	return m_properties.GetSize();

}

CProperty* CPropertyContainer::GetAt( int index ) const
{

	CProperty* result = NULL;

	if( index < GetSize() )
		result = static_cast< CProperty* >( m_properties[ index ] );

	return result;

}

void CPropertyContainer::RemoveAt( int index )
{

	if( index > -1 && index < GetSize() )
	{

		delete GetAt( index );
		m_properties.RemoveAt( index );

	}

}

void CPropertyContainer::RemoveAll( )
{

	while( GetSize() )
		RemoveAt( 0 );

}

void CPropertyContainer::Add( CProperty* property )
{

	CProperty* oldproperty = FindProperty( property->key );
	if( oldproperty )
	{
		if( property->value != oldproperty->value )
			oldproperty->value = property->value;
		delete property;
	}
	else
		m_properties.Add( property );

}

void CPropertyContainer::Add( const CString& tag, const CString& val )
{
	
	CProperty* property = new CProperty( tag, val );
	Add( property );

}

CString CPropertyContainer::GetString( int format ) const
{

	CString output;
	int max = GetSize();
	if( max )
	{
		switch( format )
		{
			case STRING_FORMAT_SAVE:
				{
					for( int t = 0 ; t < max ; t++ )
					{
						CProperty* property = GetAt( t );
						output += property->GetString( format );
						if( t < max - 1 )
							output += _T( "#" );
					}
				}
				break;
			case STRING_FORMAT_CPP:
				{
					for( int t = 0 ; t < max ; t++ )
					{
						CProperty* property = GetAt( t );
						output += property->GetString( format );
						if( t < max - 1 )
							output += _T( ", " );
					}
				}
				break;
			case STRING_FORMAT_UML:
				{
					output = _T( "{ " );
					for( int t = 0 ; t < max ; t++ )
					{
						CProperty* property = GetAt( t );
						output += property->GetString( format );
						if( t < max - 1 )
							output += _T( ", " );
					}
					output += _T( " }" );
				}
				break;
			case STRING_FORMAT_HTML:
				{
					output = _T( "{ " );
					for( int t = 0 ; t < max ; t++ )
					{
						CProperty* property = GetAt( t );
						output += property->GetString( STRING_FORMAT_UML );
						if( t < max - 1 )
							output += _T( "<br>" );
					}
					output += _T( " }" );
				}
				break;
		}
	}

	return output;

}

void CPropertyContainer::FromString( const CString& str )
{

	CTokenizer tok( str, _T( "#" ) );
	int max = tok.GetSize();
	for( int t = 0 ; t < max ; t++ )
	{

		CString propval;
		tok.GetAt( t, propval );
		CProperty* prop = CProperty::FromString( propval );
		if( prop )
			Add( prop );

	}

}

CString	CPropertyContainer::GetPropertyValue( const CString& tag ) const
{

	CString result;
	int max = GetSize();
	for( int t = 0 ; t < max ; t++ )
	{
		CProperty* property = GetAt( t );
		if( property->key == tag )
		{
			result = property->value;
			if( result.IsEmpty() )
				result = _T( "true" );
		}
	}

	return result;

}

CProperty* CPropertyContainer::FindProperty( const CString& tag )
{

	CProperty* result = NULL;

	int max = GetSize();
	for( int t = 0 ; t < max ; t++ )
	{
		CProperty* property = GetAt( t );
		if( property->key == tag )
			result = property;
	}

	return result;

}

void CPropertyContainer::RemoveProperty( const CString& tag )
{

	int max = GetSize();
	for( int t = 0 ; t < max ; t++ )
	{
		CProperty* property = GetAt( t );
		if( property->key == tag )
		{
			RemoveAt( t );
			t = max;
		}
	}

}

void CPropertyContainer::SetPropertyValue( const CString& tag, const CString& value )
{

	CProperty* property = FindProperty( tag );
	if( property == NULL )
	{
		property = new CProperty( tag, value );
		Add( property );
	}
	else
	{
		property->value = value;
	}

}
