
#include "stdafx.h"
#include "UMLUndoItem.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// Construction/destruction
CUMLUndoItem::CUMLUndoItem() 
{

	col = RGB( 255, 255, 255 );

}

CUMLUndoItem::~CUMLUndoItem() 
{
}

