
#include "stdafx.h"
#include "TextFile.h"

////////////////////////////////////////
// CTextFile construction/destruction

CTextFile::CTextFile( const CString& ext, const CString& eol ) 
{

	m_extension = ext;
	m_eol = eol;

}

CTextFile::~CTextFile() 
{
}

////////////////////////////////////////
// CTextFile operations
//

BOOL CTextFile::ReadTextFile( CString& filename, CStringArray& contents ) 
{

	ClearError();
	BOOL result = TRUE;

	if( filename.IsEmpty() )
		result = GetFilename( FALSE, filename );

	if( result )
	{
		CStdioFile file;
		CFileException feError;

		if( file.Open( filename, CFile::modeRead, &feError ) )
		{

			contents.RemoveAll();

			CString line;
			while( file.ReadString( line ) )
				contents.Add( line );

			file.Close();

		}
		else
		{

			TCHAR	errBuff[256];
			feError.GetErrorMessage( errBuff, 256 );
			m_error = errBuff;
			result = FALSE;

		}
	}

	return result;

}

BOOL CTextFile::ReadTextFile( CString& filename, CString& contents ) 
{

	contents = _T( "" );

	// Error handling
	ClearError();

	CStdioFile file;
	CFileException feError;
	BOOL result = TRUE;

	if( filename.IsEmpty() )
		result = GetFilename( FALSE, filename );

	if( result )
	{

		// Reading the file
		if( file.Open( filename, CFile::modeRead, &feError ) )
		{

			CString line;
			while( file.ReadString( line ) )
				contents += line + m_eol;

			file.Close();

		}
		else
		{

			// Setting error message
			TCHAR	errBuff[256];
			feError.GetErrorMessage( errBuff, 256 );
			m_error = errBuff;
			result = FALSE;

		}
	}

	return result;

}

BOOL CTextFile::WriteTextFile( CString& filename, const CStringArray& contents ) 
{

	// Error handling
	ClearError();

	CStdioFile file;
	CFileException feError;
	BOOL result = TRUE;

	if( filename.IsEmpty() )
		result = GetFilename( TRUE, filename );

	if( result )
	{
		// Write file
		if( file.Open( filename, CFile::modeWrite | CFile::modeCreate, &feError ) )
		{

			int max = contents.GetSize();
			for( int t = 0 ; t < max ; t++ )
				file.WriteString( contents[ t ] + m_eol );

			file.Close();

		}
		else
		{

			// Set error message
			TCHAR	errBuff[256];
			feError.GetErrorMessage( errBuff, 256 );
			m_error = errBuff;
			result = FALSE;

		}
	}

	return result;

}

BOOL CTextFile::WriteTextFile( CString& filename, const CString& contents ) 
{

	// Error checking
	ClearError();

	CFile file;
	CFileException feError;
	BOOL result = TRUE;

	if( filename.IsEmpty() )
		result = GetFilename( TRUE, filename );

	if( result )
	{
		// Write the file
		if( file.Open( filename, CFile::modeWrite | CFile::modeCreate, &feError ) )
		{

			file.Write( contents, contents.GetLength() );
			file.Close();

		}
		else
		{

			// Set error message
			TCHAR	errBuff[256];
			feError.GetErrorMessage( errBuff, 256 );
			m_error = errBuff;
			result = FALSE;

		}
	}

	return result;

}

BOOL CTextFile::AppendFile( CString& filename, const CString& contents ) 
{

	CFile file;
	CFileException feError;
	BOOL result = TRUE;

	if( filename.IsEmpty() )
		result = GetFilename( TRUE, filename );

	if( result )
	{
		// Write the file
		if( file.Open( filename, CFile::modeWrite | CFile::modeCreate | CFile::modeNoTruncate, &feError ) )
		{

			file.SeekToEnd();
			file.Write( contents, contents.GetLength() );
			file.Close();

		}
		else
		{

			// Set error message
			TCHAR	errBuff[256];
			feError.GetErrorMessage( errBuff, 256 );
			m_error = errBuff;
			result = FALSE;

		}
	}

	return result;

}

BOOL CTextFile::AppendFile( CString& filename, const CStringArray& contents ) 
{

	CStdioFile file;
	CFileException feError;
	BOOL result = TRUE;

	if( filename.IsEmpty() )
		result = GetFilename( TRUE, filename );

	if( result )
	{
		// Write the file
		if( file.Open( filename, CFile::modeWrite | CFile::modeCreate | CFile::modeNoTruncate, &feError ) )
		{

			file.SeekToEnd();

			int max = contents.GetSize();
			for( int t = 0 ; t < max ; t++ )
				file.WriteString( contents[ t ] + m_eol );

			file.Close();

		}
		else
		{

			// Set error message
			TCHAR	errBuff[256];
			feError.GetErrorMessage( errBuff, 256 );
			m_error = errBuff;
			result = FALSE;

		}
	}

	return result;

}

////////////////////////////////////////
// Window operations
//

BOOL CTextFile::Load( CString& filename, CEdit* edit ) 
{
	BOOL result = FALSE;

	// Error checking
	if( ValidParam( edit ) )
	{
		CString contents;
		if( ReadTextFile( filename, contents ) )
		{

			edit->SetWindowText( contents );
			result = TRUE;

		}
	}

	return result;

}

BOOL CTextFile::Load( CString& filename, CListBox* list ) 
{
	BOOL result = FALSE;

	// Error checking
	if( ValidParam( list ) )
	{

		// Read the file
		CStringArray contents;
		if( ReadTextFile( filename, contents ) )
		{

			// Set to listbox
			int max = contents.GetSize();
			for( int t = 0 ; t < max ; t++ )
				if( contents[ t ].GetLength() )
					list->AddString( contents[ t ] );
			result = TRUE;

		}

	}

	return result;

}

BOOL CTextFile::Save( CString& filename, CEdit* edit ) 
{
	BOOL result = FALSE;

	// Error checking
	if( ValidParam( edit ) )
	{

		// Get text
		CString contents;
		edit->GetWindowText( contents );

		// Write file
		if( WriteTextFile( filename, contents ) )
			result = TRUE;

	}

	return result;

}

BOOL CTextFile::Save( CString& filename, CListBox* list ) 
{
	BOOL result = FALSE;

	// Error checking
	if( ValidParam( list ) )
	{

		// Get listbox contents
		CStringArray contents;
		int max = list->GetCount();
		for( int t = 0; t < max ; t++ )
		{

			CString line;
			list->GetText( t, line );
			contents.Add( line );

		}

		// Write file
		if( WriteTextFile( filename, contents ) )
			result = TRUE;

	}

	return result;

}

////////////////////////////////////////
// Error handling
//

CString CTextFile::GetErrorMessage() 
{

	return m_error;

}

////////////////////////////////////////
// Private functions
//

void CTextFile::ClearError()
{

	m_error = _T( "" );

}

BOOL CTextFile::ValidParam( CWnd* wnd )
{

	ClearError();
	BOOL result = TRUE;

	if( wnd == NULL )
	{

		ASSERT( FALSE );
		result = FALSE;

	}

	if( !IsWindow( wnd->m_hWnd ) )
	{

		ASSERT( FALSE );
		result = FALSE;

	}

	if( !result )
		m_error = "Bad Window handle as parameter";

	return result;

}

BOOL CTextFile::GetFilename( BOOL save, CString& filename )
{
	CString filter;
	CString extension = GetExtension();
	if( extension.GetLength() )
		filter = extension + _T( "-files (*." + extension + ")|*." ) + extension + _T( "|All Files (*.*)|*.*||" );

	BOOL result = FALSE;
	CFileDialog dlg( !save, extension, NULL, OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT, filter );

	if( dlg.DoModal() == IDOK )
	{
		filename = dlg.GetPathName();
		result = TRUE;
	}

	return result;

}

CString CTextFile::GetExtension()
{

	return m_extension;

}
