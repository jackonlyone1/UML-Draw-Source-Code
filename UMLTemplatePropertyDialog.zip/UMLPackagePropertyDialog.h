#if !defined(AFX_UMLPACKAGEPROPERTYDIALOG_H__0F34B3BB_CEDC_435F_BC4C_256D4DDD548C__INCLUDED_)
#define AFX_UMLPACKAGEPROPERTYDIALOG_H__0F34B3BB_CEDC_435F_BC4C_256D4DDD548C__INCLUDED_

#include "DiagramPropertyDlg.h"
#include "resource.h"

/////////////////////////////////////////////////////////////////////////////
// CUMLPackagePropertyDialog dialog

 
//===========================================================================
// Summary:
//     The CUMLPackagePropertyDialog class derived from CDiagramPropertyDlg
//      U M L Package Property Dialog
//===========================================================================

class CUMLPackagePropertyDialog : public CDiagramPropertyDlg
{

// Construction
public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// U M L Package Property Dialog, Constructs a CUMLPackagePropertyDialog object.
	//		Returns A  value.  
	// Parameters:
	//		pParent---Parent, A pointer to the CWnd or NULL if the call failed.
	CUMLPackagePropertyDialog(CWnd* pParent = NULL);
	
	//-----------------------------------------------------------------------
	// Summary:
	// C U M L Package Property Dialog, Destructor of class CUMLPackagePropertyDialog
	//		Returns A  value.
	~CUMLPackagePropertyDialog();

	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Values, Sets a specify value to current class CUMLPackagePropertyDialog
	// This member function is also a virtual function, you can Override it if you need,
	virtual void SetValues();

// Dialog Data
	//{{AFX_DATA(CUMLPackagePropertyDialog)
	enum { IDD = IDD_UML_PROP_PACKAGE };
 
	// You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString	m_text;
	//}}AFX_DATA

// Overrides
	//{{AFX_VIRTUAL(CUMLPackagePropertyDialog)
	protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Data Exchange, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDX---D X, A pointer to the CDataExchange or NULL if the call failed.
	virtual void DoDataExchange(CDataExchange* pDX);
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CUMLPackagePropertyDialog)
	
	//-----------------------------------------------------------------------
	// Summary:
	// On O K, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void OnOK();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Cancel, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void OnCancel();
	//}}AFX_MSG
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Button Font, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnButtonFont();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Button Color, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnButtonColor();
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ M E S S A G E_ M A P, None Description.
	//		Returns A  value.
	DECLARE_MESSAGE_MAP()

private:

 
	// You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString		m_font;
 
	// This member sets A 32-bit value used as a color value.  
	COLORREF	m_color;

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_UMLPACKAGEPROPERTYDIALOG_H__0F34B3BB_CEDC_435F_BC4C_256D4DDD548C__INCLUDED_)
