#if !defined(AFX_UMLLINKPROPERTYDIALOG_H__240BC1A0_5124_427A_B390_4AF299AA0910__INCLUDED_)
#define AFX_UMLLINKPROPERTYDIALOG_H__240BC1A0_5124_427A_B390_4AF299AA0910__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// LinkPropertyDialog.h : header file
//
#include "resource.h"
#include "DiagramPropertyDlg.h"

#define TYPE_ASSOCIATION	0
#define TYPE_DEPENDANCY		1
#define TYPE_INHERITANCE	2
#define TYPE_COMPOSITION	3
#define TYPE_PARTOF			4
#define TYPE_INVISIBLE		5
#define TYPE_INTERFACE		6

/////////////////////////////////////////////////////////////////////////////
// CUMLLinkPropertyDialog dialog

 
//===========================================================================
// Summary:
//     The CUMLLinkPropertyDialog class derived from CDiagramPropertyDlg
//      U M L Link Property Dialog
//===========================================================================

class CUMLLinkPropertyDialog : public CDiagramPropertyDlg
{
// Construction
public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// U M L Link Property Dialog, Constructs a CUMLLinkPropertyDialog object.
	//		Returns A  value.  
	// Parameters:
	//		pParent---Parent, A pointer to the CWnd or NULL if the call failed.
	CUMLLinkPropertyDialog(CWnd* pParent = NULL);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Values, Sets a specify value to current class CUMLLinkPropertyDialog
	// This member function is also a virtual function, you can Override it if you need,
	virtual void SetValues();

// Dialog Data
	//{{AFX_DATA(CUMLLinkPropertyDialog)
	enum { IDD = IDD_UML_PROP_LINK };
 
	// This member sets TRUE if it is right.  
	BOOL	m_unidirectional;
 
	// You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString	m_endlabel;
 
	// You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString	m_startlabel;
 
	// You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString	m_secondaryendlabel;
 
	// You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString	m_secondarystartlabel;
 
	// This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int		m_linktype;
 
	// You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString	m_title;
	//}}AFX_DATA


// Overrides
	//{{AFX_VIRTUAL(CUMLLinkPropertyDialog)
	protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Data Exchange, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDX---D X, A pointer to the CDataExchange or NULL if the call failed.
	virtual void DoDataExchange(CDataExchange* pDX);
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CUMLLinkPropertyDialog)
	
	//-----------------------------------------------------------------------
	// Summary:
	// On O K, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void OnOK();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Cancel, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void OnCancel();
	//}}AFX_MSG
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Button Font, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnButtonFont();
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ M E S S A G E_ M A P, None Description.
	//		Returns A  value.
	DECLARE_MESSAGE_MAP()

private:

 
	// You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString		m_font;

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_UMLLINKPROPERTYDIALOG_H__240BC1A0_5124_427A_B390_4AF299AA0910__INCLUDED_)
