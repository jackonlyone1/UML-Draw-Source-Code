#if !defined(AFX_UMLNOTEPROPERTYDIALOG_H__2FB127AA_9D6C_46CD_82AA_25DECE00338B__INCLUDED_)
#define AFX_UMLNOTEPROPERTYDIALOG_H__2FB127AA_9D6C_46CD_82AA_25DECE00338B__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// UMLNotePropertyDialog.h : header file
//

#include "DiagramPropertyDlg.h"
#include "resource.h"

/////////////////////////////////////////////////////////////////////////////
// CUMLNotePropertyDialog dialog

 
//===========================================================================
// Summary:
//     The CUMLNotePropertyDialog class derived from CDiagramPropertyDlg
//      U M L Note Property Dialog
//===========================================================================

class CUMLNotePropertyDialog : public CDiagramPropertyDlg
{

// Construction
public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// U M L Note Property Dialog, Constructs a CUMLNotePropertyDialog object.
	//		Returns A  value.  
	// Parameters:
	//		pParent---Parent, A pointer to the CWnd or NULL if the call failed.
	CUMLNotePropertyDialog(CWnd* pParent = NULL);
	
	//-----------------------------------------------------------------------
	// Summary:
	// C U M L Note Property Dialog, Destructor of class CUMLNotePropertyDialog
	//		Returns A  value.
	~CUMLNotePropertyDialog();

	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Values, Sets a specify value to current class CUMLNotePropertyDialog
	// This member function is also a virtual function, you can Override it if you need,
	virtual void SetValues();

// Dialog Data
	//{{AFX_DATA(CUMLNotePropertyDialog)
	enum { IDD = IDD_UML_PROP_NOTE };
 
	// You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString	m_text;
	//}}AFX_DATA

// Overrides
	//{{AFX_VIRTUAL(CUMLNotePropertyDialog)
	protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Data Exchange, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDX---D X, A pointer to the CDataExchange or NULL if the call failed.
	virtual void DoDataExchange(CDataExchange* pDX);
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CUMLNotePropertyDialog)
	
	//-----------------------------------------------------------------------
	// Summary:
	// On O K, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void OnOK();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Cancel, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void OnCancel();
	//}}AFX_MSG
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Button Font, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnButtonFont();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Button Color, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnButtonColor();
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ M E S S A G E_ M A P, None Description.
	//		Returns A  value.
	DECLARE_MESSAGE_MAP()

private:

 
	// You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString		m_font;
 
	// This member sets A 32-bit value used as a color value.  
	COLORREF	m_color;

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_UMLNOTEPROPERTYDIALOG_H__2FB127AA_9D6C_46CD_82AA_25DECE00338B__INCLUDED_)
