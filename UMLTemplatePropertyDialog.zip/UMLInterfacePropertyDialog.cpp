
#include "stdafx.h"
#include "UMLEntityInterface.h"
#include "UMLInterfacePropertyDialog.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CUMLInterfacePropertyDialog dialog

CUMLInterfacePropertyDialog::CUMLInterfacePropertyDialog(CWnd* pParent /*=NULL*/)
	: CDiagramPropertyDlg(CUMLInterfacePropertyDialog::IDD, pParent) 
{

	//{{AFX_DATA_INIT(CUMLInterfacePropertyDialog)
	m_text = _T("");
	//}}AFX_DATA_INIT

}

CUMLInterfacePropertyDialog::~CUMLInterfacePropertyDialog() 
{
}

void CUMLInterfacePropertyDialog::DoDataExchange(CDataExchange* pDX) 
{

	CDiagramPropertyDlg::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CUMLInterfacePropertyDialog)
	DDX_Text(pDX, IDC_EDIT_TEXT, m_text);
	//}}AFX_DATA_MAP

}

BEGIN_MESSAGE_MAP(CUMLInterfacePropertyDialog, CDiagramPropertyDlg)
	//{{AFX_MSG_MAP(CUMLInterfacePropertyDialog)
	ON_BN_CLICKED(IDC_BUTTON_FONT, OnButtonFont)
	ON_BN_CLICKED(IDC_BUTTON_COLOR, OnButtonColor)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CUMLInterfacePropertyDialog message handlers

void CUMLInterfacePropertyDialog::OnOK()  
{

	CUMLEntityInterface* uml = static_cast< CUMLEntityInterface* >( GetEntity() );

	UpdateData();
	uml->SetTitle( m_text );
	uml->SetBkColor( m_color );
	uml->SetFont( m_font );
	Redraw();
	ShowWindow( SW_HIDE );
	GetRedrawWnd()->SetFocus();

}

void CUMLInterfacePropertyDialog::OnCancel()  
{

	CDialog::OnCancel();
	GetRedrawWnd()->SetFocus();

}

/////////////////////////////////////////////////////////////////////////////
// CUMLInterfacePropertyDialog overrides

void CUMLInterfacePropertyDialog::SetValues()  
{

	CUMLEntityInterface* uml = static_cast< CUMLEntityInterface* >( GetEntity() );

	m_text = uml->GetTitle();
	m_color = uml->GetBkColor();
	m_font = uml->GetFont();

	if( m_hWnd )
		UpdateData( FALSE );

}

void CUMLInterfacePropertyDialog::OnButtonFont()  
{

	CFont font;
	CUMLEntityInterface* uml = static_cast< CUMLEntityInterface* >( GetEntity() );
	font.CreatePointFont( 120, uml->GetFont() );
	LOGFONT lf;
	font.GetLogFont( &lf );
	CFontDialog	dlg( &lf );
	if( dlg.DoModal() == IDOK )
		m_font = dlg.GetFaceName();
	
}
void CUMLInterfacePropertyDialog::OnButtonColor()  
{

	CUMLEntityInterface* uml = static_cast< CUMLEntityInterface* >( GetEntity() );
	COLORREF color = uml->GetBkColor();
	CColorDialog	dlg( color );
	if( dlg.DoModal() == IDOK )
		m_color = dlg.GetColor();
	
}
