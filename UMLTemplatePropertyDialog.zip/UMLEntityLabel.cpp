
#include "stdafx.h"
#include "UMLEntityLabel.h"
#include "Tokenizer.h"
#include "UMLEntityContainer.h"
#include "StringHelpers.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


CUMLEntityLabel::CUMLEntityLabel() 
{

	SetDefaultSize( CSize( 48, 14 ) );

	CString title;
	title.LoadString( IDS_UML_LABEL );
	SetTitle( title );

	SetType( _T( "uml_label" ) );
	SetConstraints( GetDefaultSize(), CSize( -1, -1 ) );

	SetBkColor( RGB( 0,0,0 ) );

	SetPropertyDialog( &m_dlg, CUMLLabelPropertyDialog::IDD );

	SetFontSize( 12 );
	SetBold( FALSE );
	SetItalic( FALSE );
	SetUnderline( FALSE );

}

CUMLEntityLabel::~CUMLEntityLabel() 
{
	if( m_dlg.m_hWnd )
		m_dlg.DestroyWindow();

}

CDiagramEntity* CUMLEntityLabel::Clone() 
{

	CUMLEntityLabel* obj = new CUMLEntityLabel;
	obj->Copy( this );
	return obj;

}

BOOL CUMLEntityLabel::FromString( const CString& str ) 
{

	BOOL result = FALSE;
	CString data( str );

	if( LoadFromString( data ) )
	{

		CTokenizer tok( data );
		CString fontName;
		int		bkColor;

		CString package;
		int		pointsize;
		BOOL	bold;
		BOOL	italic;
		BOOL	underline;

		int count = 0;

		tok.GetAt( count++, package );
		tok.GetAt( count++, fontName );
		tok.GetAt( count++, bkColor );
		tok.GetAt( count++, pointsize );
		tok.GetAt( count++, bold );
		tok.GetAt( count++, italic );
		tok.GetAt( count++, underline );

		UnmakeSaveString( package );

		SetPackage( package );
		SetFont( fontName );
		SetBkColor( static_cast< COLORREF >( bkColor ) );
		SetFontSize( pointsize );
		SetBold( bold );
		SetItalic( italic );
		SetUnderline( underline );

		CalcRestraints();
		result = TRUE;
	}

	return result;

}

CDiagramEntity* CUMLEntityLabel::CreateFromString( const CString& str ) 
{

	CUMLEntityLabel* obj = new CUMLEntityLabel;
	if(!obj->FromString( str ) )
	{
		delete obj;
		obj = NULL;
	}

	return obj;

}

void CUMLEntityLabel::Draw( CDC* dc, CRect rect ) 
{

	if( GetTitle().GetLength() )
	{
	
		CFont font;
		int weight = FW_NORMAL;
		if( GetBold() )
			weight = FW_BOLD;

		font.CreateFont( -round( static_cast< double >( GetFontSize() ) ), 
			0,0,0,
			weight,
			( BYTE ) GetItalic(),
			( BYTE ) GetUnderline(),0,0,0,0,0,0, 
			GetFont() );

		CFont* oldfont = dc->SelectObject( &font );
		dc->SetBkMode( TRANSPARENT );
		dc->DrawText( GetTitle(), rect, DT_WORDBREAK | DT_NOPREFIX);
		dc->SelectObject( oldfont );

	}

}

void CUMLEntityLabel::SetTitle( CString title ) 
{

	CUMLEntity::SetTitle( title );
	CalcRestraints();

}

CString CUMLEntityLabel::GetString() const 
{

	CString str;
	CString package = GetPackage();
	MakeSaveString( package );

	str.Format( _T( ",%s,%s,%i,%i,%i,%i,%i;" ), 
			package,
			GetFont(),
			static_cast< int >( GetBkColor() ),
			GetFontSize(),
			GetBold(),
			GetItalic(),
			GetUnderline()
		);

	str = GetDefaultGetString() + str;
	return str;

}

void CUMLEntityLabel::SetRect( CRect rect ) 
{

	CDiagramEntity::SetRect( rect );
	CalcRestraints();

}

void CUMLEntityLabel::SetRect( double left, double top, double right, double bottom ) 
{

	CDiagramEntity::SetRect( left, top, right, bottom );
	CalcRestraints();

}

void CUMLEntityLabel::CalcRestraints() 
{

	CString title = GetTitle();
	if( title.GetLength() )
	{

		CDC* dc = CWnd::GetDesktopWindow()->GetDC();

		CRect rect = GetRect();
		CRect newRect( rect );
		CFont font;
		int weight = FW_NORMAL;
		if( GetBold() )
			weight = FW_BOLD;

		font.CreateFont( -GetFontSize(), 0,0,0,weight, ( BYTE ) GetItalic(), ( BYTE ) GetUnderline(),0,0,0,0,0,0, GetFont() );
		CFont* oldfont = dc->SelectObject( &font );
		dc->DrawText( GetTitle(), newRect, DT_WORDBREAK | DT_CALCRECT );
		dc->SelectObject( oldfont );
		CWnd::GetDesktopWindow()->ReleaseDC( dc );

		int diff = newRect.Height() - rect.Height();
		rect.bottom += diff;
		if( GetBottom() - GetTop() < rect.Height() )
			SetBottom( GetTop() + rect.Height() );

		if( GetDefaultSize().cy < rect.Height() )
		{
			SetMinimumSize( CSize( GetDefaultSize().cx, rect.Height() ) );
			CRect rc = GetRect();
			if( rc.Height() < rect.Height() )
				SetRect( GetLeft(), GetTop(), GetRight(), GetTop() + rect.Height() );
		}
		else
			SetMinimumSize( GetDefaultSize() );

	}

}

int CUMLEntityLabel::GetLinkCode( CPoint /*point*/ ) const 
{

	return LINK_NONE;

}

CString CUMLEntityLabel::Export( UINT format ) const 
{

	CString result;

	switch( format )
	{
		case EXPORT_HTML:
			result = ExportHTML();
			break;
	}

	return result;

}

CString CUMLEntityLabel::ExportHTML() const 
{

	CString result;
	CRect rect = GetRect();

	int font_size = GetFontSize();
	CString fontweight( _T( "normal" ) );
	if( GetBold() )
		fontweight = _T( "bold" );
	CString fontstyle( _T( "normal" ) );
	if( GetItalic() )
		fontstyle = _T( "italic" );
	CString textdecoration( _T( "none" ) );
	if( GetUnderline() )
		textdecoration = _T( "underline" );

	CString color = ColorrefToString( GetBkColor() );
	CString title = GetTitle();
	title.Replace( _T( "<" ), _T( "&lt;" ) );
	title.Replace( _T( ">" ), _T( "&gt;" ) );
	title.Replace( _T( "\r\n" ), _T( "<br>" ) );

	result.Format( _T( "<div style='position:absolute;left:%i;top:%i;width:%i;height:%i;font-family:%s;font-size:%i;overflow:hidden;font-weight:%s;font-style:%s;text-decoration:%s;'>%s</div>" ),
		rect.left, rect.top, rect.Width(), rect.Height(), GetFont(), font_size, fontweight, fontstyle, textdecoration, title );

	return result;
}

void CUMLEntityLabel::SetBold( BOOL bold ) 
{

	m_bold = bold;

}

void CUMLEntityLabel::SetItalic( BOOL italic ) 
{

	m_italic = italic;

}

void CUMLEntityLabel::SetUnderline( BOOL underline ) 
{

	m_underline = underline;

}

BOOL CUMLEntityLabel::GetBold() const 
{

	return m_bold;

}

BOOL CUMLEntityLabel::GetItalic() const 
{

	return m_italic;

}

BOOL CUMLEntityLabel::GetUnderline() const 
{

	return m_underline;

}
