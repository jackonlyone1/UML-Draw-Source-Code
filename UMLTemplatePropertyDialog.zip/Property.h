#ifndef _CPROPERTY_H_16554D14_3C55_4CD4_BB287BFB5822
#define _CPROPERTY_H_16554D14_3C55_4CD4_BB287BFB5822

///////////////////////////////////////////////////////////
// File :		Property.h
// Created :	06/06/04
//

#include "StringHelpers.h"

 
//===========================================================================
// Summary:
//     The CProperty class derived from CObject
//      Property
//===========================================================================

class CProperty : public CObject
{
public:
	// Construction/destruction
	
	//-----------------------------------------------------------------------
	// Summary:
	// Property, Constructs a CProperty object.
	//		Returns A  value.
	CProperty();
	
	//-----------------------------------------------------------------------
	// Summary:
	// C Property, Destructor of class CProperty
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value.
	virtual ~CProperty();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Property, Constructs a CProperty object.
	//		Returns A  value.  
	// Parameters:
	//		property---A pointer to the CProperty or NULL if the call failed.
	CProperty( CProperty* property );
	
	//-----------------------------------------------------------------------
	// Summary:
	// Property, Constructs a CProperty object.
	//		Returns A  value.  
	// Parameters:
	//		tag---Specifies A CString type value.  
	//		val---Specifies A CString type value.
	CProperty( const CString& tag, const CString& val );
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get String, Returns the specified value.
	//		Returns a CString type value.  
	// Parameters:
	//		format---Specifies A integer value.
	CString GetString( int format = STRING_FORMAT_SAVE ) const;

	
	//-----------------------------------------------------------------------
	// Summary:
	// From String, None Description.
	// This member function is a static function.
	//		Returns a pointer to the object CProperty,or NULL if the call failed  
	// Parameters:
	//		str---Specifies A CString type value.
	static CProperty* FromString( const CString& str );

// Attributes
 
	// You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString key;
 
	// You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString value;

};

#endif //_CPROPERTY_H_16554D14_3C55_4CD4_BB287BFB5822
