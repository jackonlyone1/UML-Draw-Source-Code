#ifndef _CPARAMETER_H_91173656_87E4_4EAC_83E628967C9A
#define _CPARAMETER_H_91173656_87E4_4EAC_83E628967C9A

///////////////////////////////////////////////////////////
// File :		Parameter.h
// Created :	06/06/04
//

#include "StringHelpers.h"

 
//===========================================================================
// Summary:
//     The CParameter class derived from CObject
//      Parameter
//===========================================================================

class CParameter : public CObject
{
public:
	// Construction/destruction
	
	//-----------------------------------------------------------------------
	// Summary:
	// Parameter, Constructs a CParameter object.
	//		Returns A  value.
	CParameter();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Parameter, Constructs a CParameter object.
	//		Returns A  value.  
	// Parameters:
	//		parameter---A pointer to the CParameter or NULL if the call failed.
	CParameter( CParameter* parameter );
	
	//-----------------------------------------------------------------------
	// Summary:
	// C Parameter, Destructor of class CParameter
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value.
	virtual ~CParameter();

	
	//-----------------------------------------------------------------------
	// Summary:
	// None Description.
	//		Returns TRUE on success; FALSE otherwise.  
	// Parameters:
	//		parameter---Specifies a const CParameter& parameter object.
	BOOL operator==( const CParameter& parameter );
	
	//-----------------------------------------------------------------------
	// Summary:
	// None Description.
	//		Returns TRUE on success; FALSE otherwise.  
	// Parameters:
	//		parameter---Specifies a const CParameter& parameter object.
	BOOL operator!=( const CParameter& parameter );

// Operations
	
	//-----------------------------------------------------------------------
	// Summary:
	// From String, None Description.
	// This member function is a static function.
	//		Returns a pointer to the object CParameter,or NULL if the call failed  
	// Parameters:
	//		str---Specifies A CString type value.
	static	CParameter* FromString( const CString& str );
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get String, Returns the specified value.
	//		Returns a CString type value.  
	// Parameters:
	//		format---Specifies A integer value.
	CString	GetString( int format = STRING_FORMAT_SAVE ) const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// To String, None Description.
	//		Returns a CString type value.  
	// Parameters:
	//		nooperationattributenames---Specifies A Boolean value.
	CString	ToString( BOOL nooperationattributenames ) const;

// Attributes
 
	// You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString name;
 
	// You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString defaultvalue;
 
	// You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString type;
 
	// This member sets TRUE if it is right.  
	BOOL	reference;
 
	// This member sets TRUE if it is right.  
	BOOL	in;
 
	// This member sets TRUE if it is right.  
	BOOL	out;

};

#endif //_CPARAMETER_H_91173656_87E4_4EAC_83E628967C9A
