#include "stdafx.h"
#include "UMLClassPropertyDialog.h"
#include "UMLEntityClass.h"
#include "ClassAttributePropertyDialog.h"
#include "ClassOperationPropertyDialog.h"
#include "PropertyListEditorDialog.h"
#include "ClassDisplayPropertyDialog.h"
#include "GetterSetterDialog.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CUMLClassPropertyDialog dialog

CUMLClassPropertyDialog::CUMLClassPropertyDialog(CWnd* pParent /*=NULL*/)
	: CDiagramPropertyDlg(CUMLClassPropertyDialog::IDD, pParent) 
{

	//{{AFX_DATA_INIT(CUMLClassPropertyDialog)
	m_name = _T("");
	m_stereotype = _T("");
	m_propertylist = _T("");
	//}}AFX_DATA_INIT

}

void CUMLClassPropertyDialog::DoDataExchange(CDataExchange* pDX) 
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CUMLClassPropertyDialog)
	DDX_Control(pDX, IDC_LIST_OPERATIONS, m_operation);
	DDX_Control(pDX, IDC_LIST_ATTRIBUTES, m_attribute);
	DDX_Control(pDX, IDC_EDIT_NAME, m_nameCtrl);
	DDX_Text(pDX, IDC_EDIT_NAME, m_name);
	DDX_Text(pDX, IDC_COMBO_STEREOTYPE, m_stereotype);
	DDX_Text(pDX, IDC_EDIT_PROPERTY_LIST, m_propertylist);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CUMLClassPropertyDialog, CDialog)
	//{{AFX_MSG_MAP(CUMLClassPropertyDialog)
	ON_BN_CLICKED(IDC_BUTTON_ADD_ATTRIBUTE, OnButtonAddAttribute)
	ON_BN_CLICKED(IDC_BUTTON_ADD_OPERATION, OnButtonAddOperation)
	ON_BN_CLICKED(IDC_BUTTON_FONT, OnButtonFont)
	ON_BN_CLICKED(IDC_BUTTON_COLOR, OnButtonColor)
	ON_BN_CLICKED(IDC_BUTTON_PROPERTY_LIST, OnButtonPropertyList)
	ON_BN_CLICKED(IDC_BUTTON_AUTO_GENERATE, OnButtonAutoGenerate)
	ON_BN_CLICKED(IDC_BUTTON_VISIBILITY, OnButtonVisibility)
	ON_BN_CLICKED(IDC_BUTTON_AUTO_GENERATE2, OnButtonAutoGenerate2)
	//}}AFX_MSG_MAP
	ON_REGISTERED_MESSAGE(rwm_EXLISTBOX_DBLCLICK, OnListboxDblClick)
	ON_REGISTERED_MESSAGE(rwm_EXLISTBOX_DELETE, OnListboxDelete)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CUMLClassPropertyDialog message handlers

void CUMLClassPropertyDialog::OnOK()  
{

	CUMLEntityClass* uml = static_cast< CUMLEntityClass* >( GetEntity() );

	UpdateData();
	if( m_name.IsEmpty() )
	{
		AfxMessageBox( IDS_UML_CLASS_MUST_HAVE_A_NAME );
		m_nameCtrl.SetFocus();
		return;
	}

	uml->SetTitle( m_name );
	uml->SetBkColor( m_color );
	uml->SetFont( m_font );

	m_stereotype.Remove( _TCHAR( '?' ) );
	m_stereotype.Remove( _TCHAR( '?') );
	m_stereotype.TrimLeft();
	m_stereotype.TrimRight();

	uml->SetStereotype( m_stereotype );
	uml->GetProperties()->Copy( m_properties );

	CreateAttributes();
	CreateOperations();

	ClearListboxes();

	uml->CalcRestraints();

	int t;
	int max;
	int style = ENTITY_TYPE_NONE;

	if( m_stereotype == _T( "interface" ) )
		style |= ENTITY_TYPE_ABSTRACT;
	if( m_stereotype == _T( "utility" ) )
		style |= ENTITY_TYPE_STATIC;

	if( style != ENTITY_TYPE_NONE )
	{
		max = uml->GetOperations();
		for( t = 0 ; t < max ; t++ )
		{
			COperation* op = uml->GetOperation( t );
			op->maintype |= style;
		}

		max = uml->GetAttributes();
		for( t = 0 ; t < max ; t++ )
		{
			CAttribute* attr = uml->GetAttribute( t );
			attr->maintype |= style;
		}
	}

	Redraw();
	ShowWindow( SW_HIDE );
	GetRedrawWnd()->SetFocus();

}

void CUMLClassPropertyDialog::OnCancel()  
{

	ClearListboxes();
	CDialog::OnCancel();
	GetRedrawWnd()->SetFocus();

}

void CUMLClassPropertyDialog::SetValues()  
{

	CUMLEntityClass* uml = static_cast< CUMLEntityClass* >( GetEntity() );

	m_name = uml->GetTitle();
	m_color = uml->GetBkColor();
	m_font = uml->GetFont();
	m_stereotype = uml->GetStereotype();

	m_properties.Copy( *( uml->GetProperties() ) );

	if( m_hWnd && ::IsWindowVisible( m_hWnd ) )
	{
		FillListboxes();
		m_propertylist = m_properties.GetString( STRING_FORMAT_UML );
		UpdateData( FALSE );
	}

}

void CUMLClassPropertyDialog::OnButtonAddAttribute()  
{

	CClassAttributePropertyDialog	dlg;
	if( dlg.DoModal() == IDOK )
	{
		CAttribute* obj = dlg.GetAttribute();
		CString output = obj->ToString( FALSE );
		int index = m_attribute.AddString( output );
		m_attribute.SetItemData( index, ( DWORD ) obj );
		m_attribute.SetCurSel( index );
		m_attribute.SetFocus();
	}
	else
		delete dlg.GetAttribute();

}

void CUMLClassPropertyDialog::EditAttribute()  
{

	int index = m_attribute.GetCurSel();
	if( index != LB_ERR )
	{
		CAttribute* obj = reinterpret_cast< CAttribute* >( m_attribute.GetItemData( index ) );
		if( obj )
		{
			CClassAttributePropertyDialog	dlg;
			dlg.SetAttribute( obj );
			if( dlg.DoModal() == IDOK )
				RefreshListboxes();
			m_attribute.SetCurSel( index );
			m_attribute.SetFocus();
		}
	}	

}

void CUMLClassPropertyDialog::DeleteAttribute()  
{

	int index = m_attribute.GetCurSel();
	if( index != LB_ERR )
	{
		if( AfxMessageBox( IDS_UML_DELETE_ATTRIBUTE, MB_YESNO ) == IDYES )
		{
			CAttribute* obj = reinterpret_cast< CAttribute* >( m_attribute.GetItemData( index ) );
			m_attribute.DeleteString( index );
			delete obj;
			m_attribute.SetCurSel( index );
			m_attribute.SetFocus();
		}
	}

}

void CUMLClassPropertyDialog::OnButtonAddOperation()  
{

	CClassOperationPropertyDialog	dlg;
	if( dlg.DoModal() == IDOK )
	{
		COperation* obj = dlg.GetOperation();
		CString output = obj->ToString( FALSE, FALSE );
		int index = m_operation.AddString( output );
		m_operation.SetItemData( index, ( DWORD ) obj );
		m_operation.SetCurSel( index );
		m_operation.SetFocus();
	}
	else
		delete dlg.GetOperation();

}

void CUMLClassPropertyDialog::EditOperation()  
{

	int index = m_operation.GetCurSel();
	if( index != LB_ERR )
	{
		COperation* obj = reinterpret_cast< COperation* >( m_operation.GetItemData( index ) );
		if( obj )
		{
			CClassOperationPropertyDialog	dlg;
			dlg.SetOperation( obj );
			if( dlg.DoModal() == IDOK )
				RefreshListboxes();
			m_operation.SetCurSel( index );
			m_operation.SetFocus();
		}
	}	

}

void CUMLClassPropertyDialog::DeleteOperation()  
{

	int index = m_operation.GetCurSel();
	if( index != LB_ERR )
	{
		if( AfxMessageBox( IDS_UML_DELETE_OPERATION, MB_YESNO ) == IDYES )
		{
			COperation* obj = reinterpret_cast< COperation* >( m_operation.GetItemData( index ) );
			m_operation.DeleteString( index );
			delete obj;
			m_operation.SetCurSel( index );
			m_operation.SetFocus();
		}
	}

}

void CUMLClassPropertyDialog::OnButtonFont()  
{

	CFont font;
	CUMLEntityClass* uml = static_cast< CUMLEntityClass* >( GetEntity() );
	font.CreatePointFont( 120, uml->GetFont() );
	LOGFONT lf;
	font.GetLogFont( &lf );
	CFontDialog	dlg( &lf );
	if( dlg.DoModal() == IDOK )
	{
		m_font = dlg.GetFaceName();
		Redraw();
	}
	
}

void CUMLClassPropertyDialog::OnButtonColor()  
{

	CUMLEntityClass* uml = static_cast< CUMLEntityClass* >( GetEntity() );
	COLORREF color = uml->GetBkColor();
	CColorDialog	dlg( color );
	if( dlg.DoModal() == IDOK )
	{
		m_color = dlg.GetColor();
		Redraw();
	}
	
}

void CUMLClassPropertyDialog::FillListboxes() 
{

	ClearListboxes();
	CUMLEntityClass* uml = static_cast< CUMLEntityClass* >( GetEntity() );
	int max = uml->GetAttributes();
	int t =0;
	for( t = 0 ; t < max ; t++ )
	{
		CAttribute* obj = uml->GetAttribute( t );
		CString output = obj->ToString( FALSE );
		int index = m_attribute.AddString( output );
		m_attribute.SetItemData( index, ( DWORD ) obj->Clone() );
	}

	max = uml->GetOperations();
	for( t = 0 ; t < max ; t++ )
	{
		COperation* obj = uml->GetOperation( t );
		CString output = obj->ToString( FALSE, FALSE );
		int index = m_operation.AddString( output );
		m_operation.SetItemData( index, ( DWORD ) obj->Clone() );
	}

}

void CUMLClassPropertyDialog::ClearListboxes() 
{

	int max = m_attribute.GetCount();
	int t = 0;
	for( t = 0 ; t < max ; t++ )
	{
		CAttribute* obj = reinterpret_cast< CAttribute* >( m_attribute.GetItemData( t ) );
		delete obj;
	}

	max = m_operation.GetCount();
	for( t = 0 ; t < max ; t++ )
	{
		COperation* obj = reinterpret_cast< COperation* >( m_operation.GetItemData( t ) );
		delete obj;
	}

	m_attribute.ResetContent();
	m_operation.ResetContent();

}

void CUMLClassPropertyDialog::RefreshListboxes() 
{

	int max = m_attribute.GetCount();
	int t = 0;
	for( t = 0 ; t < max ; t++ )
	{
		CAttribute* obj = reinterpret_cast< CAttribute* >( m_attribute.GetItemData( t ) );
		CString output = obj->ToString( FALSE );
		m_attribute.DeleteString( t );
		int index = m_attribute.InsertString( t, output );
		m_attribute.SetItemData( index, ( DWORD ) obj );
	}

	max = m_operation.GetCount();
	for( t = 0 ; t < max ; t++ )
	{
		COperation* obj = reinterpret_cast< COperation* >( m_operation.GetItemData( t ) );
		CString output = obj->ToString( FALSE, FALSE );
		m_operation.DeleteString( t );
		int index = m_operation.InsertString( t, output );
		m_operation.SetItemData( index, ( DWORD ) obj );
	}

}

LRESULT CUMLClassPropertyDialog::OnListboxDblClick( WPARAM id, LPARAM ) 
{

	if( static_cast< int >( id ) == m_attribute.GetDlgCtrlID() )
		EditAttribute();
	if( static_cast< int >( id ) == m_operation.GetDlgCtrlID() )
		EditOperation();

	return 0;

}

LRESULT CUMLClassPropertyDialog::OnListboxDelete( WPARAM id, LPARAM ) 
{

	if( static_cast< int >( id ) == m_attribute.GetDlgCtrlID() )
		DeleteAttribute();
	if( static_cast< int >( id ) == m_operation.GetDlgCtrlID() )
		DeleteOperation();

	return 0;

}

void CUMLClassPropertyDialog::OnButtonPropertyList()  
{

	UpdateData();
	CPropertyListEditorDialog	dlg;

	dlg.SetProperties( m_properties );
	if( dlg.DoModal() == IDOK )
	{
		m_properties.Copy( *( dlg.GetProperties() ) );
		m_propertylist = m_properties.GetString( STRING_FORMAT_UML );
		UpdateData( FALSE );
	}
	
}

void CUMLClassPropertyDialog::OnButtonAutoGenerate()  
{

	int index = m_attribute.GetCurSel();
	if( index != LB_ERR )
	{
		CAttribute* attr = reinterpret_cast< CAttribute* >( m_attribute.GetItemData( index ) );
		if( attr )
		{
			if( AfxMessageBox( IDS_UML_CREATEGETTERS_SETTERS, MB_YESNO ) == IDYES )
			{

				CString name = attr->name;
				if( name.GetLength() > 2 && name.Left( 2 ) == _T( "m_" ) )
					name = name.Right( name.GetLength() - 2 );
				name = _TCHAR( _totupper( name[ 0 ] ) ) + name.Right( name.GetLength() - 1 );
				CString getName( _T( "Get" ) + name );
				CString setName( _T( "Set" ) + name );

				BOOL getFound = FALSE;
				BOOL setFound = FALSE;

				CreateAttributes();
				CreateOperations();

				CUMLEntityClass* uml = static_cast< CUMLEntityClass* >( GetEntity() );
				int size = uml->GetOperations();
				for( int i = 0 ; i < size ; i++ )
				{
					COperation* op = uml->GetOperation( i );
					if( op->getter && op->getsetvariable == attr->name )
						getFound = TRUE;
					if( op->setter && op->getsetvariable == attr->name )
						setFound = TRUE;
				}

				if( !getFound || !setFound )
				{
					CGetterSetterDialog	dlg;
					if( !getFound )
						dlg.m_getter = getName;
					else
						dlg.m_noget = TRUE;
					if( !setFound )
						dlg.m_setter = setName;
					else
						dlg.m_noset = TRUE;

					if( dlg.DoModal() == IDOK )
					{
						BOOL added = FALSE;
						if( !dlg.m_noget && dlg.m_getter.GetLength() )
						{
							COperation* op = new COperation;
							op->name = dlg.m_getter;
							op->type = attr->type;
							op->access = ACCESS_TYPE_PUBLIC;
							op->properties.Add( _T( "query" ) );
							op->getter = TRUE;
							op->getsetvariable = attr->name;
							uml->AddOperation( op );
							added = TRUE;
						}

						if( !dlg.m_noset && dlg.m_setter.GetLength() )
						{
							COperation* op = new COperation;
							op->name = dlg.m_setter;
							op->access = ACCESS_TYPE_PUBLIC;
							CParameter* parameter = new CParameter;
							parameter->name = _T( "value" );
							parameter->type = attr->type;
							op->parameters.Add( parameter );

							op->setter = TRUE;
							op->getsetvariable = attr->name;
							uml->AddOperation( op );
							added = TRUE;
						}

						if( added )
							FillListboxes();
					}
				}
				else
					AfxMessageBox( IDS_UML_GETSET_DEFINED );
			}
		}
	}
	else
		AfxMessageBox( IDS_UML_MUST_SELECT_AN_ATTRIBUTE );

	m_attribute.SetCurSel( index );
	m_attribute.SetFocus();

}

void CUMLClassPropertyDialog::CreateAttributes() 
{

	CUMLEntityClass* uml = static_cast< CUMLEntityClass* >( GetEntity() );

	// Wipe current attributes from the class.
	uml->ClearAttributes();

	// Re-add from listbox.
	int max = m_attribute.GetCount();
	for( int t = 0 ; t < max ; t++ )
	{
		CAttribute* obj = reinterpret_cast< CAttribute* >( m_attribute.GetItemData( t ) );
		if( obj )
			uml->AddAttribute( obj->Clone() );
	}

}

void CUMLClassPropertyDialog::CreateOperations() 
{

	CUMLEntityClass* uml = static_cast< CUMLEntityClass* >( GetEntity() );

	// Wipe current operations from the class.
	uml->ClearOperations();

	int max = m_operation.GetCount();
	for( int t = 0 ; t < max ; t++ )
	{
		COperation* obj = reinterpret_cast< COperation* >( m_operation.GetItemData( t ) );
		if( obj )
			uml->AddOperation( obj->Clone() );
	}

}

void CUMLClassPropertyDialog::OnButtonVisibility()  
{

	CUMLEntityClass* uml = static_cast< CUMLEntityClass* >( GetEntity() );

	CClassDisplayPropertyDialog	dlg;
	int displayOptions = uml->GetDisplayOptions();

	dlg.m_noattributenames = ( displayOptions & DISPLAY_NO_OPERATION_ATTRIBUTE_NAMES ) != 0;
	dlg.m_noattributes = ( displayOptions & DISPLAY_NO_ATTRIBUTES ) != 0;
	dlg.m_nomarkers = ( displayOptions & DISPLAY_NO_MARKERS ) != 0;
	dlg.m_nooperations = ( displayOptions & DISPLAY_NO_OPERATIONS ) != 0;
	dlg.m_onlypublic = ( displayOptions & DISPLAY_ONLY_PUBLIC ) != 0;
	if( dlg.DoModal() )
	{

		displayOptions = 0;
		if( dlg.m_noattributenames )
			displayOptions |= DISPLAY_NO_OPERATION_ATTRIBUTE_NAMES;
		if( dlg.m_noattributes )
			displayOptions |= DISPLAY_NO_ATTRIBUTES;
		if( dlg.m_nomarkers )
			displayOptions |= DISPLAY_NO_MARKERS;
		if( dlg.m_nooperations )
			displayOptions |= DISPLAY_NO_OPERATIONS;
		if( dlg.m_onlypublic )
			displayOptions |= DISPLAY_ONLY_PUBLIC;

		uml->SetDisplayOptions( displayOptions );

	}

}

void CUMLClassPropertyDialog::OnButtonAutoGenerate2()  
{

	if( AfxMessageBox( IDS_UML_CREATECTOR_DTOR, MB_YESNO ) == IDYES )
	{
		UpdateData();
		CreateAttributes();
		CreateOperations();

		CUMLEntityClass* uml = static_cast< CUMLEntityClass* >( GetEntity() );
		COperation* op = new COperation;
		op->name = m_name;
		op->access = ACCESS_TYPE_PUBLIC;
		uml->AddOperation( op );

		op = new COperation;
		op->name = _T( "~" ) + m_name;
		op->access = ACCESS_TYPE_PUBLIC;
		op->maintype = ENTITY_TYPE_VIRTUAL;
		op->properties.Add( _T( "virtual" ) );
		uml->AddOperation( op );

		FillListboxes();

	}

}
