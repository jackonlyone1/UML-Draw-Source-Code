#ifndef _UMLENTITYNOTE_H_
#define _UMLENTITYNOTE_H_

#include "UMLEntity.h"
#include "UMLNotePropertyDialog.h"

 
//===========================================================================
// Summary:
//     The CUMLEntityNote class derived from CUMLEntity
//      U M L Entity Note
//===========================================================================

class CUMLEntityNote : public CUMLEntity
{
public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// U M L Entity Note, Constructs a CUMLEntityNote object.
	//		Returns A  value.
	CUMLEntityNote();
	
	//-----------------------------------------------------------------------
	// Summary:
	// C U M L Entity Note, Destructor of class CUMLEntityNote
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value.
	virtual ~CUMLEntityNote();

	
	//-----------------------------------------------------------------------
	// Summary:
	// Clone this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CDiagramEntity,or NULL if the call failed
	virtual CDiagramEntity* Clone();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create From String, You construct a CUMLEntityNote object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is a static function.
	//		Returns a pointer to the object CDiagramEntity,or NULL if the call failed  
	// Parameters:
	//		str---Specifies A CString type value.
	static	CDiagramEntity* CreateFromString( const CString& str );
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draws current object to the specify device.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---A pointer to the CDC or NULL if the call failed.  
	//		rect---Specifies A CRect type value.
	virtual void Draw( CDC* dc, CRect rect );

	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Title, Sets a specify value to current class CUMLEntityNote
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		title---Specifies A CString type value.
	virtual void	SetTitle( CString title );
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Rectangle, Sets a specify value to current class CUMLEntityNote
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		rect---Specifies A CRect type value.
	virtual void	SetRect( CRect rect );
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Rectangle, Sets a specify value to current class CUMLEntityNote
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		left---Specifies a double left object.  
	//		top---Specifies a double top object.  
	//		right---Specifies a double right object.  
	//		bottom---Specifies a double bottom object.
	virtual void	SetRect( double left, double top, double right, double bottom );
	
	//-----------------------------------------------------------------------
	// Summary:
	// None Description.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CString type value.  
	// Parameters:
	//		format---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual CString	Export( UINT format = 0 ) const;

	
	//-----------------------------------------------------------------------
	// Summary:
	// Calculate Restraints, None Description.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void	CalcRestraints();

private:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Text Rectangle, Returns the specified value.
	//		Returns a CRect type value.  
	// Parameters:
	//		inrect---Specifies A CRect type value.
	CRect			GetTextRect( const CRect& inrect ) const;

 
	// This member specify CUMLNotePropertyDialog object.  
	CUMLNotePropertyDialog	m_dlg;

	
	//-----------------------------------------------------------------------
	// Summary:
	// Export H T M L, None Description.
	//		Returns a CString type value.
	CString ExportHTML() const;

};

#endif //_UMLENTITYNOTE_H_
