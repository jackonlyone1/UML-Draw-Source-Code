
#include "stdafx.h"
#include "UMLEntityContainer.h"
#include "UMLControlFactory.h"
#include "DiskObject.h"
#include "TextFile.h"
#include "UMLEntityInterface.h"

#include <math.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#pragma warning( disable : 4706 )
#pragma warning( disable : 4541 )

CUMLEntityContainer::CUMLEntityContainer() 
{

	m_displayOptions = 0;
	m_color = RGB( 0, 0, 0 );

	SetUndoStackSize( 10 );

}

CUMLEntityContainer::~CUMLEntityContainer() 
{

	ClearUndo();

}


void CUMLEntityContainer::RemoveAt( int index ) 
{

	CUMLEntity* obj = GetObjectAt( index );
	if( obj )
	{

		CUMLLineSegment* line = dynamic_cast< CUMLLineSegment* >( obj );

		if( line )
		{
			DeleteLine( line );
		}
		else
		{
			CString link;

			link = obj->GetName();
			for( int t = GetSize() - 1 ; t >= 0 ; t-- )
			{
				CUMLLineSegment* del = dynamic_cast< CUMLLineSegment* >( GetAt( t ) );
				if( del )
				{
					if( del->GetLink( LINK_START ) == link || 
						del->GetLink( LINK_END ) == link )
					{
						Remove( del );
						t = GetSize() - 1;
					}
				}
			}

			index = Find( obj );
			if( index != -1 )
			{
				GetData()->RemoveAt( index );
				delete obj;
			}

		}

	}

}


CUMLLineSegment* CUMLEntityContainer::GetNextSegment( CUMLLineSegment* from ) const 
{
	CUMLLineSegment* result = NULL;
	CString name = from->GetLink( LINK_END );
	if( name.GetLength() )
		result = dynamic_cast< CUMLLineSegment* >( GetNamedObject( name ) );
	else
	{
		name = from->GetName();
		CUMLLineSegment* obj = NULL;
		int max = GetSize();
		for( int t = 0 ; t < max && result == NULL ; t++ )
		{
			obj = dynamic_cast< CUMLLineSegment* >( GetAt( t ) );
			if( obj && obj->GetLink( LINK_START) == name )
				return obj;
		}
	}

	return result;
}

CUMLLineSegment* CUMLEntityContainer::GetPrevSegment( CUMLLineSegment* from ) const 
{
	CUMLLineSegment* result = NULL;
	CString name = from->GetLink( LINK_START );
	if( name.GetLength() )
		result = dynamic_cast< CUMLLineSegment* >( GetNamedObject( name ) );
	else
	{
		name = from->GetName();
		CUMLLineSegment* obj = NULL;
		int max = GetSize();
		for( int t = 0 ; t < max && result == NULL ; t++ )
		{
			obj = dynamic_cast< CUMLLineSegment* >( GetAt( t ) );
			if( obj && obj->GetLink( LINK_END ) == name )
				return obj;
		}
	}

	return result;
}

CUMLLineSegment* CUMLEntityContainer::GetStartSegment( CUMLLineSegment* from ) const 
{

	CUMLLineSegment* result = from;
	CUMLLineSegment* test = GetPrevSegment( from );

	while( test )
	{
		result = test;
		test = GetPrevSegment( test );
	}

	return result;

}

CUMLLineSegment* CUMLEntityContainer::GetEndSegment( CUMLLineSegment* from ) const 
{

	CUMLLineSegment* result = from;
	CUMLLineSegment* test = GetNextSegment( from );

	while( test )
	{
		result = test;
		test = GetNextSegment( test );
	}

	return result;

}

void CUMLEntityContainer::DeleteLine( CUMLLineSegment* from ) 
{

	CUMLEntity* start = GetStartNode( from );
	CUMLEntity* end = GetEndNode( from );
	CUMLLineSegment* obj = GetStartSegment( from );
	CUMLLineSegment* next = NULL;
	while( obj )
	{
		int index = Find( obj );
		next = GetNextSegment( obj );
		GetData()->RemoveAt( index );
		delete obj;
		obj = next;
	}

	if( start )
		start->CalcRestraints();
	if( end )
		end->CalcRestraints();

}

CUMLEntity* CUMLEntityContainer::GetNamedObject( const CString& name ) const 
{

	CUMLEntity* test;
	int max = GetSize();
	for( int t = 0 ; t < max ; t++ )
	{
		test = GetObjectAt( t );
		if( test->GetName() == name )
			return test;
	}

	return NULL;

}

CUMLEntity* CUMLEntityContainer::GetTitledObject( const CString& name ) const 
{

	CUMLEntity* test;
	int max = GetSize();
	for( int t = 0 ; t < max ; t++ )
	{

		test = GetObjectAt( t );
		if( test->GetTitle() == name )
			return test;

	}

	return NULL;

}

void CUMLEntityContainer::RemoveAllSelected() 
{

	for( int t = GetSize() - 1; t >= 0 ; t-- )
	{
		if( GetAt( t )->IsSelected() )
		{
			RemoveAt( t );
			t = GetSize();
		}
	}

}

CUMLEntity* CUMLEntityContainer::GetStartNode( CUMLLineSegment* from ) const 
{

	CUMLEntity* result = NULL;
	CUMLLineSegment* line = GetStartSegment( from );
	if( line )
	{
		CString start = line->GetLink( LINK_START );
		result = GetNamedObject( start );
	}
	return result;

}

CUMLEntity* CUMLEntityContainer::GetEndNode( CUMLLineSegment* from ) const 
{

	CUMLEntity* result = NULL;
	CUMLLineSegment* line = GetEndSegment( from );
	if( line )
	{
		CString end = line->GetLink( LINK_END );
		result = GetNamedObject( end );
	}
	return result;

}

int	CUMLEntityContainer::GetSelectCount() const 
{

	int count = 0;
	int max = GetSize();

	for( int t = 0 ; t < max ; t++ )
		if( GetAt( t )->IsSelected() )
			count++;

	return count;

}

void CUMLEntityContainer::DeleteDanglingLines() 
{

	for( int t = 0 ; t < GetSize() ; t++ )
	{
		CUMLLineSegment* obj = dynamic_cast< CUMLLineSegment* >( GetAt( t ) );
		if( obj )
		{
			CUMLEntity* end = GetEndNode( obj );
			CUMLEntity* start = GetStartNode( obj );
			if( !end || !start )
			{
				Remove( obj );
				t = 0;
			}
		}
	}

}

CDiagramEntity* CUMLEntityContainer::GetAt( int index ) const 
{

	CUMLEntityContainer* const local = const_cast<CUMLEntityContainer* const>(this);
	CObArray* objs = local->GetData();
	CUMLEntity* result = NULL;
	if( index < objs->GetSize() && index >= 0 )
	{
		result = static_cast< CUMLEntity* >( objs->GetAt( index ) );
		if( GetPackage() != _T( "all" ) && result->GetPackage() != GetPackage() )
			result =  &( local->m_dummy );
	}

	return result;

}

void CUMLEntityContainer::SetPackage( const CString& package ) 
{

	m_package = package;

}

CString CUMLEntityContainer::GetPackage() const 
{

	return m_package;

}

CUMLEntity* CUMLEntityContainer::GetObjectAt( int index ) const 
{

	CUMLEntity* result = static_cast< CUMLEntity* >( GetAt( index ) );
	return result;

}

void CUMLEntityContainer::AdjustLinkedObjects( CUMLEntity* in, CUMLEntity* filter ) 
{
	CPoint point;
	CPoint objpoint;
	double posdiff = 0.0;
	CString name = in->GetName();
	CString link;
	int linktype;

	CUMLLineSegment* line = dynamic_cast< CUMLLineSegment* >( in );
	if( line )
	{
		link = line->GetLink( LINK_END );
		if( link.GetLength() && link != name )
		{
			CUMLEntity* obj = static_cast< CUMLEntity* >( GetNamedObject( link ) );
			if( obj  && obj != filter && !obj->IsSelected() )
			{
				objpoint = line->GetLinkPosition( LINK_END );
				linktype = line->GetLinkType( LINK_END );
				if( linktype == LINK_TOP )
				{
					CPoint linkpoint = GetLinkPosition( obj, line );
					posdiff = objpoint.x - linkpoint.x;
					if( posdiff )
					{
						obj->MoveRect( posdiff, 0 );
						AdjustLinkedObjects( obj, in );
					}
				}
				if( linktype == LINK_BOTTOM )
				{
					CPoint linkpoint = GetLinkPosition( obj, line );
					posdiff = objpoint.x - linkpoint.x;
					if( posdiff )
					{
						obj->MoveRect( posdiff, 0 );
						AdjustLinkedObjects( obj, in );
					}
				}
				if( linktype == LINK_RIGHT )
				{
					CPoint linkpoint = GetLinkPosition( obj, line );
					posdiff = objpoint.y - linkpoint.y;
					if( posdiff )
					{
						obj->MoveRect( 0, posdiff );
						AdjustLinkedObjects( obj, in );
					}
				}
				if( linktype == LINK_LEFT )
				{
					CPoint linkpoint = GetLinkPosition( obj, line );
					posdiff = objpoint.y - linkpoint.y;
					if( posdiff )
					{
						obj->MoveRect( 0, posdiff );
						AdjustLinkedObjects( obj, in );
					}
				}
				if( linktype == LINK_START )
				{
					CRect first = obj->GetRect();
					obj->SetLeft( objpoint.x );
					obj->SetTop( objpoint.y );
					if( static_cast< CUMLLineSegment* >( obj )->IsHorizontal() )
						obj->SetBottom( obj->GetTop() );
					else
						obj->SetRight( obj->GetLeft() );
					if( first != obj->GetRect() )
						AdjustLinkedObjects( obj, in );
				}
				if( linktype == LINK_END )
				{
					CRect first = obj->GetRect();
					obj->SetRight( objpoint.x );
					obj->SetBottom( objpoint.y );
					if( static_cast< CUMLLineSegment* >( obj )->IsHorizontal() )
						obj->SetTop( obj->GetBottom() );
					else
						obj->SetLeft( obj->GetRight() );
					if( first != obj->GetRect() )
						AdjustLinkedObjects( obj, in );
				}
			}
		}

		link = line->GetLink( LINK_START );
		if( link.GetLength() && link != name )
		{
			CUMLEntity* obj = static_cast< CUMLEntity* >( GetNamedObject( link ) );
			if( obj  && obj != filter && !obj->IsSelected() )
			{
				objpoint = line->GetLinkPosition( LINK_START );
				linktype = line->GetLinkType( LINK_START );
				if( linktype == LINK_TOP )
				{
					CPoint linkpoint = GetLinkPosition( obj, line );
					posdiff = objpoint.x - linkpoint.x;
					if( posdiff )
					{
						obj->MoveRect( posdiff, 0 );
						AdjustLinkedObjects( obj, in );
					}
				}
				if( linktype == LINK_BOTTOM )
				{
					CPoint linkpoint = GetLinkPosition( obj, line );
					posdiff = objpoint.x - linkpoint.x;
					if( posdiff )
					{
						obj->MoveRect( posdiff, 0 );
						AdjustLinkedObjects( obj, in );
					}
				}
				if( linktype == LINK_RIGHT )
				{
					CPoint linkpoint = GetLinkPosition( obj, line );
					posdiff = objpoint.y - linkpoint.y;
					if( posdiff )
					{
						obj->MoveRect( 0, posdiff );
						AdjustLinkedObjects( obj, in );
					}
				}
				if( linktype == LINK_LEFT )
				{
					CPoint linkpoint = GetLinkPosition( obj, line );
					posdiff = objpoint.y - linkpoint.y;
					if( posdiff )
					{
						obj->MoveRect( 0, posdiff );
						AdjustLinkedObjects( obj, in );
					}
				}
				if( linktype == LINK_START )
				{
					CRect first = obj->GetRect();
					obj->SetLeft( objpoint.x );
					obj->SetTop( objpoint.y );
					if( static_cast< CUMLLineSegment* >( obj )->IsHorizontal() )
						obj->SetBottom( obj->GetTop() );
					else
						obj->SetRight( obj->GetLeft() );
					if( first != obj->GetRect() )
						AdjustLinkedObjects( obj, in );
				}
				if( linktype == LINK_END )
				{
					CRect first = obj->GetRect();
					obj->SetRight( objpoint.x );
					obj->SetBottom( objpoint.y );
					if( static_cast< CUMLLineSegment* >( obj )->IsHorizontal() )
						obj->SetTop( obj->GetBottom() );
					else
						obj->SetLeft( obj->GetRight() );
					if( first != obj->GetRect() )
						AdjustLinkedObjects( obj, in );
				}
			}
		}
	}
	else
	{
		CUMLEntity* obj = NULL;
		int count = 0;
		while( ( obj = GetObjectAt( count++ ) ) )
		{
			if( obj->GetPackage() == GetPackage() )
			{
				if( obj != in )
				{
					CUMLLineSegment* line = dynamic_cast< CUMLLineSegment* >( obj );
					if( line )
					{
						link = line->GetLink( LINK_START );
						if( link == name )
						{
							if( line && line != filter && !line->IsSelected() )
							{
								linktype = line->GetLinkType( LINK_START );
								objpoint = GetLinkPosition( in, line );
								CRect first = line->GetRect();
								if( linktype == LINK_RIGHT || linktype == LINK_LEFT )
								{
									line->SetTop( objpoint.y );
									line->SetLeft( objpoint.x );

									line->SetBottom( objpoint.y );
								}
								if( linktype == LINK_TOP || linktype == LINK_BOTTOM )
								{
									line->SetTop( objpoint.y );
									line->SetLeft( objpoint.x );

									line->SetRight( objpoint.x );
								}

								if( linktype == LINK_END )
								{
									line->SetLeft( objpoint.x );
									line->SetTop( objpoint.y );
									if( line->IsHorizontal() )
										line->SetBottom( objpoint.y );
									else
										line->SetRight( objpoint.x );
								}

								if( linktype == LINK_START )
								{
									line->SetRight( objpoint.x );
									line->SetBottom( objpoint.y );
									if( line->IsHorizontal() )
										line->SetTop( objpoint.y );
									else
										line->SetLeft( objpoint.x );
								}

								if( first != line->GetRect() )
									AdjustLinkedObjects( line, in );
							}
						}

						link = line->GetLink( LINK_END );
						if( link == name )
						{
							if( line && line != filter && !line->IsSelected() )
							{
								objpoint = GetLinkPosition( in, line );
								linktype = line->GetLinkType( LINK_END );
								CRect first = line->GetRect();
								if( linktype == LINK_RIGHT || linktype == LINK_LEFT )
								{
									line->SetBottom( objpoint.y );
									line->SetRight( objpoint.x );

									line->SetTop( objpoint.y );
								}
								if( linktype == LINK_TOP || linktype == LINK_BOTTOM )
								{
									line->SetBottom( objpoint.y );
									line->SetRight( objpoint.x );

									line->SetLeft( objpoint.x );
								}

								if( linktype == LINK_END )
								{
									line->SetLeft( objpoint.x );
									line->SetTop( objpoint.y );
									if( line->IsHorizontal() )
										line->SetBottom( objpoint.y );
									else
										line->SetRight( objpoint.x );
								}

								if( linktype == LINK_START )
								{
									line->SetRight( objpoint.x );
									line->SetBottom( objpoint.y );
									if( line->IsHorizontal() )
										line->SetTop( objpoint.y );
									else
										line->SetLeft( objpoint.x );
								}

								if( first != line->GetRect() )
									AdjustLinkedObjects( line, in );
							}
						}
					}
				}
			}
		}
	}

}

void CUMLEntityContainer::ReduceLine( CUMLLineSegment* line ) 
{

	SetDefaultLineStyle( line );

	CUMLLineSegment* test = GetPrevSegment( line );
	if( test )
	{
		if( ( line->IsHorizontal() && test->IsHorizontal() ) || 
			( !line->IsHorizontal() && !test->IsHorizontal() ) )
		{
			// We have found two lines with the same orientation 
			// attached to each other. The second line should 
			// swallow the first one

			// Setting start values from test to line
			line->SetLeft( test->GetLeft() );
			line->SetTop( test->GetTop() );

			// Assign the start link from test to line
			line->SetLink( LINK_START, test->GetLink( LINK_START ) );
			line->SetLinkType( LINK_START, test->GetLinkType( LINK_START ) );
			line->SetOffset( LINK_START, test->GetOffset( LINK_START ) );

			// If we have an end link to test, 
			// we must rename it as well
			CUMLLineSegment* prev = GetPrevSegment( test );
			if( prev )
				prev->SetLink( LINK_END, line->GetName() );

			// Remove test
			int index = Find( test );
			GetData()->RemoveAt( index );
			delete test;
		}
	}

}

void CUMLEntityContainer::SetDefaultLineStyle( CUMLLineSegment* line ) 
{

	CUMLEntity* start = GetStartNode( line );
	CUMLEntity* end = GetEndNode( line );
	BOOL dashed = FALSE;
	BOOL owned = FALSE;

	if( start )
	{
		if( start->GetType() == _T( "uml_note" ) )
			dashed = TRUE;
	}

	if( end )
	{
		if( end->GetType() == _T( "uml_note" ) )
			dashed = TRUE;
		if( end->GetType() == _T( "uml_package" ) && !dashed )
			owned = TRUE;
	}

	if( dashed )
		line->AddLineStyle( STYLE_DASHED );

	if( owned )
		line->SetLineStyle( STYLE_CIRCLECROSS );

}

CPoint CUMLEntityContainer::GetLinkPosition( CUMLEntity* obj, CUMLLineSegment* line ) const 
{

	CPoint result( -1, -1 );
	CPoint	start;
	int linkOffset = 0;
	int type = LINK_NONE;

	if( line->GetLink( LINK_START ) == obj->GetName() )
	{
		type = line->GetLinkType( LINK_START );
		linkOffset = line->GetOffset( LINK_START );
	}
	else if( line->GetLink( LINK_END ) == obj->GetName() )
	{
		type = line->GetLinkType( LINK_END );
		linkOffset = line->GetOffset( LINK_END );
	}

	CRect rect = obj->GetRect();
	start = obj->GetLinkPosition( type );
	switch( type )
	{
		case LINK_LEFT:
		case LINK_RIGHT:
		{
			result.x = start.x;
			result.y = rect.top + linkOffset;
		}
		break;
		case LINK_TOP:
		case LINK_BOTTOM:
		{
			result.y = start.y;
			result.x = rect.left + linkOffset;
		}
		break;
	}

	return result;

}

void CUMLEntityContainer::Save( CArchive& ar ) 
{

	CString package = GetPackage();
	SetPackage( _T( "all" ) );
	ar.WriteString( GetString() + _T( "\r\n" ) );
	int count = 0;
	CDiagramEntity* obj;
	while( ( obj = GetAt( count++ ) ) )
		ar.WriteString( obj->GetString() + _T( "\r\n" ) );

	SetPackage( package );
	SetModified( FALSE );

}

void CUMLEntityContainer::Save( CString& filename ) 
{

	CString package = GetPackage();
	SetPackage( _T( "all" ) );
	CTextFile		file;
	CStringArray	stra;

	stra.Add( GetString() + _T( "\r\n" ) );
	int count = 0;
	CDiagramEntity* obj;
	while( ( obj = GetAt( count++ ) ) )
		stra.Add( obj->GetString() + _T( "\r\n" ) );

	if( file.WriteTextFile( filename, stra ) )
	{
		SetPackage( package );
		SetModified( FALSE );
	}
	else
		AfxMessageBox( file.GetErrorMessage() );

}

void CUMLEntityContainer::SetDisplayOptions( int displayOption ) 
{

	m_displayOptions = displayOption;
	CUMLEntity* obj;
	int count = 0;
	while( ( obj = GetObjectAt( count++ ) ) )
		obj->SetDisplayOptions( displayOption );

}

int CUMLEntityContainer::GetDisplayOptions() const 
{

	return m_displayOptions;

}

void CUMLEntityContainer::SetColor( COLORREF color ) 
{

	m_color = color;

}

COLORREF CUMLEntityContainer::GetColor() const 
{

	return m_color;

}

BOOL CUMLEntityContainer::PackageExists( const CString& name, CUMLEntity* filter ) 
{

	BOOL result = FALSE;

	CString oldpackage = GetPackage();
	SetPackage( _T( "all" ) );
	CUMLEntity* obj;
	int count = 0;
	while( ( obj = GetObjectAt( count++ ) ) )
		if( obj->GetTitle() == name && obj != filter )
			result = TRUE;

	SetPackage( oldpackage );

	return result;

}

CString CUMLEntityContainer::GetString() const 
{

	CString str;
	str.Format( _T( "paper:%i,%i,%i;" ), GetVirtualSize().cx, GetVirtualSize().cy, static_cast< int >( GetColor() ) );
	return str;

}

BOOL CUMLEntityContainer::FromString( const CString& str ) 
{

	BOOL result = FALSE;

	CTokenizer main( str, _T( ":" ) );
	CString header;
	CString data;
	if( main.GetSize() == 2 )
	{
		main.GetAt( 0, header );
		main.GetAt( 1, data );
		header.TrimLeft();
		header.TrimRight();
		data.TrimLeft();
		data.TrimRight();
		if( header == _T( "paper" ) )
		{
			CTokenizer tok( data.Left( data.GetLength() - 1 ) );
			int size = tok.GetSize();
			if( size == 3 )
			{
				int right;
				int bottom;
				int color;

				tok.GetAt(0, right );
				tok.GetAt(1, bottom );
				tok.GetAt(2, color );

				SetVirtualSize( CSize( right, bottom ) );
				SetColor( static_cast< COLORREF >( color ) );
				result = TRUE;
			}
		}
	}

	return result;

}

BOOL CUMLEntityContainer::LineSelected( CUMLLineSegment* line ) const 
{

	BOOL result = FALSE;
	if( line->IsSelected() )
	{
		CUMLEntity* obj = GetStartNode( line );
		if( obj && obj->IsSelected() )
		{
			obj = GetEndNode( line );
			if( obj && obj->IsSelected() )
			{
				result = TRUE;
				CUMLLineSegment* seg = GetStartSegment( line );
				while( seg )
				{
					if( !seg->IsSelected() )
						result =  FALSE;
					seg = GetNextSegment( seg );
				}
			}
		}
	}

	return result;

}

void CUMLEntityContainer::Undo() 
{

	if( GetUndo()->GetSize() )
	{
		// We remove all current data
		RemoveAll();

		// We get the last entry from the undo-stack
		// and clone it into the container data
		CUMLUndoItem* undo = static_cast< CUMLUndoItem* >( GetUndo()->GetAt( GetUndo()->GetUpperBound() ) );
		int count = ( undo->arr ).GetSize();
		for( int t = 0 ; t < count ; t++ )
		{

			CDiagramEntity* obj = static_cast< CDiagramEntity* >( ( undo->arr ).GetAt( t ) );
			Add( obj->Clone() );

		}

		FixLinks( GetData() );

		// Set the saved virtual size as well
		SetVirtualSize( undo->pt );
		SetColor( undo->col );
		SetPackage( undo->package );

		// We remove the entry from the undo-stack
		delete undo;
		GetUndo()->RemoveAt( GetUndo()->GetUpperBound() );

	}

}

void CUMLEntityContainer::Snapshot() 
{

	if( GetUndoStackSize() > 0 && GetUndo()->GetSize() == GetUndoStackSize() )
	{
		delete GetUndo()->GetAt( 0 );
		GetUndo()->RemoveAt( 0 );
	}

	CUMLUndoItem* undo = new CUMLUndoItem;

	while( !undo && GetUndo()->GetSize() )
	{

		// We seem - however unlikely -
		// to be out of memory.
		// Remove first element in
		// undo-stack and try again
		delete GetUndo()->GetAt( 0 );
		GetUndo()->RemoveAt( 0 );
		undo = new CUMLUndoItem;

	}

	if( undo )
	{

		// Save current virtual size
		undo->pt = GetVirtualSize();
		undo->col = GetColor();
		undo->package = GetPackage();

		// Save all objects
		int count = GetData()->GetSize();
		for( int t = 0 ; t < count ; t++ )
			( undo->arr ).Add( GetAt( t )->Clone() );

		FixLinks( &( undo->arr ) );

		// Add to undo stack
		GetUndo()->Add( undo );

	}

}

void CUMLEntityContainer::FixLinks( CObArray *arr ) 
{

	int count = arr->GetSize();

	for( int t = 0 ; t < count ; t++ )
	{
		CUMLEntity* obj = static_cast< CUMLEntity* >( arr->GetAt( t ) );
		if( obj->GetOldId().GetLength() )
		{
			for( int i = 0 ; i < count ; i++ )
			{

				if( t != i )
				{
					CUMLLineSegment* line = dynamic_cast< CUMLLineSegment* >( arr->GetAt( i ) );
					if( line )
					{
						if( line->GetLink( LINK_START ) == obj->GetOldId() )
							line->SetLink( LINK_START, obj->GetName() );
						if( line->GetLink( LINK_END ) == obj->GetOldId() )
							line->SetLink( LINK_END, obj->GetName() );
					}
				}
			}
			obj->SetOldId( _T( "" ) );
		}
	}

}

CSize CUMLEntityContainer::CalcMinimumRestraints( const CString& name ) 
{

	CSize result( -1, -1 );
	BOOL horz = FALSE;
	BOOL vert = FALSE;
	if( name.GetLength() )
	{
		int max = GetSize();
		for( int t = 0 ; t < max ; t++ )
		{
			CUMLLineSegment* line = dynamic_cast< CUMLLineSegment* >( GetAt( t ) );
			if( line )
			{
				int offset = -1;
				if( line->GetLink( LINK_START ) == name )
					offset = line->GetOffset( LINK_START );

				if( line->GetLink( LINK_END ) == name )
					offset = line->GetOffset( LINK_END );

				if( offset != -1 )
				{
					if( line->IsHorizontal() )
					{
						if( result.cx == -1 )
							result.cx = offset;
						else if( offset > result.cx )
							result.cx = offset;
						horz = TRUE;
					}
					else
					{
						if( result.cy == -1 )
							result.cy = offset;
						else if( offset > result.cy )
							result.cy = offset;
						vert = TRUE;
					}

					if( horz && vert )
						return result;
				}
			}
		}
	}

	return result;

}

void CUMLEntityContainer::SetProjectName( const CString& value ) 
{

	m_project = value;

}

CString CUMLEntityContainer::GetProjectName() const 
{

	return m_project;

}

void CUMLEntityContainer::SetProjectLocation( const CString& value ) 
{

	m_location = value;

}

CString CUMLEntityContainer::GetProjectLocation() const 
{

	return m_location;

}

void CUMLEntityContainer::Export( CStringArray& stra, UINT format ) const 
{

	switch( format )
	{
		case EXPORT_HTML:
			ExportHTML( stra );
			break;
		case EXPORT_CPP:
			ExportCPP();
			break;
		case EXPORT_H:
			ExportH();
			break;
	}

}

void CUMLEntityContainer::ExportHTML( CStringArray& stra ) const 
{

	// Creating headers
	CStringArray	ext;
	CTextFile		file;
	CString			filename;
	filename =		GetApplicationDirectory() + _T( "html_header.txt" );
	if( file.ReadTextFile( filename, ext ) )
	{
		stra.Append( ext );
	}
	else
	{
		CString title;
		title.Format( _T( "<title>%s</title>" ), GetProjectName() );
		stra.Add( _T( "<html>" ) );
		stra.Add( _T( "<head>" ) );
		stra.Add( title );
		stra.Add( _T( "<meta name=\"generator\" content=\"UMLEditorDemo\">" ) );
		stra.Add( _T( "<meta http-equiv=\"content-type\" content=\"text/html; charset=iso-8859-1\">" ) );
		stra.Add( _T( "</head>" ) );
		stra.Add( _T( "<body>" ) );
	}

	CString div;
	div.Format( _T( "<div style='position:relative;height:%i;'>" ), GetTotalHeight() );
	stra.Add( div );

	// Creating the individual objects.
	// Create lines first, as they might
	// be to tall vertically (there is a
	// minimum height of the divs)
	int max = GetSize();
	int t = 0;
	for( t = 0 ; t < max ; t++ )
	{
		CUMLLineSegment* obj = dynamic_cast< CUMLLineSegment* >( GetObjectAt( t ) );
		if( obj )
			if( GetPackage() == obj->GetPackage() )
				stra.Add( obj->Export( EXPORT_HTML ) );
	}

	for( t = 0 ; t < max ; t++ )
	{
		CUMLEntity* obj = GetObjectAt( t );
		CUMLLineSegment* seg = dynamic_cast< CUMLLineSegment* >( GetObjectAt( t ) );
		if( !seg )
			if( GetPackage() == obj->GetPackage() )
				stra.Add( obj->Export( EXPORT_HTML ) );
	}

	// Adding jogs
	// For each line we find in the data, we check against 
	// every other line onwards. If they cross, we add a 
	// div with a jog-picture.

	CString horzTemplate( _T( "<div style='position:absolute;left:%i;top:%i;width:16;height:8;background-image:url(\"images/lrjog.gif\");background-repeat:no-repeat;);'>&nbsp;&nbsp;&nbsp;&nbsp;</div>" ) );
	CString vertTemplate( _T( "<div style='position:absolute;left:%i;top:%i;width:8;height:16;background-image:url(\"images/udjog.gif\");background-repeat:no-repeat;);'>&nbsp;</div>" ) );
	CString result;
	max = GetSize();
	for( int i = 0 ; i < max ; i++ )
	{
		CUMLLineSegment* obj = dynamic_cast< CUMLLineSegment* >( GetObjectAt( i ) );
		if( obj && GetPackage() == obj->GetPackage() )
		{
			BOOL horz = obj->IsHorizontal();
			for( int t = i + 1 ; t < max ; t++ )
			{
				CUMLLineSegment* line = dynamic_cast< CUMLLineSegment* >( GetObjectAt( t ) );
				if( line )
				{
					if( horz && !line->IsHorizontal() )
					{
						if( min( obj->GetLeft(), obj->GetRight() ) < line->GetLeft() &&
							max( obj->GetLeft(), obj->GetRight() ) > line->GetLeft() &&
							min( line->GetTop(), line->GetBottom() ) < obj->GetTop() &&
							max( line->GetTop(), line->GetBottom() ) > obj->GetTop() )
						{
							CRect rect( round( line->GetLeft() - 7 ), round( obj->GetTop() - 7 ), round( line->GetLeft() + 7 ), round( obj->GetTop() + 4 ) );
							result.Format( vertTemplate, rect.left, rect.top );
							stra.Add( result );
						}
					}

					else if( !horz && ( line->IsHorizontal() ) )
					{
						if( min( line->GetLeft(), line->GetRight() ) < obj->GetLeft() &&
							max( line->GetLeft(), line->GetRight() ) > obj->GetLeft() &&
							min( obj->GetTop(), obj->GetBottom() ) < line->GetTop() &&
							max( obj->GetTop(), obj->GetBottom() ) > line->GetTop() )
						{
							CRect rect( round( obj->GetLeft() - 7 ), round( line->GetTop() - 7 ), round( obj->GetLeft() + 4 ), round( line->GetTop() + 7 ) );
							result.Format( horzTemplate, rect.left, rect.top );
							stra.Add( result );
						}
					}
				}
			}
		}
	}

	stra.Add( _T( "</div>" ) );

	// Creating footer
	filename = GetApplicationDirectory() + _T( "html_footer.txt" );
	if( file.ReadTextFile( filename, ext ) )
	{
		stra.Append( ext );
	}
	else
	{
		stra.Add( _T( "</body>" ) );
		stra.Add( _T( "</html>" ) );
	}

}

void CUMLEntityContainer::ExportCPP() const 
{

	CUMLEntityContainer* const local = const_cast<CUMLEntityContainer* const>(this);
	CString current = GetPackage();
	local->SetPackage( _T( "all" ) );

	CString str;
	int max = GetSize();
	CString location = GetProjectLocation() + _T( "\\" ) + GetProjectName();
	CDiskObject cdo;
	local->SetErrorMessage( _T( "" ) );
	if( cdo.CreateDirectory( location ) )
	{
		for( int t = 0 ; t < max ; t++ )
		{
			CUMLEntityClass* obj = dynamic_cast< CUMLEntityClass* >( GetAt( t ) );
			if( obj )
			{
				CString title = obj->GetTitle();
				if( title.GetLength() )
				{
					CStringArray baseClassArray;
					CStringArray baseClassAccessArray;
					GetBaseClassArray( obj, baseClassArray, baseClassAccessArray );
					CStringArray baseClassFilenameArray;
					baseClassFilenameArray.Append( baseClassArray );

					if( GetStripLeadingClassCharacter() )
					{
						title = title.Right( title.GetLength() - 1 );
						int size = baseClassFilenameArray.GetSize();
						for( int i = 0 ; i < size ; i++ )
						{
							CString baseClassFilename = baseClassFilenameArray[ i ].Right( baseClassFilenameArray[ i ].GetLength() - 1 );
							baseClassFilenameArray[ i ] = baseClassFilename;
						}
					}

					obj->SetBaseClassArray( baseClassArray, baseClassAccessArray );

					CString path = GetObjectPath( obj );
					path.Replace( _TCHAR( ':' ), _TCHAR( '\\' ) );
					if( path.GetLength() )
					{
						if( path[0] != _TCHAR( '\\' ) )
							path = _T( "\\" ) + path;
					}

					CString filename = location + path + _T( "\\" ) + title;
					obj->SetFilename( title );
					filename += _T( ".cpp" );
					obj->SetBaseClassFilenameArray( baseClassFilenameArray );
					str = obj->Export( EXPORT_CPP );

					if( str.GetLength() )
					{
						if( cdo.CreateFile( filename ) ) 
						{
							CTextFile file( _T( "" ), _T( "\n" ) );;
							if( !file.WriteTextFile( filename, str ) )
								local->SetErrorMessage( file.GetErrorMessage() );
						}
						else
							local->SetErrorMessage( cdo.GetErrorMessage() );
					}
				}
			}
		}
	}
	else
		local->SetErrorMessage( cdo.GetErrorMessage() );

	local->SetPackage( current );

}

void CUMLEntityContainer::ExportH() const 
{

	CUMLEntityContainer* const local = const_cast<CUMLEntityContainer* const>(this);
	CString current = GetPackage();
	local->SetPackage( _T( "all" ) );

	CString str;
	int max = GetSize();
	CString location = GetProjectLocation() + _T( "\\" ) + GetProjectName();
	CDiskObject cdo;
	if( cdo.CreateDirectory( location ) )
	{
		for( int t = 0 ; t < max ; t++ )
		{
			CUMLEntityClass* obj = dynamic_cast< CUMLEntityClass* >( GetAt( t ) );
			if( obj )
			{
				CString title = obj->GetTitle();
				if( title.GetLength() )
				{
					CStringArray baseClassArray;
					CStringArray baseClassAccessArray;
					GetBaseClassArray( obj, baseClassArray, baseClassAccessArray );
					CStringArray baseClassFilenameArray;
					baseClassFilenameArray.Append( baseClassArray );

					if( GetStripLeadingClassCharacter() )
					{
						title = title.Right( title.GetLength() - 1 );
						int size = baseClassFilenameArray.GetSize();
						for( int i = 0 ; i < size ; i++ )
						{
							CString baseClassFilename = baseClassFilenameArray[ i ].Right( baseClassFilenameArray[ i ].GetLength() - 1 );
							baseClassFilenameArray[ i ] = baseClassFilename;
						}
					}

					obj->SetBaseClassArray( baseClassArray, baseClassAccessArray );

					CString path = GetObjectPath( obj );
					path.Replace( _TCHAR( ':' ), _TCHAR( '\\' ) );
					if( path.GetLength() )
					{
						if( path [ 0 ] != _TCHAR( '\\' ) )
							path = _T( "\\" ) + path;
					}

					CString filename = location + path + _T( "\\" ) + title;
					obj->SetFilename( title );
					filename += _T( ".h" );
					obj->SetBaseClassFilenameArray( baseClassFilenameArray );
					str = obj->Export( EXPORT_H );

					if( cdo.CreateFile( filename ) ) 
					{
						CTextFile file( _T( "" ), _T( "\n" ) );;
						if( !file.WriteTextFile( filename, str ) )
							AfxMessageBox( file.GetErrorMessage() );
					}
					else
						local->SetErrorMessage( cdo.GetErrorMessage() );
				}
			}
		}
	}
	else
		AfxMessageBox( cdo.GetErrorMessage() );

	local->SetPackage( current );

}

void CUMLEntityContainer::GetBaseClassArray( CUMLEntityClass* obj, CStringArray& array, CStringArray& arrayAccess ) const
{

	CStringArray result;
	CStringArray accessArray;
	CString baseClass = obj->GetProperties()->GetPropertyValue( _T( "baseClass" ) );
	if( baseClass.GetLength() )
	{
		CTokenizer tok( baseClass, " " );
		int max = tok.GetSize();
		for( int t = 0 ; t < max ; t++ )
		{
			CString value;
			tok.GetAt( t, value );
			result.Add ( value );
		}
	}
	else
	{
		int max = GetSize();
		for( int t = 0 ; t < max ; t++ )
		{
			CUMLLineSegment* line = dynamic_cast< CUMLLineSegment* >( GetAt( t ) );
			if( line )
			{
				if( line->GetLink( LINK_START ) == obj->GetName() )
				{
					// Check if this is an inherited class
					CUMLLineSegment* seg = GetEndSegment( line );
					if( seg && seg->GetStyle() & STYLE_ARROWHEAD )
					{
						CUMLEntityClass* node = dynamic_cast< CUMLEntityClass* >( GetEndNode( seg ) );
						if( node )
							result.Add( node->GetTitle() );
						else
						{
							// Might be a 
							CUMLEntityInterface* node = dynamic_cast< CUMLEntityInterface* >( GetEndNode( seg ) );
							if( node )
								result.Add( node->GetTitle() );
						}
					}

				}

				// If we have a multi-segment line, it might be flipped
				if( GetNextSegment( line ) || GetPrevSegment( line ) )
				{
					if( line->GetLink( LINK_END ) == obj->GetName() )
					{
						// Check if this is an inherited class
						CUMLLineSegment* seg = GetStartSegment( line );
						if( seg && seg->GetStyle() & STYLE_ARROWHEAD )
						{
							CUMLEntityClass* node = dynamic_cast< CUMLEntityClass* >( GetStartNode( seg ) );
							if( node )
								result.Add( node->GetTitle() );
						}

					}
				}

			}
		}
	}

	int max = result.GetSize();
	for( int t = 0 ; t < max ; t++ )
	{

		CString access( _T( "public" ) );
		CUMLEntity* base = GetTitledObject( result[ t ] );
		if( base )
		{

			// Try to find a link between obj and base
			CUMLLineSegment* seg = GetLinkBetween( obj, base );
			if( seg )
			{

				// Is any segment either private or protected?
				if( IsPrivateLink( seg ) )
					access = _T( "private" );
				if( IsProtectedLink( seg ) )
					access = _T( "protected" );

			}
		}
		accessArray.Add( access );

	}

	array.RemoveAll();
	array.Append( result );

	arrayAccess.RemoveAll();
	arrayAccess.Append( accessArray );

}

void CUMLEntityContainer::SetStripLeadingClassCharacter( BOOL stripLeadingClassLetter ) 
{

	m_stripLeadingClassLetter = stripLeadingClassLetter;

}

BOOL CUMLEntityContainer::GetStripLeadingClassCharacter() const 
{

	return m_stripLeadingClassLetter;

}

BOOL CUMLEntityContainer::IsLinkSelected() const 
{

	if( GetSelectCount() == 1 )
	{
		CUMLLineSegment* line = dynamic_cast< CUMLLineSegment* >( GetSelectedObject() );
		if( line )
			return TRUE;
	}
		
	return FALSE;

}

void CUMLEntityContainer::FlipLink() 
{

	if( GetSelectCount() == 1 )
	{
		CUMLLineSegment* line = dynamic_cast< CUMLLineSegment* >( GetSelectedObject() );
		if( line )
		{
			if( line->IsSingleLineSegment() )
			{
				line->Flip();
			}
			else
			{
				CUMLLineSegment* start = GetStartSegment( line );
				CUMLLineSegment* end = GetEndSegment( line );
				if( start && end )
				{

					int style = end->GetStyle();
					end->SetStyle( start->GetStyle() );
					start->SetStyle( style );

				}
			}
		}
	}

}

CDiagramEntity* CUMLEntityContainer::GetSelectedObject() const 
{

	int count = 0;
	CDiagramEntity* obj;

	while( ( obj = GetAt( count++ ) ) )
		if( obj->IsSelected() )
			return obj;

	return NULL;

}

void CUMLEntityContainer::Import() 
{

	SendMessageToObjects( CMD_IMPORT, TRUE );

}

void CUMLEntityContainer::GetIncludeList( CUMLEntityClass* inobj, CStringArray& stringarray ) const 
{

	CStringArray stra;
	int max = GetSize();
	CStringArray classes;
	GetClassList( classes );

	CStringArray baseClassArray;
	CStringArray baseClassAccessArray;
	GetBaseClassArray( inobj, baseClassArray, baseClassAccessArray );
	int size = baseClassArray.GetSize();
	int t = 0;
	for( t = 0 ; t < size ; t++ )
	{
		if( InClasslist( baseClassArray[ t ], classes ) )
			stra.Add( baseClassArray[ t ] );
	}

	for( t = 0 ; t < max ; t++ )
	{
		CUMLLineSegment* line = dynamic_cast< CUMLLineSegment* >( GetAt( t ) );
		if( line )
		{
			if( line->IsSingleLineSegment() )
			{
				if( line->GetLink( LINK_END ) == inobj->GetName() )
				{
					if( line->GetStyle() & STYLE_FILLED_DIAMOND )
					{
						CUMLEntityClass* node = NULL;
						node = dynamic_cast< CUMLEntityClass*>( GetStartNode( line ) );

						if( node && node != inobj )
						{
							CString title = node->GetTitle();
							AddString( title, stra );

						}
					}
				}
			}
			else
			{
				if( line->GetLink( LINK_END ) == inobj->GetName() || line->GetLink( LINK_START ) == inobj->GetName() )
				{
					if( line->GetStyle() & STYLE_FILLED_DIAMOND )
					{
						CUMLEntityClass* node = NULL;
						if( line->GetLink( LINK_END ) == inobj->GetName() )
							node = dynamic_cast< CUMLEntityClass*>( GetStartNode( line ) );
						else
							node = dynamic_cast< CUMLEntityClass*>( GetEndNode( line ) );

						if( node && node != inobj )
						{
							CString title = node->GetTitle();
							AddString( title, stra );

						}
					}
				}
			}
		}
	}

	max = classes.GetSize();
	size = inobj->GetOperations();

	CString cls( inobj->GetTitle() );
	for( t = 0 ; t < size ; t++ )
	{
		COperation* op = inobj->GetOperation( t );
		int params = op->parameters.GetSize();
		for( int i = 0 ; i < params ; i++ )
		{
			CParameter* param = op->parameters.GetAt( i );
			CString title( param->type );
			title.Remove( _TCHAR( '*' ) );
			title.Remove( _TCHAR( '&' ) );
			int templ = title.Find( _TCHAR( '<' ) );
			if( templ != -1 )
				title = title.Left( templ );

			if( cls != title && InClasslist( title, classes ) )
			{
				if( param->out && ! param->reference )
				{
					if( !inobj->InBaseClassArray( title ) )
					{
						title = _T( "#" ) + title; // prepare for a forward declaration
						AddString( title, stra );
					}
				}
			}
		}
	}

	size = inobj->GetAttributes();
	for( t = 0 ; t < size ; t++ )
	{
		CAttribute* attr = inobj->GetAttribute( t );
		CString title( attr->type );
		int pointer = title.Remove( _TCHAR( '*' ) );
		int templ = title.Find( _TCHAR( '<' ) );
		if( templ != -1 )
			title = title.Left( templ );

		if( cls != title && InClasslist( title, classes ) )
		{
			if( pointer )
				title = _T( "#" ) + title;
			AddString( title, stra );
		}
	}

	// Put forward declarations at the end of the list
	max = stra.GetSize();
	for( t = 0 ; t < max ; t++ )
	{
		if( stra[ t ][ 0 ] != _TCHAR( '#' ) )
		{
			CString filename( stra[ t ] );
			if( GetStripLeadingClassCharacter() )
				filename = filename.Right( filename.GetLength() - 1 );
			stringarray.Add( filename );
		}
	}

	for( t = 0 ; t < max ; t++ )
		if( stra[ t ][ 0 ] == _TCHAR( '#' ) )
			stringarray.Add( stra[ t ] );

}

void CUMLEntityContainer::GetDependencyList( CUMLEntityClass* inobj, CStringArray& stringarray ) const 
{

	CStringArray stra;
	CStringArray included;
	GetIncludeList( inobj, included );

	int max = GetSize();
	int t = 0;
	for( t = 0 ; t < max ; t++ )
	{
		CUMLLineSegment* line = dynamic_cast< CUMLLineSegment* >( GetAt( t ) );
		if( line )
		{
			if( line->IsSingleLineSegment() )
			{
				if( line->GetLink( LINK_END ) == inobj->GetName() )
				{
					if( line->GetStyle() & STYLE_FILLED_ARROWHEAD && line->GetStyle() & STYLE_DASHED )
					{
						CUMLEntityClass* node = NULL;
						node = dynamic_cast< CUMLEntityClass* >( GetStartNode( line ) );

						if( node && node != inobj )
						{

							CString title = node->GetTitle();
							AddString( title, stra );

						}
					}
				}
			}
			else
			{
				if( line->GetLink( LINK_START ) == inobj->GetName() || line->GetLink( LINK_END ) == inobj->GetName() )
				{
					if( !( line->GetStyle() & STYLE_FILLED_ARROWHEAD ) && line->GetStyle() & STYLE_DASHED )
					{
						CUMLEntityClass* node = NULL;
						if( line->GetLink( LINK_START ) == inobj->GetName() )
							node = dynamic_cast< CUMLEntityClass*>( GetEndNode( line ) );
						else
							node = dynamic_cast< CUMLEntityClass*>( GetStartNode( line ) );

						if( node && node != inobj )
						{

							CString title = node->GetTitle();
							AddString( title, stra );

						}
					}
				}
			}
		}
	}

	CStringArray classes;
	GetClassList( classes );
	max = classes.GetSize();
	int size = inobj->GetOperations();

	CString cls( inobj->GetTitle() );
	for( t = 0 ; t < size ; t++ )
	{
		COperation* op = inobj->GetOperation( t );
		int params = op->parameters.GetSize();
		for( int i = 0 ; i < params ; i++ )
		{
			CParameter* param = op->parameters.GetAt( i );
			CString title( param->type );
			int templ = title.Find( _TCHAR( '<' ) );
			if( templ != -1 )
				title = title.Left( templ );
			if( cls != title && InClasslist( title, classes ) )
				AddString( title, stra );
		}
	}

	size = inobj->GetAttributes();
	for( t = 0 ; t < size ; t++ )
	{
		CAttribute* at = inobj->GetAttribute( t );
		if( at->type[ at->type.GetLength() - 1 ] == _TCHAR( '*' ) )
		{
			CString title( at->type );
			title = title.Left( title.GetLength() - 1 );
			int templ = title.Find( _TCHAR( '<' ) );
			if( templ != -1 )
				title = title.Left( templ );
			if( cls != title && InClasslist( title, classes ) )
				AddString( title, stra );

		}
	}

	// Check against already included
	max = stra.GetSize();
	size = included.GetSize();
	for( t = max - 1 ; t >= 0 ; t-- )
	{
		for( int i = 0 ; i < size ; i++ )
		{
			if( included[ i ] == stra[ t ] )
			{
				stra.RemoveAt( t );
				i = size;
			}
		}
	}

	max = stra.GetSize();
	for( t = 0 ; t < max ; t++ )
	{
		CString filename( stra[ t ] );
		if( GetStripLeadingClassCharacter() )
			filename = filename.Right( filename.GetLength() - 1 );
		stringarray.Add( filename );
	}

}

BOOL CUMLEntityContainer::VirtualizeClasses() 
{

	BOOL result = FALSE;
	int max = GetSize();
	for( int t = 0 ; t < max ; t++ )
	{
		CUMLEntityClass* obj = dynamic_cast< CUMLEntityClass* >( GetAt( t ) );
		if( obj )
		{
			CStringArray baseClassArray;
			CStringArray baseClassAccessArray;
			GetBaseClassArray( obj, baseClassArray, baseClassAccessArray );
			if( baseClassArray.GetSize() )
			{
				for( int i = 0 ; i < baseClassArray.GetSize() ; i++ )
				{
					CUMLEntityClass* base = dynamic_cast< CUMLEntityClass* >( GetTitledObject( baseClassArray[ i ] ) );
					if( base )
					{
						int operations = obj->GetOperations();
						int baseoperations = base->GetOperations();
						for( int i = 0 ; i < operations ; i++ )
						{
							COperation* operation = obj->GetOperation( i );
							if( operation->name == _T( "~" ) + obj->GetTitle() )
							{
								// Always make dtors virtual
								operation->properties.Add( _T( "virtual" ) );
								for( int x = 0 ; x < baseoperations ; x++ )
								{
									COperation* baseoperation = base->GetOperation( x );
									if( baseoperation->name == _T( "~" ) + base->GetTitle() )
										baseoperation->properties.Add( _T( "virtual" ) );
								}
								result = TRUE;
							}
							else
							{
								for( int x = 0 ; x < baseoperations ; x++ )
								{
									COperation* baseoperation = base->GetOperation( x );
									if( *operation == *baseoperation )
									{
										operation->properties.Add( _T( "virtual" ) );
										baseoperation->properties.Add( _T( "virtual" ) );
										result = TRUE;
									}
								}
							}
						}
					}
					else
					{
						int operations = obj->GetOperations();
						for( int i = 0 ; i < operations ; i++ )
						{
							COperation* operation = obj->GetOperation( i );
							if( operation->name == _T( "~" ) + obj->GetTitle() )
							{
								// Always make dtors virtual
								operation->properties.Add( _T( "virtual" ) );
								result = TRUE;
							}
						}
					}
				}
			}
		}
	}

	return result;

}

BOOL CUMLEntityContainer::BaseClassClasses() 
{

	// Loop all classes, setting the base 
	// class property
	BOOL result = FALSE;
	int max = GetSize();
	for( int t = 0 ; t < max ; t++ )
	{
		CUMLEntityClass* obj = dynamic_cast< CUMLEntityClass* >( GetAt( t ) );
		if( obj )
		{
			CStringArray baseClassArray;
			CStringArray baseClassAccessArray;
			GetBaseClassArray( obj, baseClassArray, baseClassAccessArray );
			if( baseClassArray.GetSize() )
			{
				CString baseClass;
				for( int i = 0 ; i < baseClassArray.GetSize() ; i++ )
				{
					baseClass += baseClassArray[ i ] + _T( " ") ;
				}

				baseClass.TrimLeft();
				baseClass.TrimRight();
				obj->GetProperties()->SetPropertyValue( _T( "baseClass" ), baseClass );
				result = TRUE;
			}
		}
	}

	return result;

}

BOOL CUMLEntityContainer::AddInterfacesToClasses() 
{

	// Loop all classes, getting interfaces 
	// and adding operations
	BOOL result = FALSE;
	int max = GetSize();
	for( int t = 0 ; t < max ; t++ )
	{
		CUMLEntityClass* obj = dynamic_cast< CUMLEntityClass* >( GetAt( t ) );
		if( obj )
		{
			CStringArray baseClassArray;
			CStringArray baseClassAccessArray;
			GetBaseClassArray( obj, baseClassArray, baseClassAccessArray );
			if( baseClassArray.GetSize() )
			{
				for( int i = 0 ; i < baseClassArray.GetSize() ; i++ )
				{
					CUMLEntityClass* base = dynamic_cast< CUMLEntityClass* >( GetTitledObject( baseClassArray[ i ] ) );
					if( base )
					{
						int operations = obj->GetOperations();
						int baseoperations = base->GetOperations();
						// Loop the base operations, trying to find pure virtual
						// operations. If a pure virtual function is found,
						// it is added to the operation container of the derived class.
						for( int x = 0 ; x < baseoperations ; x++ )
						{
							COperation* baseoperation = base->GetOperation( x );
							if( baseoperation )
							{
								if( baseoperation->maintype & ENTITY_TYPE_ABSTRACT )
								{
									BOOL found = FALSE;
									for( int y = 0 ; y < operations ; y++ )
									{
										COperation* operation = obj->GetOperation( y );
										if( operation )
										{
											if( *operation == *baseoperation )
											{
												found = TRUE;
											}
										}
									}
									if( !found )
									{
										// Add the pure virtual operation 
										// to the derived class
										COperation* newoperation = baseoperation->Clone();
										newoperation->maintype = 0;
										obj->AddOperation( newoperation );
										obj->CalcRestraints();
										result = TRUE;
									}
								}
							}
						}
					}
				}
			}
		}
	}

	return result;

}

void CUMLEntityContainer::SetErrorMessage( const CString& error ) 
{

	m_error = error;

}

CString CUMLEntityContainer::GetErrorMessage() const 
{

	return m_error;

}

void CUMLEntityContainer::GetClassList( CStringArray& stra ) const 
{

	int max = GetSize();
	for( int t = 0 ; t < max ; t++ )
	{

		CUMLEntityClass* obj = dynamic_cast< CUMLEntityClass* >( GetAt( t ) );
		if( obj )
		{
			CString name = obj->GetTitle();
			stra.Add( name );
		}

	}

}

BOOL CUMLEntityContainer::InClasslist( const CString& name,  const CStringArray& stra ) const 
{

	BOOL result = FALSE;

	int max = stra.GetSize();
	for( int t = 0 ; t < max ; t++ )
	{
		CString cls = stra[ t ];
		if( cls == name )
			result = TRUE;
	}

	return result;

}

CString CUMLEntityContainer::GetObjectPath( CUMLEntity* inobj ) const 
{

	CUMLEntityContainer* const local = const_cast<CUMLEntityContainer* const>(this);
	CString current = GetPackage();
	local->SetPackage( _T( "all" ) );
	CString package = inobj->GetPackage();
	CString level( package );
	CString path;
	while( level.GetLength() )
	{
		CUMLEntity* obj = GetNamedObject( level );
		if( obj )
		{
			path = obj->GetTitle() + _T( ":" ) + path;
			level = obj->GetPackage();
		}
		else
			level = _T( "" );
	}

	if( path.GetLength() )
		path = path.Left( path.GetLength() - 1 );

	local->SetPackage( current );

	return path;

}

int CUMLEntityContainer::GetTotalHeight() const 
{

	int bottom = 0;
	int top = 100;
	int max = GetSize();
	for( int t = 0 ; t < max ; t++ )
	{

		CDiagramEntity* obj = GetAt( t );
		bottom = max( bottom, round( obj->GetTop() ) );
		bottom = max( bottom, round( obj->GetBottom() ) );

		// We want to leave as much space at 
		// the bottom as at the top.
		top = min( top, round( obj->GetTop() ) );
		top = min( top, round( obj->GetBottom() ) );

	}

	return bottom + top;

}

void CUMLEntityContainer::Load( CArchive& ar ) 
{

	Clear();
	CString str;
	while(ar.ReadString( str ) )
	{

		if( !FromString( str ) )
		{
			CDiagramEntity* obj = CUMLControlFactory::CreateFromString( str );
			if( obj )
				Add( obj );
		}
	}

	SetModified( FALSE );

}

void CUMLEntityContainer::Load( CString& filename ) 
{

	CTextFile		file;
	CStringArray	stra;
	if( file.ReadTextFile( filename, stra ) )
	{
		Clear();
		int max = stra.GetSize();
		for( int t = 0 ; t < max ; t++ )
		{
			if( !FromString( stra[ t ] ) )
			{
				CDiagramEntity* obj = CUMLControlFactory::CreateFromString( stra[ t ] );
				if( obj )
					Add( obj );
			}
		}
	}
	else
		AfxMessageBox( file.GetErrorMessage() );

}

CUMLLineSegment* CUMLEntityContainer::GetLinkBetween( CUMLEntity* start, CUMLEntity* end ) const 
{

	CUMLLineSegment* result = NULL;
	CUMLEntity* startnode;
	CUMLEntity* endnode;
	int max = GetSize();
	for( int t = 0; t < max ; t++ )
	{
		CUMLLineSegment* link = dynamic_cast< CUMLLineSegment* >( GetAt( t ) );
		if( link )
		{
			startnode = GetStartNode( link );
			endnode = GetEndNode( link );
			if( ( startnode == start && endnode == end ) ||
				( startnode == end && endnode == start ) )
			{
				result = link;
				t = max;
			}
		}
	}

	return result;

}

BOOL CUMLEntityContainer::IsPrivateLink( CUMLLineSegment* link ) const 
{

	CString val( _T( "?private ?" ) );
	BOOL result = FALSE;
	CUMLLineSegment* segment = GetStartSegment( link );
	while( segment )
	{
		if( segment->GetTitle() == val )
		{
			result = TRUE;
			segment = NULL;
		}
		else
			segment = GetNextSegment( segment );
	}

	return result;

}

BOOL CUMLEntityContainer::IsProtectedLink( CUMLLineSegment* link ) const 
{

	CString val( _T( "?protected ? ") );
	BOOL result = FALSE;
	CUMLLineSegment* segment = GetStartSegment( link );
	while( segment )
	{
		if( segment->GetTitle() == val )
		{
			result = TRUE;
			segment = NULL;
		}
		else
			segment = GetNextSegment( segment );
	}

	return result;

}

#pragma warning( default : 4706 )
#pragma warning( default : 4541 )
