
#include "stdafx.h"
#include "UMLEntityPackage.h"
#include "UMLPackagePropertyDialog.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CUMLPackagePropertyDialog dialog

CUMLPackagePropertyDialog::CUMLPackagePropertyDialog(CWnd* pParent /*=NULL*/)
	: CDiagramPropertyDlg(CUMLPackagePropertyDialog::IDD, pParent) 
{

	//{{AFX_DATA_INIT(CUMLPackagePropertyDialog)
	m_text = _T("");
	//}}AFX_DATA_INIT

}

CUMLPackagePropertyDialog::~CUMLPackagePropertyDialog() 
{
}

void CUMLPackagePropertyDialog::DoDataExchange(CDataExchange* pDX) 
{

	CDiagramPropertyDlg::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CUMLPackagePropertyDialog)
	DDX_Text(pDX, IDC_EDIT_TEXT, m_text);
	//}}AFX_DATA_MAP

}

BEGIN_MESSAGE_MAP(CUMLPackagePropertyDialog, CDiagramPropertyDlg)
	//{{AFX_MSG_MAP(CUMLPackagePropertyDialog)
	ON_BN_CLICKED(IDC_BUTTON_FONT, OnButtonFont)
	ON_BN_CLICKED(IDC_BUTTON_COLOR, OnButtonColor)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CUMLPackagePropertyDialog message handlers

void CUMLPackagePropertyDialog::OnOK()  
{

	CUMLEntityPackage* uml = static_cast< CUMLEntityPackage* >( GetEntity() );

	UpdateData();
	if( uml->ModifyTitle( m_text ) )
	{
		uml->SetBkColor( m_color );
		uml->SetFont( m_font );
		Redraw();
		ShowWindow( SW_HIDE );
		GetRedrawWnd()->SetFocus();
	}

}

void CUMLPackagePropertyDialog::OnCancel()  
{

	CDialog::OnCancel();
	GetRedrawWnd()->SetFocus();

}

/////////////////////////////////////////////////////////////////////////////
// CUMLPackagePropertyDialog overrides

void CUMLPackagePropertyDialog::SetValues()  
{

	CUMLEntityPackage* uml = static_cast< CUMLEntityPackage* >( GetEntity() );

	m_text = uml->GetTitle();
	m_color = uml->GetBkColor();
	m_font = uml->GetFont();

	if( m_hWnd )
		UpdateData( FALSE );

}

void CUMLPackagePropertyDialog::OnButtonFont()  
{

	CFont font;
	CUMLEntityPackage* uml = static_cast< CUMLEntityPackage* >( GetEntity() );
	font.CreatePointFont( 120, uml->GetFont() );
	LOGFONT lf;
	font.GetLogFont( &lf );
	CFontDialog	dlg( &lf );
	if( dlg.DoModal() == IDOK )
		m_font = dlg.GetFaceName();

}
void CUMLPackagePropertyDialog::OnButtonColor()  
{

	CUMLEntityPackage* uml = static_cast< CUMLEntityPackage* >( GetEntity() );
	COLORREF color = uml->GetBkColor();
	CColorDialog	dlg( color );
	if( dlg.DoModal() == IDOK )
		m_color = dlg.GetColor();
	
}
