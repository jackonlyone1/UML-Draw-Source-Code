#ifndef _UMLENTITYLABEL_H_
#define _UMLENTITYLABEL_H_

#include "UMLEntity.h"
#include "UMLLabelPropertyDialog.h"

 
//===========================================================================
// Summary:
//     The CUMLEntityLabel class derived from CUMLEntity
//      U M L Entity Label
//===========================================================================

class CUMLEntityLabel : public CUMLEntity
{
public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// U M L Entity Label, Constructs a CUMLEntityLabel object.
	//		Returns A  value.
	CUMLEntityLabel();
	
	//-----------------------------------------------------------------------
	// Summary:
	// C U M L Entity Label, Destructor of class CUMLEntityLabel
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value.
	virtual ~CUMLEntityLabel();

	
	//-----------------------------------------------------------------------
	// Summary:
	// Clone this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CDiagramEntity,or NULL if the call failed
	virtual CDiagramEntity* Clone();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create From String, You construct a CUMLEntityLabel object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is a static function.
	//		Returns a pointer to the object CDiagramEntity,or NULL if the call failed  
	// Parameters:
	//		str---Specifies A CString type value.
	static	CDiagramEntity* CreateFromString( const CString& str );
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draws current object to the specify device.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---A pointer to the CDC or NULL if the call failed.  
	//		rect---Specifies A CRect type value.
	virtual void Draw( CDC* dc, CRect rect );

	
	//-----------------------------------------------------------------------
	// Summary:
	// Get String, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CString type value.
	virtual CString GetString() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// From String, None Description.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns TRUE on success; FALSE otherwise.  
	// Parameters:
	//		str---Specifies A CString type value.
	virtual BOOL	FromString( const CString& str );
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Title, Sets a specify value to current class CUMLEntityLabel
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		title---Specifies A CString type value.
	virtual void	SetTitle( CString title );
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Rectangle, Sets a specify value to current class CUMLEntityLabel
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		rect---Specifies A CRect type value.
	virtual void	SetRect( CRect rect );
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Rectangle, Sets a specify value to current class CUMLEntityLabel
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		left---Specifies a double left object.  
	//		top---Specifies a double top object.  
	//		right---Specifies a double right object.  
	//		bottom---Specifies a double bottom object.
	virtual void	SetRect( double left, double top, double right, double bottom );
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Link Code, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.  
	// Parameters:
	//		point---Specifies A CPoint type value.
	virtual int		GetLinkCode( CPoint point ) const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// None Description.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CString type value.  
	// Parameters:
	//		format---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual CString	Export( UINT format = 0 ) const;

	
	//-----------------------------------------------------------------------
	// Summary:
	// Calculate Restraints, None Description.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void	CalcRestraints();

	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Bold, Sets a specify value to current class CUMLEntityLabel
	// Parameters:
	//		bold---Specifies A Boolean value.
	void			SetBold( BOOL bold );
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Italic, Sets a specify value to current class CUMLEntityLabel
	// Parameters:
	//		italic---Specifies A Boolean value.
	void			SetItalic( BOOL italic );
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Underline, Sets a specify value to current class CUMLEntityLabel
	// Parameters:
	//		underline---Specifies A Boolean value.
	void			SetUnderline( BOOL underline );
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Bold, Returns the specified value.
	//		Returns TRUE on success; FALSE otherwise.
	BOOL			GetBold() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Italic, Returns the specified value.
	//		Returns TRUE on success; FALSE otherwise.
	BOOL			GetItalic() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Underline, Returns the specified value.
	//		Returns TRUE on success; FALSE otherwise.
	BOOL			GetUnderline() const;

private:

 
	// This member specify CUMLLabelPropertyDialog object.  
	CUMLLabelPropertyDialog	m_dlg;


	
	//-----------------------------------------------------------------------
	// Summary:
	// Export H T M L, None Description.
	//		Returns a CString type value.
	CString ExportHTML() const;

 
	// This member sets TRUE if it is right.  
	BOOL	m_bold;
 
	// This member sets TRUE if it is right.  
	BOOL	m_italic;
 
	// This member sets TRUE if it is right.  
	BOOL	m_underline;

};

#endif //_UMLENTITYNOTE_H_
