#ifndef _UMLENTITYCLASSTEMPLATE_H_
#define _UMLENTITYCLASSTEMPLATE_H_

#include "UMLEntityClass.h"
#include "UMLTemplatePropertyDialog.h"

 
//===========================================================================
// Summary:
//     The CUMLEntityClassTemplate class derived from CUMLEntityClass
//      U M L Entity Class Template
//===========================================================================

class CUMLEntityClassTemplate : public CUMLEntityClass
{
public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// U M L Entity Class Template, Constructs a CUMLEntityClassTemplate object.
	//		Returns A  value.
	CUMLEntityClassTemplate();
	
	//-----------------------------------------------------------------------
	// Summary:
	// C U M L Entity Class Template, Destructor of class CUMLEntityClassTemplate
	//		Returns A  value.
	~CUMLEntityClassTemplate();

// Overrides
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clone this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CDiagramEntity,or NULL if the call failed
	virtual CDiagramEntity* Clone();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create From String, You construct a CUMLEntityClassTemplate object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is a static function.
	//		Returns a pointer to the object CDiagramEntity,or NULL if the call failed  
	// Parameters:
	//		str---Specifies A CString type value.
	static	CDiagramEntity* CreateFromString( const CString& str );

	
	//-----------------------------------------------------------------------
	// Summary:
	// Draws current object to the specify device.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---A pointer to the CDC or NULL if the call failed.  
	//		rect---Specifies A CRect type value.
	virtual void Draw( CDC* dc, CRect rect );

	
	//-----------------------------------------------------------------------
	// Summary:
	// Get String, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CString type value.
	virtual CString GetString() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// From String, None Description.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns TRUE on success; FALSE otherwise.  
	// Parameters:
	//		str---Specifies A CString type value.
	virtual BOOL	FromString( const CString& str );
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create a duplicate copy of this object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		obj---A pointer to the CDiagramEntity or NULL if the call failed.
	virtual void	Copy( CDiagramEntity* obj );
	
	//-----------------------------------------------------------------------
	// Summary:
	// None Description.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CString type value.  
	// Parameters:
	//		format---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual CString	Export( UINT format = 0 ) const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Import H, None Description.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns TRUE on success; FALSE otherwise.  
	// Parameters:
	//		filename---Specifies A CString type value.
	virtual BOOL	ImportH( const CString& filename );

	// Implementation
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Parameter Type, Sets a specify value to current class CUMLEntityClassTemplate
	// Parameters:
	//		parameterType---Type, Specifies A CString type value.
	void SetParameterType( const CString& parameterType );
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Parameter Type, Returns the specified value.
	//		Returns a CString type value.
	CString GetParameterType() const;

protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Header Template Filename, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CString type value.
	virtual CString GetHeaderTemplateFilename() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Operation List, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CString type value.  
	// Parameters:
	//		format---Specifies A integer value.
	virtual CString GetOperationList( int format ) const;

private:
 
	// This member specify CUMLTemplatePropertyDialog object.  
	CUMLTemplatePropertyDialog	m_dlg;

 
	// Type, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString	m_parameterType;

	
	//-----------------------------------------------------------------------
	// Summary:
	// Export H T M L, None Description.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CString type value.
	virtual CString ExportHTML() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Export H, None Description.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CString type value.
	virtual CString ExportH() const;

};

#endif //_UMLENTITYCLASSTEMPLATE_H_
