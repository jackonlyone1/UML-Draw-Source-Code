
#include "stdafx.h"
#include "UMLEntityDummy.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// Construction/destruction
CUMLEntityDummy::CUMLEntityDummy()
{

	SetRect( 0, 0, 0, 0 );
	SetType( _T( "uml_dummy" ) );

}

CUMLEntityDummy::~CUMLEntityDummy()
{
}

// Implementation
int CUMLEntityDummy::GetHitCode( CPoint /*point*/ ) const
{

	return DEHT_NONE;

}

int CUMLEntityDummy::GetLinkCode( CPoint /*point*/ ) const
{

	return LINK_NONE;

}

BOOL CUMLEntityDummy::IsSelected( ) const
{

	return FALSE;

}

void CUMLEntityDummy::Select( BOOL /*select*/ )
{
	// Do nothing
}

BOOL CUMLEntityDummy::BodyInRect( CRect /*rect*/ ) const
{

	return FALSE;

}



