
#include "stdafx.h"
#include "Property.h"
#include "Tokenizer.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// Construction/destruction
CProperty::CProperty() 
{
	key = _T( "" );
	value = _T( "" );
}

CProperty::~CProperty() 
{
}

CProperty::CProperty( CProperty* property ) 
{

	key = property->key;
	value = property->value;

}

CProperty::CProperty( const CString& tag, const CString& val ) 
{

	key = tag;
	value = val;

}

// Implementation
CString CProperty::GetString( int format ) const 
{

	CString result;

	switch( format )
	{
		case STRING_FORMAT_SAVE:

			result.Format( _T( "%s=%s" ),
					key,
					value
				);

			break;

		case STRING_FORMAT_UML:
			if( value.GetLength() )
			{
				result.Format( _T( "%s = %s" ),
						key,
						value
					);
			}
			else
				result = key;
			break;
	}

	return result;

}

CProperty* CProperty::FromString( const CString& str ) 
{
	CProperty* result = NULL;

	CTokenizer tok( str, _T( "=" ) );
	int max = tok.GetSize();
	if( max == 2 )
	{
		CString key;
		CString value;
		tok.GetAt( 0, key );
		tok.GetAt( 1, value );

		result = new CProperty;
		result->key = key;
		result->value = value;
	}

	return result;

}
