
#include "stdafx.h"
#include "UMLControlFactory.h"

#include "UMLEntityClass.h"
#include "UMLEntityNote.h"
#include "UMLEntityLabel.h"
#include "UMLEntityPackage.h"
#include "UMLEntityInterface.h"
#include "UMLEntityClassTemplate.h"
#include "UMLLineSegment.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CUMLControlFactory

CDiagramEntity* CUMLControlFactory::CreateFromString( const CString& str )
{
	CDiagramEntity* obj;

	obj = CUMLEntityClass::CreateFromString( str );
	if( !obj )
		obj = CUMLLineSegment::CreateFromString( str );
	if( !obj )
		obj = CUMLEntityNote::CreateFromString( str );
	if( !obj )
		obj = CUMLEntityPackage::CreateFromString( str );
	if( !obj )
		obj = CUMLEntityLabel::CreateFromString( str );
	if( !obj )
		obj = CUMLEntityInterface::CreateFromString( str );
	if( !obj )
		obj = CUMLEntityClassTemplate::CreateFromString( str );

	return obj;
}
