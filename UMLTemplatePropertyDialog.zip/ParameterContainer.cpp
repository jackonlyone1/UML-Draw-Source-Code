

#include "stdafx.h"
#include "ParameterContainer.h"
#include "Tokenizer.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


// Construction/destruction
CParameterContainer::CParameterContainer()
{
}

CParameterContainer::~CParameterContainer()
{

	RemoveAll();

}

void CParameterContainer::Copy( CParameterContainer& parameters )
{

	RemoveAll();
	int max = parameters.GetSize();
	for( int t = 0 ; t < max ; t++ )
		Add( new CParameter( parameters.GetAt( t ) ) );

}

// Implementation
int CParameterContainer::GetSize( ) const
{

	return m_parameters.GetSize();

}

CParameter* CParameterContainer::GetAt( int index ) const
{

	CParameter* result = NULL;
	if( index < GetSize() )
		result = static_cast< CParameter* >( m_parameters.GetAt( index ) );

	return result;

}

void CParameterContainer::RemoveAt( int index )
{

	if( index > -1 && index < GetSize() )
	{

		delete GetAt( index );
		m_parameters.RemoveAt( index );

	}

}

void CParameterContainer::RemoveAll( )
{

	while( GetSize() )
		RemoveAt( 0 );

}

void CParameterContainer::Add( CParameter* parameter )
{

	m_parameters.Add( parameter );

}

CString CParameterContainer::ToString( BOOL nooperationattributenames ) const
{

	CString output;
	int max = GetSize();

	for( int t = 0 ; t < max ; t++ )
	{
		CParameter* param = GetAt( t );
		output += param->ToString( nooperationattributenames );
		if( t < max - 1 )
			output += _T(", " );
	}

	return output;

}

CString CParameterContainer::GetString( int format ) const
{

	CString output;
	int max = GetSize();
	if( max )
	{
		switch( format )
		{
			case STRING_FORMAT_SAVE:
				{
					for( int t = 0 ; t < max ; t++ )
					{
						CParameter* param = GetAt( t );
						output+= param->GetString();
						if( t < max - 1 )
							output += _T("@" );
					}
				}
				break;
			case STRING_FORMAT_CPP:
			case STRING_FORMAT_H:
			case STRING_FORMAT_H_CTOR:
			case STRING_FORMAT_UML:
				{
					for( int t = 0 ; t < max ; t++ )
					{
						CParameter* param = GetAt( t );
						output += param->GetString( format );
						if( t < max - 1 )
							output += _T(", " );
					}
				}
				break;
		}
	}

	return output;

}

void CParameterContainer::FromString( const CString& str )
{

	CTokenizer tok( str, _T( "@" ) );
	int max = tok.GetSize();
	for( int t = 0 ; t < max ; t++ )
	{

		CString paramval;
		tok.GetAt( t, paramval );
		CParameter* param = CParameter::FromString( paramval );
		if( param )
			Add( param );

	}
}

void CParameterContainer::Remove( CParameter* parameter )
{

	int max = GetSize();
	for( int t = 0 ; t < max ; t++ )
	{
		CParameter* param = GetAt( t );
		if( param == parameter )
		{
			RemoveAt( t );
			parameter = NULL;
			t = max;
		}
	}

}

BOOL CParameterContainer::operator==( const CParameterContainer& parameters )
{

	BOOL result = TRUE;
	if( GetSize() == parameters.GetSize() )
	{
		int max = GetSize();
		for( int t = 0 ; t < max ; t++ )
			if( *( GetAt( t ) ) != *( parameters.GetAt( t ) ) )
				result = FALSE;
	}
	else
		result = FALSE;

	return result;

}
