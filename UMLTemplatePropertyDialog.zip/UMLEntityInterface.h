#ifndef _UMLENTITYINTERFACE_H_
#define _UMLENTITYINTERFACE_H_

#include "UMLEntity.h"
#include "UMLInterfacePropertyDialog.h"

 
//===========================================================================
// Summary:
//     The CUMLEntityInterface class derived from CUMLEntity
//      U M L Entity Interface
//===========================================================================

class CUMLEntityInterface : public CUMLEntity
{
public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// U M L Entity Interface, Constructs a CUMLEntityInterface object.
	//		Returns A  value.
	CUMLEntityInterface();
	
	//-----------------------------------------------------------------------
	// Summary:
	// C U M L Entity Interface, Destructor of class CUMLEntityInterface
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value.
	virtual ~CUMLEntityInterface();

	
	//-----------------------------------------------------------------------
	// Summary:
	// Clone this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CDiagramEntity,or NULL if the call failed
	virtual CDiagramEntity* Clone();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create From String, You construct a CUMLEntityInterface object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is a static function.
	//		Returns a pointer to the object CDiagramEntity,or NULL if the call failed  
	// Parameters:
	//		str---Specifies A CString type value.
	static	CDiagramEntity* CreateFromString( const CString& str );
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draws current object to the specify device.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---A pointer to the CDC or NULL if the call failed.  
	//		rect---Specifies A CRect type value.
	virtual void Draw( CDC* dc, CRect rect );

	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Link Code, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.  
	// Parameters:
	//		point---Specifies A CPoint type value.
	virtual int		GetLinkCode( CPoint point ) const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Selection Markers, Draws current object to the specify device.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---A pointer to the CDC or NULL if the call failed.  
	//		rect---Specifies A CRect type value.
	virtual void	DrawSelectionMarkers( CDC* dc, CRect rect ) const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Cursor, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A HCURSOR value.  
	// Parameters:
	//		hit---Specifies A integer value.
	virtual HCURSOR	GetCursor( int hit ) const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// None Description.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CString type value.  
	// Parameters:
	//		format---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual CString	Export( UINT format = 0 ) const;

private:

 
	// This member specify CUMLInterfacePropertyDialog object.  
	CUMLInterfacePropertyDialog	m_dlg;

};

#endif //_UMLENTITYINTERFACE_H_
